{{--
  میانبرهای پرکاربرد باکس جست‌وجوی صفحه‌ی خانه
  در این مرحله فقط چیدمان و ظاهر کارت‌ها آماده شده است.
--}}
<div class="ig-quick-row" dir="rtl">

  <a class="ig-quick-item" data-quick="upscale" href="{{ route('landing.image-quality') }}" aria-label="افزایش کیفیت عکس">
    <span class="ig-quick-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4 4h6"/>
        <path d="M4 4v6"/>
        <path d="M20 20h-6"/>
        <path d="M20 20v-6"/>
        <path d="m8 16 3-3 2 2 3-4 2 3"/>
        <circle cx="8" cy="8" r="1.4"/>
      </svg>
    </span>
    <span class="ig-quick-text">
      <span class="ig-quick-title">افزایش کیفیت</span>
      <span class="ig-quick-sub">عکس را واضح کن</span>
    </span>
  </a>

  <a class="ig-quick-item ig-quick-item--link" data-quick="character-sheet" href="{{ route('landing.character-sheet') }}" aria-label="کارکتر شیت">
    <span class="ig-quick-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="8" r="3"/>
        <path d="M5 20a7 7 0 0 1 14 0"/>
        <path d="M18 4v4"/>
        <path d="M16 6h4"/>
      </svg>
    </span>
    <span class="ig-quick-text">
      <span class="ig-quick-title">کارکتر شیت</span>
      <span class="ig-quick-sub">یکبار خودتو بساز!</span>
    </span>
  </a>

  <button type="button" class="ig-quick-item" data-quick="profile" aria-label="ساخت عکس پروفایل حرفه‌ای">
    <span class="ig-quick-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="8" r="3"/>
        <path d="M5 20a7 7 0 0 1 14 0"/>
        <path d="M18 4v4"/>
        <path d="M16 6h4"/>
      </svg>
    </span>
    <span class="ig-quick-text">
      <span class="ig-quick-title">پروفایل حرفه‌ای</span>
      <span class="ig-quick-sub">رسمی و جذاب</span>
    </span>
  </button>

  <button type="button" class="ig-quick-item" data-quick="photo-to-video" aria-label="تبدیل عکس به ویدئو">
    <span class="ig-quick-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="5" width="13" height="14" rx="2"/>
        <path d="m16 10 4.5-2.5v9L16 14"/>
        <path d="m8 9 4 3-4 3z"/>
      </svg>
    </span>
    <span class="ig-quick-text">
      <span class="ig-quick-title">عکس به ویدئو</span>
      <span class="ig-quick-sub">به عکس جان بده</span>
    </span>
  </button>

  <button type="button" class="ig-quick-item" data-quick="occasions" aria-label="ساخت عکس برای تولد و مناسبت‌ها">
    <span class="ig-quick-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4 10h16v10H4z"/>
        <path d="M12 10v10"/>
        <path d="M4 14h16"/>
        <path d="M12 10H8.5a2.5 2.5 0 1 1 2.5-2.5V10Z"/>
        <path d="M12 10h3.5A2.5 2.5 0 1 0 13 7.5V10Z"/>
      </svg>
    </span>
    <span class="ig-quick-text">
      <span class="ig-quick-title">تولد و مناسبت‌ها</span>
      <span class="ig-quick-sub">برای هر جشن بساز</span>
    </span>
  </button>

</div>
