<div class="hb-video-loop-row">
  @foreach($products as $product)
    @php
      $videoUrl = trim((string) $product->preview_video_url);
      if ($videoUrl !== '' && !str_starts_with($videoUrl, 'http') && !str_starts_with($videoUrl, '/')) {
        $videoUrl = str_starts_with($videoUrl, 'assets/')
          ? asset($videoUrl)
          : asset('storage/' . ltrim($videoUrl, '/'));
      }
    @endphp
    <a class="hb-video-loop-card" href="{{ route('app.product', $product->route_slug) }}">
      @if($videoUrl)
        <video data-hb-video-src="{{ $videoUrl }}" poster="{{ $product->displayImageUrl() }}" muted loop playsinline preload="none" aria-label="پیش‌نمایش {{ $product->name_fa }}"></video>
      @else
        <span class="hb-video-loop-fallback" data-hb-background style="--hb-card-image:url('{{ $product->displayImageUrl() }}');background-image:var(--hb-card-image)"></span>
      @endif
      <span class="hb-video-live"><i></i> پخش زنده</span>
      <div class="hb-video-loop-info"><b>{{ $product->name_fa }}</b><small>{{ $product->subcategory ?: $product->category }}</small></div>
    </a>
  @endforeach
</div>
