@extends('layouts.app')

@section('page_title', 'ساخت ' . ($product->name_fa ?: $product->name_en) . ' | وطن AI')

@push('styles')
  <link rel="stylesheet" href="{{ \App\Support\AppAsset::url('css/create-samples-workspace.css') }}">
  <style>
    .create-section--product .cw-generate.is-credit-locked { filter: none; }
  </style>
@endpush

@section('content')
  <div class="create-page-compare" dir="rtl">
    <button type="button" class="create-page-close" data-create-page-close title="برگشت" aria-label="برگشت به صفحه قبل">
      <i class="fa-solid fa-xmark" aria-hidden="true"></i>
    </button>
    <section class="create-section create-section--redesign create-section--product" data-create-section="redesign" aria-label="صفحه‌ی بساز محصول">
      @include('app.partials.create-samples-workspace', [
          'product' => $buildProduct,
          'previewMode' => false,
          'instance' => 'redesign',
      ])
    </section>
  </div>
@endsection

@push('scripts')
  <script src="{{ \App\Support\AppAsset::url('js/create-samples-workspace.js') }}"></script>
  <script>
    document.querySelector('[data-create-page-close]')?.addEventListener('click', function () {
      if (window.history.length > 1) window.history.back();
      else window.location.href = @json(route('app.home'));
    });
  </script>
@endpush
