(function () {
  'use strict';

  const root = document.querySelector('[data-create-studio]');
  if (!root) return;

  // Never restore this workflow from the browser back/forward cache after a deploy.
  window.addEventListener('pageshow', (event) => {
    if (event.persisted) window.location.reload();
  });

  let config = {};
  try { config = JSON.parse(root.querySelector('[data-studio-config]')?.textContent || '{}'); } catch (_) {}
  const faDigits = (value) => String(value).replace(/[0-9]/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[Number(digit)]);
  const modeTabs = [...root.querySelectorAll('[data-studio-mode]')];
  const form = root.querySelector('[data-studio-form]');
  const prompt = root.querySelector('[data-studio-prompt]');
  const promptCount = root.querySelector('[data-studio-count]');
  const submit = root.querySelector('[data-studio-submit]');
  const submitLabel = root.querySelector('[data-studio-submit-label]');
  const cost = root.querySelector('[data-studio-cost]');
  const videoContent = root.querySelector('[data-studio-video-content]');
  const imageContent = root.querySelector('[data-studio-image-content]');
  const progress = root.querySelector('[data-studio-progress]');
  const progressTitle = root.querySelector('[data-studio-progress-title]');
  const progressText = root.querySelector('[data-studio-progress-text]');
  const progressBar = root.querySelector('[data-studio-progress-bar]');
  const progressValue = root.querySelector('[data-studio-progress-value]');
  const result = root.querySelector('[data-studio-result]');
  const outputImage = root.querySelector('[data-studio-output-image]');
  const creditSummary = root.querySelector('[data-studio-credit-summary]');
  const outputVideo = root.querySelector('[data-studio-output-video]');
  const videoPlay = root.querySelector('[data-studio-video-play]');
  const errorBox = root.querySelector('[data-studio-error]');
  const errorText = errorBox?.querySelector('span');
  const uploadZone = root.querySelector('[data-studio-upload-zone]');
  const uploadInput = root.querySelector('[data-studio-upload-input]');
  const uploadFile = root.querySelector('[data-studio-upload-file]');
  const imageWorkflowTabs = root.querySelector('[data-image-workflow-tabs]');
  const imageWorkflowNote = root.querySelector('[data-image-workflow-note]');
  const negativeInput = root.querySelector('[data-studio-negative-input]');
  const outputCountInput = root.querySelector('[data-studio-output-count]');
  const stateKey = 'vatan-create-studio-state';
  let currentMode = 'image';
  let imageWorkflow = 'text_to_image';
  let activeConfig = null;
  let selectedValues = {};
  let selectedUploadFiles = [];
  let pollTimer = null;
  let progressTimer = null;
  let quoteTimer = null;
  let quoteSequence = 0;

  const ratioNames = {'1:1': 'مربع', '16:9': 'افقی', '9:16': 'عمودی', '4:5': 'پرتره', '3:4': 'عمودی', '4:3': 'افقی', '2:3': 'عمودی', '3:2': 'افقی', '21:9': 'عریض'};
  const formatRatio = (value) => String(value).replace(/[0-9]/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[Number(digit)]);
  const formatNumber = (value) => Number(value || 0).toLocaleString('fa-IR');
  const qualityLabel = (value) => {
    const normalized = String(value).trim().toLowerCase();
    if (normalized === '1k') return '۱٬۰۲۴ پیکسل';
    if (normalized === '2k') return '۲٬۰۴۸ پیکسل';
    if (normalized === '4k') return '۴٬۰۹۶ پیکسل';
    return `${formatNumber(normalizeDigits(value))} پیکسل`;
  };

  function hideError() { if (errorBox) errorBox.hidden = true; }
  function showError(message) { if (errorText) errorText.textContent = message; if (errorBox) errorBox.hidden = false; }

  function normalizeDigits(value) {
    return String(value ?? '')
      .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
      .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
      .replace(/[^0-9]/g, '');
  }

  function saveStudioState() {
    try {
      sessionStorage.setItem(stateKey, JSON.stringify({
        mode: currentMode,
        imageWorkflow,
        prompt: prompt.value,
        negative: negativeInput?.value || '',
        project: root.querySelector('[data-studio-project]')?.value || '',
        selectedValues,
        outputCount: selectedValues.count || outputCountInput?.value || '1',
      }));
    } catch (_) {}
  }

  function readStudioState() {
    try { return JSON.parse(sessionStorage.getItem(stateKey) || 'null'); } catch (_) { return null; }
  }

  function clearStudioState() { try { sessionStorage.removeItem(stateKey); } catch (_) {} }

  function valueForField(fieldId) {
    return activeConfig?.defaults?.[fieldId] ?? '';
  }

  function setHiddenField(name, value) {
    let input = form.querySelector(`[data-studio-hidden="${CSS.escape(name)}"]`);
    if (!input) {
      input = document.createElement('input'); input.type = 'hidden'; input.dataset.studioHidden = name; form.appendChild(input);
    }
    input.name = name; input.value = value ?? '';
  }

  function fieldOption(fieldId, fallback) {
    const field = (activeConfig?.fields || []).find((item) => item.id === fieldId);
    const options = field?.options || [];
    return options[0]?.value ?? fallback;
  }

  function fieldForKey(key) {
    if (!String(key).startsWith('field:')) return null;
    const fieldId = String(key).slice(6);
    return (activeConfig?.fields || []).find((field) => field.id === fieldId) || null;
  }

  function englishModelName(label, value) {
    const text = String(label || value || '').trim();
    const parenthesized = text.match(/\(([^()]*[A-Za-z][^()]*)\)\s*$/);
    if (parenthesized) return parenthesized[1].trim();
    return /[A-Za-z]/.test(text) ? text : String(value || text || 'مدل هوش مصنوعی');
  }

  function modelSupportsImageWorkflow(item) {
    if (!item || !item.task_type) return false;
    return imageWorkflow === 'image_to_image'
      ? ['image_to_image', 'face_consistency'].includes(String(item.task_type))
        || (String(item.task_type) === 'text_to_image' && item.supports_image_input === true)
      : String(item.task_type) === 'text_to_image';
  }

  function optionsFor(key) {
    if (!activeConfig) return [];
    if (key === 'model') {
      const rawOptions = (activeConfig.model_options || [{value: activeConfig.model, label: activeConfig.model, meta: activeConfig.name}]).map((item) => ({
      ...item,
      value: item.value,
      label: item.label || item.value,
      meta: item.meta || '',
      provider: item.provider || '',
      task_type: item.task_type || '',
      }));
      if (currentMode === 'video' && Array.isArray(config.workflow_models) && config.workflow_models.length > 0) {
        const byValue = new Map(rawOptions.map((item) => [String(item.value), item]));
        const workflowValues = new Set();
        const prioritized = config.workflow_models.map((item) => {
          const value = String(item.value);
          workflowValues.add(value);
          return {
            ...(byValue.get(value) || {}),
            ...item,
            value,
            label: byValue.get(value)?.label || value,
            meta: byValue.get(value)?.meta || '',
          };
        });
        return prioritized.concat(rawOptions.filter((item) => !workflowValues.has(String(item.value))));
      }
      return rawOptions.filter((item) => currentMode !== 'image' || modelSupportsImageWorkflow(item));
    }
    if (key === 'count') return Array.from({length: 6}, (_, index) => {
      const value = String(index + 1);
      return {value, label: `${formatNumber(value)} عدد`, meta: ''};
    });
    const dynamicField = fieldForKey(key);
    if (dynamicField) return (dynamicField.options || []).map((item) => ({value: item.value, label: item.label, meta: item.meta || ''}));
    if (currentMode === 'video') {
      const video = activeConfig.video || {};
      if (key === 'duration') return Array.from({length: 15}, (_, index) => index + 1).map((value) => ({value: String(value), label: `${formatNumber(value)} ثانیه`}));
      if (key === 'ratio') return (video.aspect_ratios || [])
        .filter((value) => String(value) !== '4:3' && String(value) !== 'source')
        .map((value) => ({value, label: formatRatio(value), meta: ratioNames[String(value)] || ''}));
      if (key === 'quality') return (video.resolutions || []).map((value) => ({value, label: qualityLabel(value), meta: value === video.default_resolution ? 'پیشنهادی' : ''}));
      if (key === 'motion') return [{value: '', label: 'بر اساس پرامپت', meta: 'تنظیم خودکار'}].concat((video.motion_presets || []).map((item) => ({value: item.key, label: item.label, meta: item.description})));
    } else {
      const selectedModel = (activeConfig.model_options || []).find((item) => String(item.value) === String(selectedValues.model));
      if (key === 'ratio') {
        const ratios = (activeConfig.output_aspect_ratios || []).filter((value) => {
          const supported = (selectedModel?.supported_aspect_ratios || []).map((item) => String(item).toLowerCase());
          return supported.length === 0 || supported.includes(String(value).toLowerCase());
        });
        return ratios.map((value) => ({value, label: formatRatio(value), meta: ratioNames[String(value)] || ''}));
      }
      if (key === 'quality') {
        const qualities = (activeConfig.output_resolutions || []).filter((value) => {
          const supported = (selectedModel?.supported_resolutions || []).map((item) => String(item).toLowerCase());
          return supported.length === 0 || supported.includes(String(value).toLowerCase());
        });
        return qualities.map((value) => ({value, label: qualityLabel(value), meta: value === activeConfig.default_output_resolution ? 'پیشنهادی' : ''}));
      }
      if (key === 'style') {
        const styleField = (activeConfig.fields || []).find((field) => field.type === 'select' && field.id === 'style') || (activeConfig.fields || []).find((field) => field.type === 'select');
        return (styleField?.options || []).map((item) => ({value: item.value, label: item.label, meta: 'سبک محصول'}));
      }
    }
    return [];
  }

  function defaultValueFor(key, options) {
    if (key === 'model') {
      const preferred = String(activeConfig?.default_model || '');
      return options.some((option) => String(option.value) === preferred) ? preferred : (options[0]?.value ?? '');
    }
    if (key === 'ratio') {
      const preferred = '16:9';
      return options.some((option) => String(option.value) === preferred) ? preferred : (options[0]?.value ?? '');
    }
    if (key === 'count') return '1';
    if (key === 'duration') return String(activeConfig.video?.default_duration ?? options[0]?.value ?? '');
    if (key === 'quality') return currentMode === 'video' ? activeConfig.video?.default_resolution : activeConfig.default_output_resolution;
    if (key === 'motion') return '';
    if (key === 'style') return fieldOption('style', options[0]?.value ?? '');
    const dynamicField = fieldForKey(key);
    if (dynamicField) return dynamicField.value ?? options[0]?.value ?? '';
    return options[0]?.value ?? '';
  }

  function renderDynamicFields() {
    const container = root.querySelector('[data-studio-dynamic-fields]');
    if (!container) return;
    container.innerHTML = '';
    const supportedTypes = ['select', 'radio', 'button_group', 'style_preset'];
    (activeConfig?.fields || []).filter((field) => supportedTypes.includes(field.type) && !['style', 'visual_style', 'background', 'duration', 'theme', 'action', 'actions'].includes(String(field.id).toLowerCase()) && !['اکشن', 'actions', 'action'].includes(String(field.label || '').trim().toLowerCase()) && !field.hidden).forEach((field) => {
      const row = document.createElement('div');
      row.className = 'create-studio-setting-row';
      row.dataset.studioDynamicField = field.id;
      row.innerHTML = `<span><i class="fa-solid fa-sliders"></i><b>${field.label || field.id}</b></span><div class="create-studio-select create-studio-select-menu-field" data-studio-select="field:${field.id}"><button type="button" class="create-studio-select-toggle" data-select-toggle><span data-select-label>انتخاب کنید</span><i class="fa-solid fa-chevron-down"></i></button><div class="create-studio-select-menu create-studio-select-menu--cards" data-select-menu role="listbox"></div><input type="hidden" data-select-input></div>`;
      container.appendChild(row);
    });
  }

  let activePortalSelect = null;
  let portalRepositionHandler = null;
  let portalScrollParents = [];

  function selectMenu(select) {
    return select._studioMenu || select.querySelector('[data-select-menu]');
  }

  function restoreSelectMenu(select) {
    const menu = selectMenu(select);
    if (!menu || !menu.classList.contains('create-studio-select-menu--portal')) return;
    const input = select.querySelector('[data-select-input]');
    if (input) input.before(menu); else select.appendChild(menu);
    menu.classList.remove('create-studio-select-menu--portal');
    menu.classList.remove('create-studio-select-menu--anchored');
    menu.removeAttribute('data-studio-menu-key');
    menu.removeAttribute('data-studio-menu-mode');
    ['width', 'min-width', 'left', 'top', 'right', 'bottom', 'position', 'z-index'].forEach((property) => menu.style.removeProperty(property));
    if (activePortalSelect === select) {
      if (portalRepositionHandler) {
        window.removeEventListener('resize', portalRepositionHandler);
        window.removeEventListener('scroll', portalRepositionHandler, true);
        portalScrollParents.forEach((parent) => parent.removeEventListener('scroll', portalRepositionHandler));
      }
      portalScrollParents = [];
      activePortalSelect = null;
      portalRepositionHandler = null;
    }
  }

  function scrollableAncestors(element) {
    const parents = [];
    let parent = element.parentElement;
    while (parent && parent !== document.body) {
      const styles = window.getComputedStyle(parent);
      if (/(auto|scroll|overlay)/.test(`${styles.overflow} ${styles.overflowX} ${styles.overflowY}`)) parents.push(parent);
      parent = parent.parentElement;
    }
    return parents;
  }

  function positionSelectMenu(select) {
    const menu = selectMenu(select);
    const toggle = select.querySelector('[data-select-toggle]');
    if (!menu || !toggle || !menu.classList.contains('create-studio-select-menu--portal')) return;
    const trigger = toggle.getBoundingClientRect();
    const key = select.dataset.studioSelect;
    const configuredWidth = key === 'model' ? (currentMode === 'video' ? Math.min(440, trigger.width) : 275) : 250;
    const width = Math.min(configuredWidth, Math.max(180, window.innerWidth - 24));
    const menuHeight = menu.getBoundingClientRect().height;
    const alignLeftWithTrigger = (currentMode === 'image' && (key === 'quality' || key === 'count')) || (currentMode === 'video' && (key === 'ratio' || key === 'motion'));
    const preferredLeft = alignLeftWithTrigger ? trigger.left : trigger.right - width;
    const left = Math.max(12, Math.min(preferredLeft, window.innerWidth - width - 12));
    const above = trigger.top - menuHeight - 8;
    const top = above >= 12 ? above : Math.min(window.innerHeight - menuHeight - 12, trigger.bottom + 8);
    const anchoredToTrigger = menu.classList.contains('create-studio-select-menu--anchored');
    const pageX = window.scrollX || document.documentElement.scrollLeft || 0;
    const pageY = window.scrollY || document.documentElement.scrollTop || 0;
    menu.style.width = `${width}px`;
    menu.style.minWidth = `${width}px`;
    menu.style.setProperty('left', `${Math.max(12, left) + (anchoredToTrigger ? pageX : 0)}px`, 'important');
    menu.style.setProperty('top', `${Math.max(12, top) + (anchoredToTrigger ? pageY : 0)}px`, 'important');
  }

  function closeSelect(select) {
    restoreSelectMenu(select);
    select.querySelector('[data-select-toggle]')?.setAttribute('aria-expanded', 'false');
    select.classList.remove('is-open');
  }

  function openSelect(select) {
    root.querySelectorAll('[data-studio-select].is-open').forEach((item) => { if (item !== select) closeSelect(item); });
    const menu = selectMenu(select);
    if (!menu) return;
    select._studioMenu = menu;
    select.classList.add('is-open');
    menu.dataset.studioMenuKey = select.dataset.studioSelect;
    menu.dataset.studioMenuMode = currentMode;
    menu.classList.add('create-studio-select-menu--portal');
    const anchoredToTrigger = window.matchMedia('(max-width: 700px)').matches;
    menu.classList.toggle('create-studio-select-menu--anchored', anchoredToTrigger);
    document.body.appendChild(menu);
    positionSelectMenu(select);
    activePortalSelect = select;
    portalRepositionHandler = () => positionSelectMenu(select);
    window.addEventListener('resize', portalRepositionHandler);
    if (anchoredToTrigger) {
      portalScrollParents = scrollableAncestors(select.querySelector('[data-select-toggle]'));
      portalScrollParents.forEach((parent) => parent.addEventListener('scroll', portalRepositionHandler, {passive: true}));
    } else {
      window.addEventListener('scroll', portalRepositionHandler, true);
    }
  }

  function renderSelectOptions(select, options, selected) {
    const menu = selectMenu(select);
    if (!menu) return;
    menu.innerHTML = '';
    if (select.dataset.studioSelect === 'duration') {
      const value = Number(selected || options[0]?.value || 1);
      const timeline = document.createElement('div');
      timeline.className = 'create-studio-duration-track';
      timeline.innerHTML = `<div class="create-studio-duration-track-head"><strong>زمان ویدیو</strong><b data-duration-value>${formatNumber(value)} ثانیه</b></div><input type="range" min="1" max="15" step="1" value="${value}" aria-label="زمان ویدیو از یک تا پانزده ثانیه"><div class="create-studio-duration-track-scale"><span>۱ ثانیه</span><span>۱۵ ثانیه</span></div>`;
      const slider = timeline.querySelector('input');
      const valueLabel = timeline.querySelector('[data-duration-value]');
      slider.addEventListener('input', () => {
        const nextValue = String(slider.value);
        selectedValues.duration = nextValue;
        valueLabel.textContent = `${formatNumber(nextValue)} ثانیه`;
        const label = select.querySelector('[data-select-label]');
        const input = select.querySelector('[data-select-input]');
        if (label) label.textContent = controlLabel('duration', {label: `${formatNumber(nextValue)} ثانیه`});
        if (input) input.value = nextValue;
        saveStudioState();
        updateCost();
      });
      menu.appendChild(timeline);
      return;
    }
    options.forEach((option) => {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'create-studio-select-option'; button.dataset.value = option.value ?? ''; button.setAttribute('role', 'option');
      if (selected !== null && selected !== undefined && String(option.value ?? '') === String(selected)) button.classList.add('is-selected');
      if (select.dataset.studioSelect === 'ratio') button.innerHTML = `<i class="create-studio-ratio-frame" style="--ratio:${String(option.value || '1:1').replace(':', '/')}"></i><span><b>${option.label}</b><small>${option.meta || ''}</small></span><i class="fa-solid fa-check"></i>`;
      else if (select.dataset.studioSelect === 'model') button.innerHTML = `<span><b>${option.label}</b></span><i class="fa-solid fa-check"></i>`;
      else button.innerHTML = `<span><b>${option.label}</b><small>${option.meta || ''}</small></span><i class="fa-solid fa-check"></i>`;
      button.addEventListener('click', () => chooseSelect(select, option.value ?? ''));
      menu.appendChild(button);
    });
  }

  function controlLabel(key, option) {
    if (!option) return 'انتخاب کنید';
    if (key === 'model') return englishModelName(option.label, option.value);
    if (key === 'count') return `تعداد خروجی: ${option.label}`;
    if (key === 'quality') return `کیفیت خروجی: ${option.label}`;
    if (key === 'motion') return `حرکت دوربین: ${option.label}`;
    if (key === 'duration') return `زمان ویدیو: ${option.label}`;
    if (key === 'ratio') return `نسبت تصویر: ${formatRatio(option.value)}`;
    return option.label || 'انتخاب کنید';
  }

  function chooseSelect(select, value) {
    const key = select.dataset.studioSelect;
    const options = optionsFor(key);
    const isEmptyDefault = value === '' && (key === 'model' || key === 'ratio' || key === 'motion');
    const selected = isEmptyDefault ? null : (options.find((option) => String(option.value ?? '') === String(value ?? '')) || options[0]);
    selectedValues[key] = selected?.value ?? '';
    const label = select.querySelector('[data-select-label]');
    const input = select.querySelector('[data-select-input]');
    const selectedValue = selected?.value ?? '';
    if (label) label.textContent = !selected && key === 'model' ? 'مدل هوش مصنوعی' : !selected && key === 'ratio' ? 'نسبت تصویر' : !selected && key === 'motion' ? 'حرکت دوربین' : controlLabel(key, selected);
    if (input) { input.value = selectedValue; input.setAttribute('value', selectedValue); }
    closeSelect(select);
    renderSelectOptions(select, options, selected ? selected.value : null);
    const restoredInput = select.querySelector('[data-select-input]');
    if (restoredInput) { restoredInput.value = selectedValue; restoredInput.setAttribute('value', selectedValue); }
    if (key === 'count' && outputCountInput) outputCountInput.value = selectedValue || '1';
    if (key === 'model') {
      const selectedModel = options.find((option) => String(option.value) === String(selected?.value));
      const modelName = root.querySelector('[data-studio-model-name]');
      if (modelName) modelName.innerHTML = `${selectedModel?.label || activeConfig.model || 'مدل محصول'} <i class="fa-solid fa-signal"></i>`;
      if (currentMode === 'image') {
        ['ratio', 'quality'].forEach((dependentKey) => {
          const dependent = root.querySelector(`[data-studio-select="${dependentKey}"]`);
          if (!dependent) return;
          const dependentOptions = optionsFor(dependentKey);
          const current = selectedValues[dependentKey];
          const next = dependentOptions.some((option) => String(option.value) === String(current)) ? current : (dependentOptions[0]?.value || '');
          chooseSelect(dependent, next);
        });
        updateImageWorkflowUI();
      }
    }
    saveStudioState();
    updateCost();
  }

  function setupSelects() {
    root.querySelectorAll('[data-studio-select]').forEach((select) => {
      const key = select.dataset.studioSelect;
      const options = optionsFor(key);
      const value = selectedValues[key] ?? defaultValueFor(key, options);
      chooseSelect(select, value);
      const toggle = select.querySelector('[data-select-toggle]');
      toggle.onclick = (event) => {
        event.stopPropagation();
        const open = !select.classList.contains('is-open');
        if (open) { openSelect(select); toggle.setAttribute('aria-expanded', 'true'); }
        else closeSelect(select);
      };
      const row = select.closest('.create-studio-setting-row');
      row?.addEventListener('click', (event) => {
        if (event.target.closest('[data-select-toggle], [data-select-menu], input, button, a')) return;
        toggle.click();
      });
    });
  }

  function updateCost() {
    let value = Number(activeConfig?.cost || 0);
    if (currentMode === 'video') {
      const duration = Number(selectedValues.duration || activeConfig?.video?.default_duration || 0);
      const costs = activeConfig?.video?.credit_costs_by_duration || {};
      if (costs[String(duration)] !== undefined) value = Number(costs[String(duration)]);
      const qualityCosts = activeConfig?.video?.quality_costs || {};
      value += Number(qualityCosts[selectedValues.quality] || 0);
    } else {
      value *= Math.max(1, Math.min(6, Number(normalizeDigits(selectedValues.count || outputCountInput?.value || '1') || 1)));
    }
    if (cost) cost.textContent = faDigits(value);
    updateCreditState(value);
    requestServerQuote();
  }

  function updateCreditState(value) {
    const balance = Number(root.dataset.balance || 0);
    const locked = config.authenticated === true && Number(value || 0) > 0 && balance < Number(value || 0);
    submit?.classList.toggle('is-credit-locked', locked);
    submit?.setAttribute('aria-label', locked ? 'افزایش اعتبار برای ساخت' : 'بساز');
  }

  function updateImageWorkflowUI() {
    const isImageMode = currentMode === 'image';
    const needsReference = imageWorkflow === 'image_to_image';
    const selectedModel = (activeConfig?.model_options || []).find((item) => String(item.value) === String(selectedValues.model));
    const maxUploadFiles = isImageMode && needsReference
      ? Math.max(1, Number(selectedModel?.max_reference_images || config.upload_limits?.max_reference_images || uploadInput?.dataset.imageMaxFiles || 1))
      : 1;
    imageWorkflowTabs?.querySelectorAll('[data-image-workflow]').forEach((button) => {
      const active = button.dataset.imageWorkflow === imageWorkflow;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    if (imageWorkflowTabs) imageWorkflowTabs.hidden = !isImageMode;
    if (imageWorkflowNote) {
      imageWorkflowNote.hidden = !isImageMode;
      imageWorkflowNote.textContent = needsReference
        ? 'یک عکس مرجع واضح اضافه کن تا آن را با توضیحاتت بازطراحی کنیم.'
        : 'برای شروع، ایده‌ات را بنویس؛ تصویر ورودی لازم نیست.';
    }
    if (uploadInput) {
      uploadInput.multiple = maxUploadFiles > 1;
      uploadInput.dataset.maxFiles = String(maxUploadFiles);
      uploadInput.accept = isImageMode ? 'image/png,image/jpeg,image/webp,image/avif' : 'image/png,image/jpeg,image/webp,video/mp4';
    }
    if (uploadZone) {
      uploadZone.hidden = !isImageMode || !needsReference;
      uploadZone.dataset.workflowDisabled = isImageMode && needsReference ? 'false' : 'true';
      const title = uploadZone.querySelector('[data-upload-title]');
      const help = uploadZone.querySelector('[data-upload-help]');
      if (title) title.textContent = isImageMode && needsReference ? 'افزودن تصویر مرجع' : 'فایل ورودی لازم نیست';
      if (help) help.textContent = isImageMode && needsReference ? `JPG، PNG، WebP یا AVIF · تا ${faDigits(maxUploadFiles)} تصویر برای این مدل` : 'برای متن به عکس فقط توضیحات را بنویس';
      if (!isImageMode || !needsReference) {
        selectedUploadFiles = [];
        uploadInput.value = '';
        if (uploadFile) uploadFile.hidden = true;
      }
    }
  }

  function setImageWorkflow(nextWorkflow) {
    imageWorkflow = nextWorkflow === 'image_to_image' ? 'image_to_image' : 'text_to_image';
    hideError();
    selectedValues = {};
    updateImageWorkflowUI();
    setupSelects();
    updateCost();
    saveStudioState();
  }

  function requestServerQuote() {
    if (!config.quote_url) return;
    if (quoteTimer) window.clearTimeout(quoteTimer);
    const sequence = ++quoteSequence;
    quoteTimer = window.setTimeout(async () => {
      const selectedModel = selectedValues.model ? optionsFor('model').find((option) => String(option.value) === String(selectedValues.model)) : null;
      const params = new URLSearchParams({
        mode: currentMode,
        model: selectedModel?.value || '',
        provider: selectedModel?.provider || '',
        workflow: currentMode === 'image' ? imageWorkflow : '',
        resolution: selectedValues.quality || '',
        aspect_ratio: selectedValues.ratio || '',
        duration: selectedValues.duration || '',
        count: currentMode === 'image' ? normalizeDigits(selectedValues.count || outputCountInput?.value || '1') || '1' : '1',
      });
      try {
        const response = await fetch(`${config.quote_url}?${params.toString()}`, {headers: {'Accept': 'application/json'}});
        const payload = await response.json();
        if (sequence !== quoteSequence) return;
        if (!payload.cost_known || payload.credits === null || payload.credits === undefined) {
          if (cost) cost.textContent = '—';
          return;
        }
        if (cost) cost.textContent = faDigits(payload.credits);
        updateCreditState(Number(payload.credits || 0));
      } catch (_) {}
    }, 220);
  }

  function updateModeUI() {
    activeConfig = config[currentMode] || {};
    root.dataset.mode = currentMode;
    modeTabs.forEach((button) => { const active = button.dataset.studioMode === currentMode; button.classList.toggle('is-active', active); button.setAttribute('aria-selected', active ? 'true' : 'false'); });
    root.querySelectorAll('[data-studio-video-only]').forEach((item) => { item.hidden = currentMode !== 'video'; });
    root.querySelectorAll('[data-studio-image-only]').forEach((item) => { item.hidden = currentMode !== 'image'; });
    videoContent.hidden = currentMode !== 'video'; imageContent.hidden = currentMode !== 'image';
    root.querySelector('[data-studio-model-title]').textContent = currentMode === 'video' ? 'استودیوی ویدیو' : 'استودیوی عکس';
    root.querySelector('[data-studio-model-subtitle]').textContent = currentMode === 'video' ? 'ساخت ویدیو با مدل واقعی محصول' : 'ساخت عکس با مدل واقعی محصول';
    root.querySelector('[data-studio-model-name]').innerHTML = `${activeConfig.model || 'مدل محصول'} <i class="fa-solid fa-signal"></i>`;
    root.querySelector('[data-studio-stage-kicker]').textContent = currentMode === 'video' ? 'استودیوی ساخت ویدیو' : 'استودیوی ساخت عکس';
    root.querySelector('[data-studio-stage-title]').textContent = currentMode === 'video' ? 'ویدیو را با چند کلمه بساز' : 'عکس را با چند کلمه بساز';
    root.querySelector('[data-studio-stage-subtitle]').textContent = currentMode === 'video' ? 'ایده‌ات را بنویس، تنظیمات را انتخاب کن و ساخت واقعی را به وطن بسپار.' : 'ایده‌ات را بنویس، تنظیمات را انتخاب کن و عکس واقعی‌ات را در گالری تحویل بگیر.';
    prompt.placeholder = currentMode === 'video' ? 'مثلاً: حرکت آرام دوربین در خیابان بارانی تهران با نورهای نئون...' : 'مثلاً: یک پرتره‌ی سینمایی با نور پنجره و پس‌زمینه‌ی مینیمال...';
    uploadInput.accept = currentMode === 'video' ? 'image/png,image/jpeg,image/webp,video/mp4' : 'image/png,image/jpeg,image/webp';
    root.querySelector('[data-upload-title]').textContent = currentMode === 'video' ? 'افزودن منبع' : 'افزودن تصویر مرجع';
    root.querySelector('[data-upload-help]').textContent = currentMode === 'video' ? 'تصویر یا ویدیو' : 'تصویر مرجع برای حفظ شباهت';
    if (outputCountInput && currentMode === 'image' && !outputCountInput.value) outputCountInput.value = '1';
    selectedValues = {};
    renderDynamicFields();
    setupSelects(); updateCost();
    updateImageWorkflowUI();
    if (outputVideo) outputVideo.hidden = currentMode !== 'video'; if (outputImage) outputImage.hidden = currentMode === 'video';
    if (videoPlay) videoPlay.hidden = currentMode !== 'video' || outputVideo.hidden;
  }

  function setMode(mode) { currentMode = mode === 'image' ? 'image' : 'video'; hideError(); updateModeUI(); saveStudioState(); }

  function updatePromptCount() { promptCount.textContent = faDigits(prompt.value.length); }
  function stopProgress() { if (progressTimer) window.clearInterval(progressTimer); progressTimer = null; }
  function setProgress(value) {
    const rounded = Math.max(0, Math.min(100, Math.round(value)));
    progressBar.style.width = `${rounded}%`;
    progressBar.parentElement?.setAttribute('aria-valuenow', String(rounded));
    if (progressValue) progressValue.textContent = `${faDigits(rounded)}٪`;
  }
  function startProgress(title) { stopProgress(); progress.hidden = false; result.hidden = true; videoContent.hidden = true; imageContent.hidden = true; progressTitle.textContent = title; progressText.textContent = currentMode === 'video' ? 'در حال آماده‌سازی ورودی‌ها و ارسال درخواست به مدل...' : 'در حال بررسی ورودی‌ها و آماده‌سازی تصویر...'; setProgress(8); let value = 8; progressTimer = window.setInterval(() => { value = Math.min(88, value + (value < 55 ? 3 : 1)); setProgress(value); }, 900); }
  function finishProgress() { stopProgress(); setProgress(100); window.setTimeout(() => { progress.hidden = true; }, 350); }

  function revealGeneratedResult() {
    if (!result) return;
    result.hidden = false;
    result.removeAttribute('hidden');
    window.requestAnimationFrame(() => {
      result.scrollIntoView({behavior: 'smooth', block: 'center', inline: 'nearest'});
    });
  }

  function renderCreditSummary(payload) {
    if (!creditSummary || !payload) return;
    const reserved = Math.max(0, Number(payload.credits_reserved || 0));
    const settled = Math.max(0, Number(payload.credits_settled || 0));
    const refunded = Math.max(0, Number(payload.credits_refunded || 0));
    creditSummary.querySelector('[data-studio-credits-reserved]').textContent = faDigits(reserved);
    creditSummary.querySelector('[data-studio-credits-settled]').textContent = faDigits(settled);
    creditSummary.querySelector('[data-studio-credits-refunded]').textContent = faDigits(refunded);
    const refundItem = creditSummary.querySelector('[data-studio-refund-item]');
    if (refundItem) refundItem.hidden = refunded < 1;
    creditSummary.hidden = false;
  }

  function imageUrlFromPayload(image) {
    if (typeof image === 'string') return image.trim();
    if (!image || typeof image !== 'object') return '';
    const nestedUrl = image.image_url && typeof image.image_url === 'object' ? image.image_url.url : image.image_url;
    return String(image.url || nestedUrl || image.src || '').trim();
  }

  function firstImageUrl(payload) {
    const listedImages = Array.isArray(payload?.images) ? payload.images : [];
    const listedUrl = listedImages.map(imageUrlFromPayload).find(Boolean);
    return listedUrl || imageUrlFromPayload(payload?.image_url);
  }

  function appendDefaults(data) {
    const uploadFiles = selectedUploadFiles.length ? selectedUploadFiles : [...(uploadInput?.files || [])];
    Object.entries(activeConfig.defaults || {}).forEach(([key, value]) => data.append(`fields[${key}]`, value));
    if (currentMode === 'video') {
      data.set('video[duration]', selectedValues.duration || activeConfig.video.default_duration);
      data.set('video[aspect_ratio]', selectedValues.ratio || activeConfig.video.default_aspect_ratio);
      data.set('video[resolution]', selectedValues.quality || activeConfig.video.default_resolution);
      data.set('video[motion_preset]', selectedValues.motion || '');
      data.set('studio_mode', '1');
      data.set('rights_confirmed', '1'); data.set('video[generate_audio]', '0');
      data.delete('studio_prompt'); data.append('prompt', prompt.value.trim());
      data.append('negative_prompt', negativeInput?.value?.trim() || '');
    } else {
      data.set('studio_workflow', imageWorkflow);
      data.set('output[aspect_ratio]', selectedValues.ratio || activeConfig.default_output_aspect_ratio || '1:1');
      data.set('output[quality]', selectedValues.quality || activeConfig.default_output_resolution || '720');
      data.set('output[main_quality]', activeConfig.default_main_quality || 'standard');
      data.set('output[count]', normalizeDigits(selectedValues.count || outputCountInput?.value || '1') || '1');
      data.set('identity_preservation', imageWorkflow === 'image_to_image' && activeConfig.reference_upload_key && uploadFiles.length > 0 ? '1' : '0');
    }
    data.set('studio_mode', '1');
    Object.entries(selectedValues).forEach(([key, value]) => {
      if (key.startsWith('field:')) data.set(`fields[${key.slice(6)}]`, value ?? '');
    });
    if (currentMode === 'video' && uploadInput.files[0]) data.append('source_image', uploadInput.files[0]);
    if (currentMode === 'image' && uploadFiles.length > 0 && activeConfig.reference_upload_key) {
      const referenceField = (activeConfig.fields || []).find((field) => String(field.id) === String(activeConfig.reference_upload_key));
      const uploadName = referenceField?.type === 'multi_image' || imageWorkflow === 'image_to_image'
        ? `uploads[${activeConfig.reference_upload_key}][]`
        : `uploads[${activeConfig.reference_upload_key}]`;
      uploadFiles.forEach((file) => data.append(uploadName, file));
    }
    const selectedModel = selectedValues.model ? optionsFor('model').find((option) => String(option.value) === String(selectedValues.model)) : null;
    if (selectedModel?.value) {
      data.set('studio_model', selectedModel.value);
      if (selectedModel.provider) data.set('studio_provider', selectedModel.provider);
    }
    if (currentMode === 'image') data.set('studio_prompt', prompt.value.trim());
    data.set('studio_negative_prompt', negativeInput?.value?.trim() || '');
    return data;
  }

  async function readPayload(response) { const text = await response.text(); let payload = {}; try { payload = text ? JSON.parse(text) : {}; } catch (_) {} if (!response.ok || !payload.success) { const error = new Error(payload.message || Object.values(payload.errors || {}).flat()[0] || 'ساخت خروجی انجام نشد.'); error.payload = payload; throw error; } return payload; }

  async function pollVideo(statusUrl) {
    for (let attempt = 0; attempt < 160; attempt += 1) {
      await new Promise((resolve) => { pollTimer = window.setTimeout(resolve, 2500); });
      const response = await fetch(statusUrl, {headers: {'Accept': 'application/json'}}); const payload = await response.json();
      if (payload.status === 'completed' && payload.video_url) return payload.video_url;
      if (['failed', 'canceled'].includes(payload.status)) {
        if (payload.credits_returned > 0) window.showCreditsReturnedModal?.(payload.credits_returned);
        throw new Error(payload.error_message || 'ساخت ویدیو ناموفق بود.');
      }
      progressText.textContent = payload.status === 'queued' ? 'درخواست در صف ساخت قرار دارد...' : 'مدل هوش مصنوعی در حال ساخت خروجی است...';
    }
    throw new Error('ساخت ویدیو بیشتر از زمان معمول طول کشید؛ لطفاً بعداً وضعیت گالری را بررسی کنید.');
  }

  async function generate() {
    hideError();
    if (!prompt.value.trim()) { showError('ابتدا توضیحات ساخت را وارد کنید.'); prompt.focus(); return; }
    if (config.authenticated !== true) { saveStudioState(); window.location.href = config.login_url; return; }
    if (currentMode === 'image' && imageWorkflow === 'image_to_image' && selectedUploadFiles.length === 0 && !uploadInput.files[0]) { showError('برای حالت عکس به عکس، حداقل یک تصویر مرجع واضح بارگذاری کنید.'); uploadZone.focus(); return; }
    const selectedModel = optionsFor('model').find((option) => String(option.value) === String(selectedValues.model));
    const modelFileLimit = Number(selectedModel?.max_reference_images || config.upload_limits?.max_reference_images || 1);
    if (currentMode === 'image' && imageWorkflow === 'image_to_image' && selectedUploadFiles.length > modelFileLimit) { showError(`مدل انتخاب‌شده حداکثر ${faDigits(modelFileLimit)} تصویر مرجع می‌پذیرد.`); return; }
    const requiredCredits = Number(normalizeDigits(cost?.textContent || 0));
    const balance = Number(root.dataset.balance || 0);
    if (requiredCredits > 0 && balance < requiredCredits) {
      window.showTokenShortageModal?.({ required: requiredCredits, balance });
      return;
    }
    submit.disabled = true; submit.setAttribute('aria-busy', 'true'); submitLabel.textContent = 'در حال ساخت'; startProgress(currentMode === 'video' ? 'در حال ساخت ویدیو' : 'در حال ساخت عکس');
    try {
      const url = activeConfig.generate_url || `${window.location.origin}/app/create/${activeConfig.route_slug}/generate`;
      const response = await fetch(url, {method: 'POST', headers: {'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content || '', 'Accept': 'application/json'}, body: appendDefaults(new FormData(form))});
      const payload = await readPayload(response);
      if (payload.credits_returned > 0) window.showCreditsReturnedModal?.(payload.credits_returned);
      if (currentMode === 'video') {
        const videoUrl = await pollVideo(payload.status_url); outputVideo.src = videoUrl; outputVideo.hidden = false; outputImage.hidden = true; outputVideo.controls = false; videoPlay.hidden = false; outputVideo.load();
      } else {
        const first = firstImageUrl(payload); if (!first) throw new Error('لینک خروجی تصویر از سرویس دریافت نشد.'); outputImage.src = first; outputImage.hidden = false; outputVideo.hidden = true; videoPlay.hidden = true;
      }
      renderCreditSummary(payload);
      finishProgress(); revealGeneratedResult(); submitLabel.textContent = 'دوباره بساز';
    } catch (error) {
      stopProgress();
      setProgress(0);
      progress.hidden = true;
      videoContent.hidden = currentMode !== 'video';
      imageContent.hidden = currentMode !== 'image';
      submitLabel.textContent = 'بساز';
      showError(error.message || 'ارتباط با سرویس ساخت برقرار نشد.');
      if (error.payload?.credits_returned > 0) window.showCreditsReturnedModal?.(error.payload.credits_returned);
    }
    finally {
      submit.disabled = false;
      submit.removeAttribute('aria-busy');
    }
  }

  outputImage?.addEventListener('error', () => {
    outputImage.hidden = true;
    result.hidden = true;
    showError('تصویر ساخته شد اما بارگذاری آن کامل نشد؛ لطفاً دوباره تلاش کنید.');
  });

  modeTabs.forEach((tab) => tab.addEventListener('click', () => setMode(tab.dataset.studioMode)));
  imageWorkflowTabs?.querySelectorAll('[data-image-workflow]').forEach((tab) => tab.addEventListener('click', () => setImageWorkflow(tab.dataset.imageWorkflow)));
  prompt.addEventListener('input', updatePromptCount);
  negativeInput?.addEventListener('input', () => root.querySelector('[data-studio-negative]').value = negativeInput.value);
  root.querySelector('[data-studio-improve]').addEventListener('click', () => { const suffix = currentMode === 'video' ? ' حرکت نرم دوربین، ریتم سینمایی و نورپردازی طبیعی' : ' ترکیب‌بندی حرفه‌ای، نورپردازی طبیعی و جزئیات دقیق'; prompt.value = prompt.value.trim() ? `${prompt.value.trim()}،${suffix}` : (currentMode === 'video' ? 'یک نمای سینمایی از تهران در شب با باران و نورهای نئون' : 'یک پرتره ادیتوریال با نور پنجره و پس‌زمینه مینیمال') + suffix; updatePromptCount(); prompt.focus(); });
  // چون ورودی فایل داخل ناحیه‌ی انتخاب قرار دارد، فعال‌سازی پیش‌فرض ناحیه و
  // کلیک دستی هم‌زمان روی input در بعضی مرورگرها پنجره‌ی انتخاب فایل را
  // دوبار باز می‌کند و باعث می‌شود اصلاً باز نشود. فعال‌سازی را یک‌بار و با
  // جلوگیری از رفتار پیش‌فرض انجام می‌دهیم.
  uploadZone.addEventListener('click', (event) => {
    if (event.target === uploadInput) return;
    event.preventDefault();
    uploadInput.click();
  });
  uploadZone.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); uploadInput.click(); } });
  uploadInput.addEventListener('change', () => {
    const maxFiles = Number(uploadInput.dataset.maxFiles || 1);
    const files = [...uploadInput.files].slice(0, maxFiles);
    const allowedImageTypes = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/avif']);
    const maxImageBytes = Number(config.upload_limits?.max_image_bytes || 12582912);
    const invalid = currentMode === 'image' && files.find((file) => !allowedImageTypes.has(file.type) || file.size > maxImageBytes);
    if (invalid) {
      selectedUploadFiles = [];
      uploadInput.value = '';
      uploadFile.hidden = true;
      uploadFile.textContent = '';
      showError(`فرمت یا حجم فایل «${invalid.name}» معتبر نیست.`);
      return;
    }
    selectedUploadFiles = files;
    if (uploadInput.files.length > maxFiles) showError(`حداکثر ${faDigits(maxFiles)} تصویر قابل انتخاب است.`);
    if (!files.length) {
      uploadFile.hidden = true;
      uploadFile.textContent = '';
      return;
    }
    uploadFile.hidden = false;
    uploadFile.textContent = files.length > 1 ? `${faDigits(files.length)} تصویر انتخاب شد` : files[0].name;
  });
  submit.addEventListener('click', generate); root.querySelector('[data-studio-regenerate]').addEventListener('click', generate);
  root.querySelector('[data-studio-error-close]').addEventListener('click', hideError);
  document.addEventListener('click', (event) => {
    if (!event.target.closest('[data-studio-select], [data-select-menu]')) root.querySelectorAll('[data-studio-select].is-open').forEach(closeSelect);
    if (helpDialog && !helpDialog.hidden && !event.target.closest('.create-studio-help-dialog, [data-studio-help]')) closeHelp();
  });
  const helpDialog = root.querySelector('[data-studio-help-dialog]');
  const closeHelp = () => { if (helpDialog) helpDialog.hidden = true; };
  root.querySelector('[data-studio-help]').addEventListener('click', () => { if (helpDialog) helpDialog.hidden = false; });
  root.querySelector('[data-studio-help-close]').addEventListener('click', closeHelp);
  helpDialog?.addEventListener('click', (event) => { if (event.target === helpDialog) closeHelp(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeHelp(); });
  root.querySelector('[data-studio-download]').addEventListener('click', () => { const media = currentMode === 'video' ? outputVideo : outputImage; if (!media?.src) return; const link = document.createElement('a'); link.href = media.src; link.download = currentMode === 'video' ? 'vatan-ai-video.mp4' : 'vatan-ai-image.png'; link.target = '_blank'; link.click(); });
  root.querySelector('[data-studio-share]').addEventListener('click', async () => { const media = currentMode === 'video' ? outputVideo : outputImage; if (!media?.src) return; try { await navigator.clipboard.writeText(media.src); showError('لینک خروجی کپی شد.'); } catch (_) { showError('کپی لینک در این مرورگر ممکن نیست؛ از گزینه دانلود استفاده کنید.'); } });
  const updateOutputVideoButton = () => {
    if (!videoPlay || !outputVideo) return;
    videoPlay.hidden = outputVideo.hidden || !outputVideo.paused;
    videoPlay.setAttribute('aria-label', outputVideo.paused ? 'پخش ویدیوی خروجی' : 'توقف ویدیوی خروجی');
  };
  videoPlay.addEventListener('click', () => {
    if (!outputVideo.src) return;
    outputVideo.controls = true;
    outputVideo.play().catch(() => {});
  });
  outputVideo.addEventListener('play', updateOutputVideoButton);
  outputVideo.addEventListener('pause', updateOutputVideoButton);
  outputVideo.addEventListener('ended', updateOutputVideoButton);
  window.addEventListener('beforeunload', () => { if (pollTimer) window.clearTimeout(pollTimer); stopProgress(); });

  const savedState = readStudioState();
  updatePromptCount();
  if (savedState?.imageWorkflow === 'image_to_image') imageWorkflow = 'image_to_image';
  setMode(savedState?.mode === 'video' ? 'video' : 'image');
  if (savedState) {
    prompt.value = String(savedState.prompt || '');
    if (negativeInput) negativeInput.value = String(savedState.negative || '');
    const projectInput = root.querySelector('[data-studio-project]');
    if (projectInput) projectInput.value = String(savedState.project || '');
    if (outputCountInput) outputCountInput.value = normalizeDigits(savedState.outputCount || '1') || '1';
    selectedValues = {...(savedState.selectedValues || {})};
    if (savedState.mode === 'video' && ['kwaivgi/kling-v2.5-turbo', 'runwayml/gen-4-turbo', 'luma/dream-machine-2'].includes(String(selectedValues.model || ''))) {
      delete selectedValues.model;
    }
    if (!selectedValues.count) selectedValues.count = String(Math.max(1, Math.min(6, Number(normalizeDigits(savedState.outputCount || '1') || 1))));
    setupSelects();
    updatePromptCount();
    clearStudioState();
  }
}());
