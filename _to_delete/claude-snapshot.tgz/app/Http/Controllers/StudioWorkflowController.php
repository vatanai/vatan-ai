<?php

namespace App\Http\Controllers;

use App\Models\AiModel;
use App\Models\Product;
use App\Models\UserUpload;
use App\Services\AiProviderCredentials;
use App\Services\ProductBuildSchema;
use App\Services\StudioCostService;
use App\Services\VideoGenerationService;
use App\Services\VideoModelSchemaService;
use App\Services\VideoProductConfigService;
use App\Services\UserStorageService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class StudioWorkflowController extends Controller
{
    public function show(ProductBuildSchema $schema, VideoModelSchemaService $modelSchemas)
    {
        $data = app(ProductGenerateController::class)->studioViewData($schema);
        $data['experimental'] = true;
        $data['studioConfig']['workflow_generate_url'] = route('app.create.studio.workflows.generate');
        $data['studioConfig']['workflow_quote_url'] = route('app.create.studio.workflows.quote');
        $data['studioConfig']['upload_limits'] = [
            'max_reference_images' => $this->infrastructureImageLimit(),
            'max_image_bytes' => max(1024, (int) config('studio.max_image_kilobytes', 12288)) * 1024,
            'max_video_bytes' => 100 * 1024 * 1024,
        ];
        $data['studioConfig']['workflow_models'] = AiModel::query()
            ->where('is_active', true)
            ->where('output_modality', 'video')
            // مسیر ساخت ویدیو در استودیو عمداً تک‌پروایدر است تا هیچ گزینه‌ای
            // خارج از قرارداد OpenRouter به صف ارسال نشود.
            ->where('provider', 'openrouter')
            ->whereNotNull('capability_config')
            ->whereIn('task_type', ['text_to_video', 'image_to_video', 'face_animation'])
            ->whereNotNull('openrouter_model_id')
            ->where('openrouter_model_id', '<>', '')
            ->get()
            ->sortBy(function (AiModel $model): array {
                $providerPriority = AiModel::STUDIO_PROVIDER_PRIORITY[$model->provider] ?? 99;
                $priority = array_search($model->openrouter_model_id, AiModel::STUDIO_VIDEO_MODEL_PRIORITY, true);
                $taskOrder = array_search($model->task_type, ['text_to_video', 'image_to_video', 'video_to_video', 'face_animation'], true);
                return [$providerPriority, $priority === false ? 1000 : $priority, $taskOrder === false ? 100 : $taskOrder, $model->id];
            })
            ->values()
            ->map(function (AiModel $model) use ($modelSchemas): array {
                $summary = $modelSchemas->summarize($model);
                $capabilities = (array) ($model->capability_config ?? []);
                $maxImages = max(1, min($this->infrastructureImageLimit(), (int) data_get(
                    $capabilities,
                    'max_reference_images',
                    data_get($capabilities, 'max_images', 1),
                )));

                return [
                    'value' => (string) $model->openrouter_model_id,
                    'provider' => (string) $model->provider,
                    'task_type' => (string) $model->task_type,
                    'supports_text' => $model->task_type === 'text_to_video' || data_get($model->capability_config, 'supports_text_to_video') === true,
                    'supports_image' => (bool) $summary['supports_image'],
                    'supports_video' => (bool) $summary['supports_video'],
                    'supports_multiple_images' => $maxImages > 1,
                    'max_images' => $maxImages,
                    'supported_durations' => array_values(array_map('strval', data_get($capabilities, 'supported_durations', $summary['durations'] ?? []))),
                    'supported_resolutions' => array_values(array_map('strval', data_get($capabilities, 'supported_resolutions', $summary['resolutions'] ?? []))),
                    'supported_aspect_ratios' => array_values(array_map('strval', data_get($capabilities, 'supported_aspect_ratios', $summary['aspect_ratios'] ?? []))),
                ];
            })
            ->values()
            ->all();

        return response()
            ->view('app.create-studio', $data)
            ->header('Cache-Control', 'no-store, private')
            ->header('Pragma', 'no-cache')
            ->header('Expires', '0');
    }

    public function quote(Request $request, StudioCostService $studioCosts): \Illuminate\Http\JsonResponse
    {
        $workflow = $this->workflow($request->query('workflow'));
        $product = $this->videoProduct();
        $model = $this->selectedModel($request, $product, $workflow);
        $quote = $studioCosts->quote($product, [
            'media_type' => 'video',
            'workflow' => $workflow,
            'resolution' => (string) $request->query('resolution', '720p'),
            'aspect_ratio' => (string) $request->query('aspect_ratio', '16:9'),
            'duration' => max(1, min(15, (int) $request->query('duration', 4))),
            'count' => 1,
        ], $model);

        return response()->json($quote + [
            'workflow' => $workflow,
            'input_count' => max(0, min($this->maxReferenceImages($model), (int) $request->query('input_count', 0))),
        ]);
    }

    public function generate(Request $request, VideoGenerationService $videos, VideoModelSchemaService $modelSchemas): \Illuminate\Http\JsonResponse
    {
        $correlationId = (string) Str::uuid();
        Log::withContext([
            'correlation_id' => $correlationId,
            'user_id' => $request->user()?->id,
            'studio_operation' => 'video_generation',
        ]);
        $workflow = $this->workflow($request->input('workflow'));
        $product = $this->videoProduct();
        $model = $this->selectedModel($request, $product, $workflow);
        $isImageWorkflow = in_array($workflow, ['image_to_video', 'image_sequence_to_video'], true);
        $isVideoWorkflow = $workflow === 'video_to_video';
        $maxImages = $this->maxReferenceImages($model);
        if ($workflow === 'image_sequence_to_video' && $maxImages < 2) {
            throw ValidationException::withMessages(['studio_model' => 'مدل انتخاب‌شده از توالی چند تصویر پشتیبانی نمی‌کند.']);
        }
        $maxImageKilobytes = max(1024, (int) config('studio.max_image_kilobytes', 12288));

        $request->validate([
            'workflow' => ['required', Rule::in(['text_to_video', 'image_to_video', 'image_sequence_to_video', 'video_to_video'])],
            'prompt' => ['required', 'string', 'max:5000'],
            'video.duration' => ['required', 'integer', 'min:1', 'max:15'],
            'video.aspect_ratio' => ['required', Rule::in(VideoProductConfigService::STUDIO_ASPECT_RATIOS)],
            'video.resolution' => ['required', Rule::in(VideoProductConfigService::RESOLUTIONS)],
            'video.motion_preset' => ['nullable', 'string', 'max:80'],
            'source_images' => [$isImageWorkflow ? 'required' : 'nullable', 'array', 'min:' . ($workflow === 'image_sequence_to_video' ? 2 : 1), 'max:' . $maxImages],
            'source_images.*' => ['image', 'mimes:jpeg,jpg,png,webp,avif', 'max:' . $maxImageKilobytes],
            'source_video' => [$isVideoWorkflow ? 'required' : 'nullable', 'file', 'mimes:mp4,webm,mov', 'max:102400'],
            'rights_confirmed' => ['accepted'],
        ]);
        $user = $request->user();
        abort_unless($user, 401);
        $incomingFiles = collect((array) $request->file('source_images', []));
        if ($request->file('source_video')) {
            $incomingFiles->push($request->file('source_video'));
        }
        $incomingBytes = $incomingFiles->filter()->sum(fn ($file): int => (int) $file->getSize());
        $storage = app(UserStorageService::class);
        $storageCheck = $storage->check($user, $incomingBytes);
        if (! $storageCheck['allowed']) {
            throw ValidationException::withMessages(['storage' => $storage->blockMessage($storageCheck)]);
        }
        $this->ensureWorkflowInputSupport($model, $workflow, $modelSchemas);
        $this->ensureSupportedOptions($model, $request, $modelSchemas);

        $runner = clone $product;
        $runner->primary_model = $model->openrouter_model_id;
        $runner->ai_provider = $model->provider;
        [$fallbackModels, $fallbackProviders] = $this->fallbackRoutes($model, $workflow, $request, $modelSchemas);
        $runner->fallback_models = $fallbackModels;
        $runner->fallback_model_providers = $fallbackProviders;
        $providerOptions = (array) $runner->provider_options;
        $videoConfig = $runner->videoConfiguration();
        $videoConfig['workflow'] = $isImageWorkflow ? 'image_to_video' : $workflow;
        $videoConfig['durations'] = range(1, 15);
        $videoConfig['preserve_source_aspect_ratio'] = false;
        $videoConfig['resolutions'] = VideoProductConfigService::RESOLUTIONS;
        $videoConfig['aspect_ratios'] = VideoProductConfigService::STUDIO_ASPECT_RATIOS;
        $providerOptions['video'] = $videoConfig;
        $runner->provider_options = $providerOptions;

        $imageUrls = [];
        $imagePaths = [];
        $uploadIds = [];
        foreach ((array) $request->file('source_images', []) as $file) {
            $path = $file->store('uploads/video-inputs/images', 'public');
            $imagePaths[] = $path;
            $imageUrls[] = asset('storage/' . ltrim($path, '/'));
            $uploadIds[] = UserUpload::create([
                'user_id' => $user->id,
                'file_path' => $path,
                'size' => $file->getSize(),
                'mime_type' => $file->getMimeType(),
                'expires_at' => now()->addDays(UserStorageService::INPUT_RETENTION_DAYS),
            ])->id;
        }

        $sourceVideoUrl = null;
        $sourceVideoPath = null;
        if ($request->hasFile('source_video')) {
            $file = $request->file('source_video');
            $sourceVideoPath = $file->store('uploads/video-inputs/videos', 'public');
            $sourceVideoUrl = asset('storage/' . $sourceVideoPath);
            $uploadIds[] = UserUpload::create([
                'user_id' => $user->id,
                'file_path' => $sourceVideoPath,
                'size' => $file->getSize(),
                'mime_type' => $file->getMimeType(),
                'expires_at' => now()->addDays(UserStorageService::INPUT_RETENTION_DAYS),
            ])->id;
        }

        $storage->forgetProfileSnapshot($user);

        try {
            $generation = $videos->start($runner, $request->user(), [
                'prompt' => trim((string) $request->input('prompt')),
                'negative_prompt' => '',
                'fields' => [],
                'duration' => (int) $request->input('video.duration'),
                'aspect_ratio' => (string) $request->input('video.aspect_ratio'),
                'preserve_source_aspect_ratio' => false,
                'resolution' => (string) $request->input('video.resolution'),
                'motion_preset' => (string) $request->input('video.motion_preset', ''),
                'generate_audio' => false,
                'source_image_data' => $imageUrls[0] ?? null,
                'source_image_data_list' => $imageUrls,
                'source_upload_path' => $imagePaths[0] ?? null,
                'source_upload_paths' => $imagePaths,
                'temporary_upload_paths' => array_values(array_filter(array_merge($imagePaths, [$sourceVideoPath]))),
                'source_video_path' => $sourceVideoPath,
                'source_video_url' => $sourceVideoUrl,
                'workflow' => $workflow,
                'reference_mode' => $workflow === 'image_sequence_to_video' || count($imageUrls) > 1 ? 'input_references' : null,
                'studio_mode' => true,
                'idempotency_key' => (string) $request->header('Idempotency-Key', $request->input('idempotency_key', '')),
                'correlation_id' => $correlationId,
            ]);

            if ($generation->getAttribute('was_idempotent_duplicate')) {
                foreach ($imagePaths as $path) Storage::disk('public')->delete($path);
                if ($sourceVideoPath) Storage::disk('public')->delete($sourceVideoPath);
                UserUpload::query()->whereIn('id', $uploadIds)->delete();
            } else {
                UserUpload::query()->whereIn('id', $uploadIds)->update(['status' => 'attached']);
            }

            Log::info('Studio video generation accepted', [
                'generation_id' => $generation->id,
                'workflow' => $workflow,
                'model' => $model->openrouter_model_id,
            ]);

            return response()->json([
                'success' => true,
                'status' => $generation->status,
                'message' => 'درخواست وارد صف ساخت شد.',
                'error_code' => null,
                'retryable' => false,
                'generation_id' => $generation->id,
                'credits_reserved' => (int) $generation->credits_reserved,
                'credits_settled' => (int) $generation->credits_settled,
                'credits_refunded' => (int) $generation->credits_refunded,
                'poll_url' => route('app.video-generation.status', $generation),
                'status_url' => route('app.video-generation.status', $generation),
            ], 202)->header('X-Correlation-ID', $correlationId);
        } catch (ValidationException $exception) {
            foreach ($imagePaths as $path) Storage::disk('public')->delete($path);
            if ($sourceVideoPath) Storage::disk('public')->delete($sourceVideoPath);
            UserUpload::query()->whereIn('id', $uploadIds)->delete();
            throw $exception;
        } catch (\Throwable $exception) {
            foreach ($imagePaths as $path) Storage::disk('public')->delete($path);
            if ($sourceVideoPath) Storage::disk('public')->delete($sourceVideoPath);
            UserUpload::query()->whereIn('id', $uploadIds)->update(['status' => 'failed', 'error_message' => 'ثبت درخواست ساخت کامل نشد.']);
            report($exception);

            $exceptionMessage = strtolower($exception->getMessage());
            if (str_contains($exceptionMessage, 'inputsensitivecontentdetected')
                || str_contains($exceptionMessage, 'real person')
                || str_contains($exceptionMessage, 'privacyinformation')) {
                return response()->json([
                    'success' => false,
                    'status' => 'failed',
                    'message' => 'پروایدر به‌دلیل سیاست ایمنی، تصویر دارای چهرهٔ انسان واقعی یا اطلاعات خصوصی را نپذیرفت؛ برای ساخت ویدیو از تصویری بدون چهرهٔ واقعی استفاده کنید.',
                    'error_code' => 'VIDEO_INPUT_SAFETY_REJECTED',
                    'retryable' => false,
                    'generation_id' => null,
                    'credits_reserved' => 0,
                    'credits_settled' => 0,
                    'credits_refunded' => 0,
                    'poll_url' => null,
                ], 422)->header('X-Correlation-ID', $correlationId);
            }
            $message = str_contains($exceptionMessage, 'exhausted balance')
                || str_contains($exceptionMessage, 'user is locked')
                ? 'موجودی سرویس ساخت ویدیو موقتاً تمام شده است؛ اعتبار این درخواست برگشت داده شد.'
                : 'ساخت ویدیو انجام نشد؛ مدل یا اتصال سرویس را بررسی کنید.';

            return response()->json([
                'success' => false,
                'status' => 'failed',
                'message' => $message,
                'error_code' => 'STUDIO_WORKFLOW_UNAVAILABLE',
                'retryable' => true,
                'generation_id' => null,
                'credits_reserved' => 0,
                'credits_settled' => 0,
                'credits_refunded' => 0,
                'poll_url' => null,
            ], 503)->header('X-Correlation-ID', $correlationId);
        }
    }

    private function infrastructureImageLimit(): int
    {
        return max(1, min(50, (int) config('studio.max_reference_images', 20)));
    }

    private function maxReferenceImages(AiModel $model): int
    {
        $configured = (int) data_get($model->capability_config, 'max_reference_images', data_get($model->capability_config, 'max_images', 1));
        return max(1, min($this->infrastructureImageLimit(), $configured));
    }

    private function videoProduct(): Product
    {
        $product = Product::query()
            ->where('status', 'active')
            ->where('slug', 'ai-cinematic-short-video')
            ->first()
            ?: Product::query()->where('status', 'active')->where('output_type', 'video')->latest()->first();

        abort_unless($product && $product->isVideoProduct(), 404);

        return $product;
    }

    private function workflow(?string $workflow): string
    {
        return in_array($workflow, ['text_to_video', 'image_to_video', 'image_sequence_to_video', 'video_to_video'], true)
            ? $workflow
            : 'text_to_video';
    }

    private function selectedModel(Request $request, Product $product, string $workflow): AiModel
    {
        $modelId = trim((string) $request->input('studio_model', $request->query('model', $product->primary_model)));
        // در مسیر تک‌پروایدر، provider ذخیره‌شده‌ی قدیمی محصول نباید بتواند
        // انتخاب OpenRouter را با مقدار قدیمی Fal یا Replicate خنثی کند.
        $provider = trim((string) $request->input('studio_provider', $request->query('provider', '')));
        $model = AiModel::query()
            ->where('is_active', true)
            ->where('output_modality', 'video')
            ->where('provider', 'openrouter')
            ->whereNotNull('capability_config')
            ->where('openrouter_model_id', $modelId)
            ->when($provider !== '', fn ($query) => $query->where('provider', $provider))
            ->first();

        $capabilities = (array) ($model?->capability_config ?? []);
        $compatible = match ($workflow) {
            'text_to_video' => $model && ($model->task_type === 'text_to_video' || data_get($capabilities, 'supports_text_to_video') === true),
            'video_to_video' => $model && ($model->task_type === 'video_to_video' || data_get($capabilities, 'supports_video_to_video') === true),
            default => $model && ($model->task_type === 'image_to_video' || $model->task_type === 'face_animation' || data_get($capabilities, 'supports_image_to_video') === true),
        };

        if (!$compatible) {
            throw ValidationException::withMessages(['studio_model' => 'مدل انتخاب‌شده برای این نوع ورودی سازگار نیست.']);
        }

        return $model;
    }

    private function ensureWorkflowInputSupport(AiModel $model, string $workflow, VideoModelSchemaService $modelSchemas): void
    {
        $capabilities = (array) ($model->capability_config ?? []);
        $summary = $modelSchemas->summarize($model);
        $supported = match ($workflow) {
            'text_to_video' => data_get($capabilities, 'supports_text_to_video', $model->task_type === 'text_to_video') === true,
            'image_to_video', 'image_sequence_to_video' => (bool) ($summary['supports_image'] || data_get($capabilities, 'supports_image_to_video') === true),
            'video_to_video' => (bool) ($summary['supports_video'] || data_get($capabilities, 'supports_video_to_video') === true),
            default => false,
        };

        if (!$supported) {
            throw ValidationException::withMessages([
                'studio_model' => 'مدل انتخاب‌شده ورودی این حالت را پشتیبانی نمی‌کند؛ یک مدل سازگار انتخاب کنید.',
            ]);
        }
    }

    /**
     * برای هر مدل انتخاب‌شده مسیر پشتیبانِ هم‌نوع و دارای کلید می‌سازد.
     * گزینه‌های ارسال‌شده با قابلیت واقعی هر مدل مقایسه می‌شوند تا fallback
     * با زمان، کیفیت یا نسبت تصویر ناسازگار وارد صف نشود.
     */
    private function fallbackRoutes(AiModel $selected, string $workflow, Request $request, VideoModelSchemaService $modelSchemas): array
    {
        $candidates = AiModel::query()
            ->where('is_active', true)
            ->where('output_modality', 'video')
            ->where('provider', 'openrouter')
            ->whereIn('task_type', ['text_to_video', 'image_to_video', 'video_to_video', 'face_animation'])
            ->whereNotNull('openrouter_model_id')
            ->where('openrouter_model_id', '<>', '')
            ->get()
            ->filter(function (AiModel $candidate) use ($selected, $workflow, $request, $modelSchemas): bool {
                if ($candidate->provider === $selected->provider && $candidate->openrouter_model_id === $selected->openrouter_model_id) return false;
                if (blank(app(AiProviderCredentials::class)->for($candidate->provider)['api_key'] ?? null)) return false;

                $summary = $modelSchemas->summarize($candidate);
                $capabilities = (array) ($candidate->capability_config ?? []);
                $supportsWorkflow = match ($workflow) {
                    'text_to_video' => $candidate->task_type === 'text_to_video' || data_get($capabilities, 'supports_text_to_video') === true,
                    'video_to_video' => $candidate->task_type === 'video_to_video' || data_get($capabilities, 'supports_video_to_video') === true || $summary['supports_video'],
                    default => $candidate->task_type === 'image_to_video' || $candidate->task_type === 'face_animation' || data_get($capabilities, 'supports_image_to_video') === true || $summary['supports_image'],
                };
                if (!$supportsWorkflow) return false;

                $checks = [
                    ['key' => 'supported_durations', 'value' => (string) $request->input('video.duration')],
                    ['key' => 'supported_resolutions', 'value' => strtolower((string) $request->input('video.resolution'))],
                    ['key' => 'supported_aspect_ratios', 'value' => strtolower((string) $request->input('video.aspect_ratio'))],
                ];
                foreach ($checks as $check) {
                    $supported = data_get($capabilities, $check['key'], $summary[
                        match ($check['key']) {
                            'supported_durations' => 'durations',
                            'supported_resolutions' => 'resolutions',
                            default => 'aspect_ratios',
                        }
                    ] ?? []);
                    if (!is_array($supported) || $supported === []) continue;
                    $allowed = array_map(static fn ($value): string => strtolower((string) $value), $supported);
                    if (!in_array(strtolower($check['value']), $allowed, true)) return false;
                }

                return true;
            })
            ->sortBy(function (AiModel $candidate): array {
                return [
                    AiModel::STUDIO_PROVIDER_PRIORITY[$candidate->provider] ?? 99,
                    $candidate->lab_priority === null ? 999 : -((int) $candidate->lab_priority),
                    $candidate->id,
                ];
            })
            ->unique(fn (AiModel $candidate): string => $candidate->provider . '|' . $candidate->openrouter_model_id)
            ->take(3)
            ->values();

        return [
            $candidates->pluck('openrouter_model_id')->all(),
            $candidates->pluck('provider')->all(),
        ];
    }

    private function ensureSupportedOptions(AiModel $model, Request $request, VideoModelSchemaService $modelSchemas): void
    {
        $capabilities = (array) ($model->capability_config ?? []);
        $summary = $modelSchemas->summarize($model);
        $checks = [
            [
                'input' => 'video.duration',
                'capability' => 'supported_durations',
                'schema' => $summary['durations'] ?? [],
                'message' => 'مدل انتخاب‌شده این زمان ویدیو را پشتیبانی نمی‌کند؛ یک زمان سازگار انتخاب کنید.',
                'normalize' => static fn (mixed $value): string => (string) ((int) $value),
            ],
            [
                'input' => 'video.resolution',
                'capability' => 'supported_resolutions',
                'schema' => $summary['resolutions'] ?? [],
                'message' => 'مدل انتخاب‌شده این کیفیت خروجی را پشتیبانی نمی‌کند؛ کیفیت دیگری انتخاب کنید.',
                'normalize' => static fn (mixed $value): string => match (strtolower(trim((string) $value))) {
                    '2160', '2160p', '4k' => '4k',
                    '1440', '1440p', '2k' => '2k',
                    '1080', '1080p' => '1080p',
                    '720', '720p' => '720p',
                    '480', '480p' => '480p',
                    default => strtolower(trim((string) $value)),
                },
            ],
            [
                'input' => 'video.aspect_ratio',
                'capability' => 'supported_aspect_ratios',
                'schema' => $summary['aspect_ratios'] ?? [],
                'message' => 'مدل انتخاب‌شده این نسبت تصویر را پشتیبانی نمی‌کند؛ نسبت دیگری انتخاب کنید.',
                'normalize' => static fn (mixed $value): string => strtolower(trim((string) $value)),
            ],
        ];

        foreach ($checks as $check) {
            $supported = data_get($capabilities, $check['capability']);
            if (!is_array($supported) || $supported === []) $supported = $check['schema'];
            if (!is_array($supported) || $supported === []) continue;

            $value = ($check['normalize'])($request->input($check['input']));
            $allowed = array_map($check['normalize'], $supported);
            if (!in_array($value, $allowed, true)) {
                throw ValidationException::withMessages([$check['input'] => $check['message']]);
            }
        }
    }
}
