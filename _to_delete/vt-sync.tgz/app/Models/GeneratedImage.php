<?php

namespace App\Models;

use App\Support\Jalali;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class GeneratedImage extends Model
{
    protected $fillable = [
        'user_id',
        'product_id',
        'order_id',
        'ai_provider_request_id',
        'build_uuid',
        'image_path',
        'user_prompt',
        'cost',
        'size',
        'expires_at',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::saving(function (GeneratedImage $image): void {
            if ($image->order_id && ($image->isDirty('order_id') || ! $image->build_uuid)) {
                $image->build_uuid = Order::query()->whereKey($image->order_id)->value('build_uuid');
            } elseif ($image->ai_provider_request_id && ($image->isDirty('ai_provider_request_id') || ! $image->build_uuid)) {
                $image->build_uuid = AiProviderRequest::query()->whereKey($image->ai_provider_request_id)->value('build_uuid');
            }
            $image->build_uuid ??= (string) Str::uuid();
        });
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function providerRequest(): BelongsTo
    {
        return $this->belongsTo(AiProviderRequest::class, 'ai_provider_request_id');
    }

    /**
     * تاریخ و ساعت ساخت به شمسی — برای نمایش در مودال پیش‌نمایش عکس پروفایل
     */
    public function getJalaliCreatedAtAttribute(): string
    {
        return Jalali::format($this->created_at);
    }

    /**
     * لینک مستقیم به صفحه محصول اصلی که این عکس با اون ساخته شده (در صورت وجود محصول)
     */
    public function getProductUrlAttribute(): ?string
    {
        if (!$this->product || empty($this->product->slug)) {
            return null;
        }

        return route('app.product', $this->product->route_slug);
    }

    /** لینک عمومی خروجی ذخیره‌شده برای گزارش‌ها و پروفایل کاربر. */
    public function imageUrl(): ?string
    {
        if (!$this->image_path) {
            return null;
        }

        if (filter_var($this->image_path, FILTER_VALIDATE_URL)) {
            return $this->image_path;
        }

        return Storage::disk('public')->exists($this->image_path)
            ? asset('storage/' . ltrim($this->image_path, '/'))
            : null;
    }
}
