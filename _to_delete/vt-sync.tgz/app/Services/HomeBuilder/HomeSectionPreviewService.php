<?php

namespace App\Services\HomeBuilder;

use App\Models\Category;
use App\Models\HomeSection;
use App\Models\Product;

class HomeSectionPreviewService
{
    public function __construct(protected HomeSectionRenderService $renderService)
    {
    }

    public function make(array $data): array
    {
        $type = $data['type'];
        $settings = array_merge($this->defaultSettings($type), $data['settings'] ?? []);

        $section = new HomeSection([
            'type' => $type,
            'layout' => $data['layout'],
            'title_fa' => ($data['title_fa'] ?? null) ?: $this->defaultTitle($type),
            'subtitle_fa' => ($data['subtitle_fa'] ?? null) ?: 'پیش‌نمایش واقعی با محتوای فعال سایت',
            'settings' => $settings,
            'responsive' => $data['responsive'] ?? [],
            'status' => HomeSection::STATUS_DRAFT,
        ]);
        $section->id = 'preview-' . substr(md5($type . $data['layout']), 0, 8);

        $item = $this->renderService->prepare($section);

        $isVideoLayout = $type === 'vt_video_row' || ($type === 'product_slider'
            && in_array($data['layout'], ['video_loop', 'video_spotlight'], true));

        if (isset($item['products']) && $item['products']->isEmpty() && ! $isVideoLayout) {
            $section->settings = array_merge($settings, ['source' => 'latest']);
            $item = $this->renderService->prepare($section);
        }

        return $item;
    }

    private function defaultTitle(string $type): string
    {
        return match ($type) {
            'product_slider' => 'ترندهای امروز',
            'product_grid' => 'محصولات منتخب',
            'category_slider' => 'دسته‌بندی‌ها',
            'collection' => 'مجموعه پیشنهادی',
            default => (string) config("home_builder.types.{$type}.label", 'نمونه سکشن'),
        };
    }

    private function defaultSettings(string $type): array
    {
        return match ($type) {
            'hero' => [
                'heading' => 'ایده‌هایت را با وطن خلق کن',
                'subheading' => 'ابزارهای هوش مصنوعی و محصولات خلاقانه را یک‌جا تجربه کن.',
                'image' => $this->previewImage(),
                'cta_label' => 'شروع ساخت',
                'cta_link' => route('app.create'),
            ],
            'banner' => [
                'image' => $this->previewImage(),
                'alt_text' => 'بنر نمونه وطن',
                'link' => route('products.index'),
                'height' => 'medium',
            ],
            'text' => [
                'heading' => 'خلاقیت بدون مرز',
                'body' => 'این یک متن نمونه برای نمایش ظاهر واقعی سکشن در سایت است.',
                'align' => 'right',
            ],
            'product_slider' => [
                'source' => 'latest',
                'limit' => 8,
                'fill_empty_spaces' => false,
                'show_credit' => true,
                'show_title' => true,
                'show_category' => true,
                'show_view_all' => true,
                'view_all_link_mode' => 'auto',
                'card_aspect_ratio' => '4:5',
                'intro_scroll_mode' => 'together',
                'intro_badge' => 'استودیو وطن',
                'intro_heading' => 'از ایده تا خروجی با',
                'intro_heading_accent' => 'هوش مصنوعی',
                'intro_desc' => 'محصول مناسب را انتخاب کن و خروجی حرفه‌ای خودت را بساز.',
                'intro_steps' => "انتخاب محصول\nواردکردن اطلاعات\nدریافت خروجی",
                'intro_note' => 'ساده، سریع و قابل تنظیم',
                'intro_cta_label' => 'مشاهده محصولات',
                'intro_cta_link' => route('products.index'),
            ],
            'product_grid', 'collection' => [
                'source' => 'latest',
                'limit' => 8,
                'fill_empty_spaces' => false,
                'show_credit' => true,
                'show_view_all' => true,
                'view_all_link_mode' => 'auto',
            ],
            'category_slider' => [
                'limit' => 8,
                'products_per_tab' => 8,
                'fill_empty_spaces' => false,
                'show_view_all' => true,
                'view_all_link_mode' => 'auto',
            ],
            'spacer' => ['spacing_mode' => 'auto', 'height' => 'medium'],
            'vt_hero' => [
                'placement' => 'flow', 'source' => 'latest', 'limit' => 3,
                'kicker' => 'ویترین وطن', 'heading' => 'عکس محصولت رو حرفه‌ای کن',
                'subheading' => 'یک عکس بفرست؛ خروجی آماده‌ی فروش تحویل بگیر.', 'cta_label' => 'همین رو بساز',
            ],
            'vt_tools' => ['category_ids' => $this->topCategoryIds(8), 'hide_quick_chips' => true],
            'vt_row' => ['source' => 'latest', 'limit' => 10, 'show_view_all' => true, 'view_all_link_mode' => 'auto'],
            'vt_tabs' => ['category_ids' => $this->topCategoryIds(5), 'products_per_tab' => 10, 'min_products_per_tab' => 1, 'show_all_tab' => true, 'show_view_all' => true],
            'vt_before_after' => ['source' => 'with_before', 'limit' => 3, 'cta_label' => 'بساز'],
            'vt_video_row' => ['source' => 'video', 'limit' => 10, 'min_items' => 1, 'show_view_all' => true],
            'vt_cta_banner' => [
                'kicker' => 'ویژه فروشگاه‌ها و برندها', 'heading' => 'کسب‌وکارت رو معرفی کن، اعتبار هدیه بگیر',
                'body' => 'صنفت رو بگو تا قالب‌های مخصوص خودت رو ببینی.', 'cta_label' => 'معرفی کسب‌وکار', 'cta_link' => '/app/products',
                'cta2_label' => 'نمونه کارها', 'cta2_link' => '/app/products',
                'product_ids' => Product::query()->where('status', 'active')->latest()->limit(3)->pluck('id')->map(fn ($id) => ['id' => $id])->all(),
            ],
            'vt_occasions' => ['category_ids' => $this->topCategoryIds(6), 'min_products' => 1],
            'vt_masonry' => ['source' => 'latest', 'limit' => 15, 'sort' => 'latest', 'avoid_duplicates' => false],
            default => [],
        };
    }

    /** پرمحصول‌ترین دسته‌ها — فقط برای پیش‌نمایش داشبورد وقتی هنوز دسته‌ای انتخاب نشده. */
    private function topCategoryIds(int $limit): array
    {
        return Category::query()->active()
            ->withCount(['products' => fn ($q) => $q->where('status', 'active')])
            ->orderByDesc('products_count')
            ->limit($limit)
            ->pluck('id')
            ->all();
    }

    private function previewImage(): ?string
    {
        return Product::query()
            ->where('status', 'active')
            ->latest()
            ->first()
            ?->displayImageUrl();
    }
}
