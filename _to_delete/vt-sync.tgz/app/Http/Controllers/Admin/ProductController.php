<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\AiModel;
use App\Models\ProductPromptHistory;
use App\Models\Category;
use App\Models\Generation;
use App\Models\ProductTestRun;
use App\Models\LabExperiment;
use App\Models\ProductCreditLog;
use App\Models\ModelTierDefault;
use App\Models\ModelQualityPreset;
use App\Models\ProductCreditPreset;
use App\Models\Order;
use App\Models\GeneratedVideo;
use App\Services\ProductImageOptimizer;
use App\Services\VideoPreviewOptimizer;
use App\Services\VideoProductConfigService;
use App\Services\OpenRouterService;
use App\Services\ExchangeRateService;
use App\Services\ImageGenerationRetryPolicy;
use App\Services\ModelQualityPresetSync;
use App\Services\ProviderPricingService;
use App\Services\ProductLabCostService;
use App\Support\ProviderStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class ProductController extends Controller
{
    public function __construct(
        private readonly ProductImageOptimizer $imageOptimizer,
        private readonly ExchangeRateService $exchangeRate,
        private readonly ProviderPricingService $pricing,
        private readonly ProductLabCostService $labCosts,
        private readonly VideoPreviewOptimizer $videoPreviewOptimizer,
    ) {}

    public function translateIdentityPrompt(Request $request, OpenRouterService $openRouter)
    {
        $data = $request->validate([
            'text' => ['required', 'string', 'max:12000'],
            'direction' => ['nullable', 'in:en-to-fa,fa-to-en'],
        ]);
        $translation = ($data['direction'] ?? 'en-to-fa') === 'fa-to-en'
            ? $openRouter->translateToEnglish($data['text'])
            : $openRouter->translateToPersian($data['text']);
        return response()->json(['translation' => $translation]);
    }
    /**
     * نمایش لیست محصولات با جستجو، فیلترهای پیشرفته، مرتب‌سازی و صفحه‌بندی
     */
    public function index(Request $request)
    {
        $isVideoList = $request->routeIs('admin.products.videos');
        $productMediaTypes = $isVideoList ? ['video', 'both'] : ['photo', 'both'];

        // منبع مشترک مدل‌های قابل‌انتخاب در «ثبت محصول» و «تغییر سریع لیست».
        // منبع مشترک: مدل‌های فعال و تیک‌خورده از تمام providerها.
        // روشن/خاموش بودن provider فقط روی اجرای واقعی اثر دارد و نباید
        // باعث ناپدیدشدن مدل از کاتالوگ و فرم تنظیم محصول شود.
        $assignableAiModels = $this->assignableAiModels()->get();
        $validAiModelsByProvider = $assignableAiModels
            ->groupBy('provider')
            ->map(fn ($models) => $models->pluck('openrouter_model_id')->filter()->values()->all())
            ->all();
        $validAiModelKeys = $assignableAiModels
            ->mapWithKeys(fn (AiModel $model) => [$model->provider . '|' . $model->openrouter_model_id => true])
            ->all();

        // آمار واقعی اجرا برای هر محصول از جدول generations:
        // - generations_count      : تعداد کل اجراهای همان محصول
        // - unique_users_count     : تعداد کاربران یکتایی که محصول را اجرا کرده‌اند
        // - last_run_at            : تاریخ/ساعت آخرین اجرای محصول
        $query = Product::query()
            ->with(['categories', 'creator', 'editor', 'creatorRewardOwner', 'latestLabExperiment.runs.aiModel', 'latestLabExperiment.runs.outputs.managerScore'])
            ->withCount('generations')
            ->withCount('sourcePhotoProducts')
            ->withCount(['generations as completed_generations_count' => fn ($generationQuery) => $generationQuery->where('status', 'completed')])
            ->withCount('labExperiments')
            ->withCount(['labExperiments as scored_lab_experiments_count' => function ($experimentQuery) {
                $experimentQuery
                    ->where('status', 'completed')
                    ->whereHas('runs', function ($runQuery) {
                        $runQuery
                            ->where('status', 'completed')
                            ->whereHas('outputs', function ($outputQuery) {
                                $outputQuery->where(function ($scoreQuery) {
                                    $scoreQuery
                                        ->whereNotNull('manual_score')
                                        ->orWhereHas('scores');
                                });
                            });
                    });
            }])
            ->withCount(['testRuns as legacy_test_runs_count'])
            ->withCount('likedByUsers')
            ->withCount([
                'creatorRewardEvents as creator_reward_uses_count' => fn ($rewardQuery) => $rewardQuery->where('status', 'credited'),
            ])
            ->withSum([
                'creatorRewardEvents as creator_reward_credits_sum' => fn ($rewardQuery) => $rewardQuery->where('status', 'credited'),
            ], 'reward_credits')
            ->withSum(['orders as revenue_credits' => function ($orderQuery) {
                $orderQuery
                    ->whereIn('status', ['confirmed', 'processing', 'completed'])
                    ->whereIn('payment_status', ['paid', 'partially_refunded']);
            }], 'final_credits')
            ->addSelect([
                'unique_users_count' => Generation::selectRaw('count(distinct user_id)')
                    ->whereColumn('generations.product_id', 'products.id'),
                'last_run_at' => Generation::select('created_at')
                    ->whereColumn('generations.product_id', 'products.id')
                    ->latest('created_at')
                    ->limit(1),
            ]);
        if (Schema::hasTable('generated_videos')) {
            $query->withCount('generatedVideos');
        }

        // صفحه‌ی اصلی فهرست، مخصوص محصولات عکس است و صفحه‌ی جداگانه‌ی ویدیو
        // فقط محصولات ویدیویی را نشان می‌دهد؛ فیلتر رسانه در این دو صفحه نباید
        // بتواند دامنه‌ی اصلی فهرست را تغییر دهد.
        $query->whereIn('media_type', $productMediaTypes);

        if ($search = trim((string) $request->get('search'))) {
            $query->where(function ($q) use ($search) {
                $q->where('name_fa', 'like', "%{$search}%")
                  ->orWhere('name_en', 'like', "%{$search}%")
                  ->orWhere('slug', 'like', "%{$search}%")
                  ->orWhere('product_code', 'like', "%{$search}%")
                  ->orWhereJsonContains('tags', $search);
                if (is_numeric($search)) {
                    $q->orWhere('id', (int) $search);
                }
            });
        }

        if ($categoryId = $request->get('category_id')) {
            $query->where('category_id', $categoryId);
        }
       
        if ($status = $request->get('status')) {
            $query->where('status', $status);
        }
        if ($aiModel = $request->get('ai_model')) {
            $query->where('primary_model', $aiModel);
        }
        if ($aiProvider = $request->get('ai_provider')) {
            $query->where('ai_provider', $aiProvider);
        }
        if ($request->get('model_tier_preset') === 'configured') {
            $query->whereJsonContains('model_configuration->applied_preset', 'global');
        }
        if ($aiStatus = $request->get('ai_status')) {
            $this->applyAiModelStatusFilter($query, $aiStatus, $validAiModelsByProvider);
        }
        if ($pricingModel = $request->get('pricing_model')) {
            if ($pricingModel === 'paid') {
                $query->where('pricing_model', '!=', 'free');
            } else {
                $query->where('pricing_model', $pricingModel);
            }
        }
        if ($request->filled('model_cost_min') || $request->filled('model_cost_max')) {
            $modelsByCost = AiModel::query();
            if ($request->filled('model_cost_min')) $modelsByCost->where('cost_per_generation_usd', '>=', (float) $request->input('model_cost_min'));
            if ($request->filled('model_cost_max')) $modelsByCost->where('cost_per_generation_usd', '<=', (float) $request->input('model_cost_max'));
            $query->whereIn('primary_model', $modelsByCost->pluck('openrouter_model_id')->all() ?: ['__no_matching_model__']);
        }
        if ($request->filled('credit_min')) $query->where('credit_cost', '>=', (int) $request->input('credit_min'));
        if ($request->filled('credit_max')) $query->where('credit_cost', '<=', (int) $request->input('credit_max'));
        if ($request->filled('featured'))  $query->where('is_featured', true);
        if ($request->filled('is_new'))    $query->where('is_new', true);
        if ($request->filled('trending'))  $query->where('is_trending', true);

        if ($createdFrom = $request->get('created_from')) $query->whereDate('created_at', '>=', $createdFrom);
        if ($createdTo   = $request->get('created_to'))   $query->whereDate('created_at', '<=', $createdTo);
        if ($updatedFrom = $request->get('updated_from')) $query->whereDate('updated_at', '>=', $updatedFrom);
        if ($updatedTo   = $request->get('updated_to'))   $query->whereDate('updated_at', '<=', $updatedTo);

        switch ($request->get('sort')) {
            case 'oldest':     $query->oldest(); break;
            case 'az':         $query->orderBy('name_fa'); break;
            // مرتب‌سازی واقعی بر اساس آمار اجرا (ستون محاسبه‌شده‌ی withCount بالا)
            case 'most_used':  $query->orderByDesc('generations_count')->latest(); break;
            case 'least_used': $query->orderBy('generations_count')->latest(); break;
            case 'most_liked': $query->orderByRaw('(base_likes_count + (select count(*) from liked_products where liked_products.product_id = products.id)) desc')->latest(); break;
            case 'least_liked': $query->orderByRaw('(base_likes_count + (select count(*) from liked_products where liked_products.product_id = products.id)) asc')->latest(); break;
            case 'most_revenue': $query->orderByDesc('revenue_credits')->latest(); break;
            case 'newest':
            default:           $query->latest(); break;
        }

        $perPage = (int) $request->get('per_page', 15);
        if (!in_array($perPage, [10, 25, 50, 100], true)) {
            $perPage = 15;
        }

        // شناسه‌ی تمام نتایج فیلترشده را برای «انتخاب همه‌ی نتایج» در عملیات گروهی
        // به صفحه می‌فرستیم؛ انتخاب گروهی نباید به محصولات صفحه‌ی فعلی محدود بماند.
        $matchingProductIds = (clone $query)
            ->reorder()
            ->select('products.id')
            ->pluck('products.id')
            ->map(fn ($id) => (int) $id)
            ->values()
            ->all();

        $products = $query->paginate($perPage)->withQueryString();

        // آخرین ساخت‌های موفق کاربر برای همان صفحه را یک‌جا می‌خوانیم تا
        // ستون هزینه‌ی مدل منبع واقعی هم داشته باشد، بدون ایجاد N+1 در جدول.
        $userOrdersByProduct = Order::query()
            ->with(['providerRequests' => function ($providerRequestQuery): void {
                $providerRequestQuery
                    ->where('status', 'completed')
                    ->with('aiModel');
            }])
            ->whereIn('product_id', $products->getCollection()->pluck('id')->all() ?: [-1])
            ->where('source', 'app')
            ->where('status', 'completed')
            ->where('processing_status', 'completed')
            ->get()
            ->groupBy('product_id')
            ->map(fn ($orders) => $orders->sortByDesc('completed_at')->values());

        $scopedProductQuery = fn () => Product::query()->whereIn('media_type', $productMediaTypes);
        $activeCount   = $scopedProductQuery()->where('status', 'active')->count();
        $draftCount    = $scopedProductQuery()->where('status', 'draft')->count();
        $inactiveCount = $scopedProductQuery()->where('status', 'inactive')->count();

        // ── آمار واقعی اجراها برای کارت‌ها و نوار محبوبیت جدول ──
        // کل اجراها: اجراهای تصویری + رکوردهای تولید ویدیوی صف‌شده
        $totalRuns = Generation::whereHas('product', fn ($productQuery) => $productQuery->whereIn('media_type', $productMediaTypes))->count();
        if (Schema::hasTable('generated_videos')) {
            $totalRuns += GeneratedVideo::whereHas('product', fn ($productQuery) => $productQuery->whereIn('media_type', $productMediaTypes))->count();
        }
        $draftPhotoCount = Product::where('status', 'draft')->whereIn('media_type', ['photo', 'both'])->count();
        $draftVideoCount = Product::where('status', 'draft')->whereIn('media_type', ['video', 'both'])->count();
        // بیشترین تعداد اجرای یک محصول (مبنای درصد نوار محبوبیت هر ردیف جدول)
        $maxImageRuns = (int) (Generation::whereHas('product', fn ($productQuery) => $productQuery->whereIn('media_type', $productMediaTypes))
            ->selectRaw('count(*) as runs_count')
            ->groupBy('product_id')
            ->orderByDesc('runs_count')
            ->limit(1)
            ->value('runs_count') ?? 0);
        $maxVideoRuns = 0;
        if (Schema::hasTable('generated_videos')) {
            $maxVideoRuns = (int) (GeneratedVideo::whereHas('product', fn ($productQuery) => $productQuery->whereIn('media_type', $productMediaTypes))
                ->selectRaw('count(*) as runs_count')
                ->groupBy('product_id')
                ->orderByDesc('runs_count')
                ->limit(1)
                ->value('runs_count') ?? 0);
        }
        $maxRuns = max($maxImageRuns, $maxVideoRuns);
        // محبوب‌ترین محصول (بیشترین اجرا) — فقط وقتی حداقل یک اجرا ثبت شده باشد
        $topProduct = null;
        if ($maxRuns > 0) {
            $topProductQuery = Product::whereIn('media_type', $productMediaTypes)->withCount('generations');
            if (Schema::hasTable('generated_videos')) {
                $topProductQuery->withCount('generatedVideos');
                $topProductQuery->orderByRaw('(generations_count + generated_videos_count) desc');
            } else {
                $topProductQuery->orderByDesc('generations_count');
            }
            $topProduct = $topProductQuery->first();
        }

        // فیلترها و منوی تغییر سریع باید دقیقاً همان مدل‌های قابل‌انتخاب
        // ثبت محصول را نشان دهند؛ وضعیت اجرایی provider جداگانه بررسی می‌شود.
        // قیمت‌ها صرفاً برای نمایش تخمینی در پنجره‌ی چهار سطح مدل هستند. با false
        // هیچ فراخوانی زنده‌ای به سرویس‌دهنده انجام نمی‌شود و بازشدن لیست کند نمی‌گردد.
        $assignableAiModels->each(fn (AiModel $model) => $model->setAttribute(
            'lab_pricing',
            $this->pricing->estimate($model, 1, false)
        ));
        $aiModels = $assignableAiModels;
        $modelTierDefaults = ModelTierDefault::query()->get()->keyBy('tier_key');
        $modelQualityPresets = ModelQualityPreset::query()->orderByDesc('is_default_for_product_creation')->orderBy('id')->get();
        $qualityCreditPresets = ProductCreditPreset::query()->orderByDesc('is_default_for_product_creation')->orderBy('id')->get();
        $categories = Category::orderBy('name')->get();
        $recentlyEdited = $scopedProductQuery()->orderByDesc('updated_at')->take(3)->get();

        $exchange = $this->exchangeRate->usdToIrr();
        $exchangeRateIrr = (float) ($exchange['rate'] ?? 0);
        $products->getCollection()->each(function (Product $product) use ($exchangeRateIrr, $assignableAiModels, $userOrdersByProduct): void {
            $product->setAttribute(
                'lab_cost_summary',
                $this->labCosts->summarize(
                    $product,
                    $exchangeRateIrr,
                    $assignableAiModels,
                    $userOrdersByProduct->get($product->id, collect()),
                )
            );
        });
        return view('admin.products.index', compact(
            'products', 'activeCount', 'draftCount', 'inactiveCount',
            'totalRuns', 'maxRuns', 'topProduct', 'draftPhotoCount', 'draftVideoCount',
            'aiModels', 'assignableAiModels', 'validAiModelKeys', 'categories', 'recentlyEdited',
            'exchange', 'matchingProductIds', 'modelTierDefaults', 'modelQualityPresets', 'qualityCreditPresets', 'isVideoList'
        ));
    }

    /** فهرست مستقل محصولات ویدیو با همان رابط کاربری فهرست محصولات عکس. */
    public function videoIndex(Request $request)
    {
        return $this->index($request);
    }

    /**
     * نمایش فرم ساخت محصول جدید — یا فرم ویرایش محصول موجود، وقتی از دکمه‌ی «ویرایش»
     * با آی‌دی محصول (پارامتر اختیاری route) وارد این صفحه شده باشیم.
     *
     * نکته مهم (رفع باگ ساختاری): پیش‌تر این متد پارامتر {product} را نادیده می‌گرفت —
     * یعنی کلیک روی «ویرایش» یک فرم کاملاً خالی باز می‌کرد و ثبتِ آن (چون فرم همیشه به
     * store() ارسال می‌شود، نه update()) به‌جای ویرایش محصول، یک محصول تکراریِ جدید می‌ساخت.
     */
    public function create(Request $request, ?Product $product = null)
    {
        // محصول پروداکتی (پک شات) فرم جدای خودش را دارد؛ محصولات چهره‌محور بدون تغییر.
        if ($product && $product->isShotProduct()) {
            return redirect()->route('admin.product-shots.products.create', $product->id);
        }

        // تمام مدل‌های فعالِ عکس‌محور وارد گام دوم و آزمایشگاه می‌شوند؛ وضعیت
        // روشن‌بودن provider فقط هنگام ذخیره یا اجرای واقعی کنترل می‌شود.
        $aiModels = $this->assignableAiModels()->get();
        // قیمت‌های زنده برای ۵۰۰+ مدل Fal.ai نباید هنگام بازشدن فرم واکشی شوند؛
        // این اطلاعات هنگام اجرای واقعی آزمایش/تولید از سرویس قیمت‌گذاری خوانده می‌شود.
        $aiModels->each(fn (AiModel $model) => $model->setAttribute('lab_pricing', $this->pricing->estimate($model, 1, false)));
        $modelTierDefaults = ModelTierDefault::query()->get()->keyBy('tier_key');
        $modelQualityPresets = ModelQualityPreset::query()->orderByDesc('is_default_for_product_creation')->orderBy('id')->get();
        $qualityCreditPresets = ProductCreditPreset::query()->orderByDesc('is_default_for_product_creation')->orderBy('id')->get();

        $duplicateFrom = null;
        if ($request->filled('duplicate')) {
            $duplicateFrom = Product::find($request->get('duplicate'));
        }

        // ═══════════════════════════════════════════════════════════════════════
        // حالت ویرایش واقعی: به‌جای تکرار دستیِ هر فیلد در Blade (ریسک بالای فراموش‌شدن
        // یک فیلد و از‌دست‌رفتن دوباره‌ی داده — دقیقاً همان خانواده‌ی باگی که مشکل خالی‌شدن
        // توضیحات محصولات را ایجاد کرده بود)، مقادیر واقعی محصول را برای «همین یک درخواست»
        // به‌عنوان ورودی قبلی (old()) در دسترس قرار می‌دهیم؛ همان مکانیزمی که Laravel برای
        // نگه‌داشتن مقادیر فرم بعد از خطای ولیدیشن استفاده می‌کند. نتیجه: تمام old('field', ...)
        // های موجود در هر ۵ گام ویزارد — بدون نیاز به تغییر دستیِ آن‌ها — مقدار واقعی محصول را
        // نشان می‌دهند. از session()->now() استفاده می‌شود (نه flashInput()) تا این مقداردهی
        // فقط مخصوص همین درخواست بماند و به صفحه/محصول بعدی نشتی نکند.
        if ($product && !$request->session()->hasOldInput()) {
            $product->loadMissing('categories');
            $productData = $product->toArray();
            $productData['category_ids'] = $product->categories->pluck('id')->all();
            $productData['provider_options'] = (is_array($product->provider_options) && !empty($product->provider_options))
                ? json_encode($product->provider_options, JSON_UNESCAPED_UNICODE)
                : null;
            $request->session()->now('_old_input', $productData);
        }

        $suggestedLikesCount = random_int(120, 250);
        $exchange = $this->exchangeRate->usdToIrr();
        $labTested = $product
            ? $product->labExperiments()->where('status', 'completed')->exists()
            : false;

        $isVideoProductPage = $request->boolean('video_mode');
        $showProductTypeChooser = ! $product
            && ! $duplicateFrom
            && ! $isVideoProductPage
            && ! $request->is('admin/products/create/*')
            && $request->query('mode') !== 'portrait'
            && app(\App\Services\ProductShots\ProductShotFeature::class)->enabled();
        $relatedPhotoProducts = $isVideoProductPage
            ? Product::query()
                ->whereIn('media_type', ['photo', 'both'])
                ->where('output_type', 'image')
                ->whereIn('status', ['active', 'draft'])
                ->orderBy('name_fa')
                ->get(['id', 'name_fa', 'name_en', 'product_code', 'cover'])
            : collect();
        if ($product) $product->loadMissing('sourcePhotoProducts');

        return view('admin.products.create', compact('aiModels', 'duplicateFrom', 'product', 'suggestedLikesCount', 'exchange', 'labTested', 'modelTierDefaults', 'modelQualityPresets', 'qualityCreditPresets', 'isVideoProductPage', 'relatedPhotoProducts', 'showProductTypeChooser'));
    }

    /**
     * فرم ثبت محصول ویدیو عمداً همان فرم کامل ثبت محصول عکس است تا دو تجربه
     * از نظر UI و همه‌ی آیتم‌ها یکسان بمانند و اصلاحیه‌ها بعداً مرحله‌ای اعمال شوند.
     */
    public function videoCreate(Request $request, ?Product $product = null)
    {
        if ($product) abort_unless($product->isVideoProduct(), 404);
        $request->merge(['video_mode' => true]);

        return $this->create($request, $product);
    }

    public function videoStore(Request $request)
    {
        $this->prepareVideoAdminRequest($request);
        return $this->store($request);
    }

    public function videoUpdate(Request $request, Product $product)
    {
        abort_unless($product->isVideoProduct(), 404);
        $this->prepareVideoAdminRequest($request, $product);
        return $this->update($request, $product);
    }

    /**
     * ذخیره محصول جدید در دیتابیس (حل خطای ولیدیشن‌های ساختاری)
     */
   public function store(Request $request)
    {
        $this->mergeInputSchemaJson($request);
        if (!$request->boolean('special_features_enabled')) {
            $request->merge(['input_schema' => []]);
        }

        $isPublishing = $request->input('status') === 'active';

        // پیش‌نویس می‌تواند ناقص بماند؛ انتشار فقط با تکمیل موارد حیاتی مجاز است.
        $validated = $request->validate([
            'name_fa' => [Rule::requiredIf($isPublishing), 'nullable', 'string', 'max:255'],
            'name_en' => [Rule::requiredIf($isPublishing), 'nullable', 'string', 'max:255'],
            'slug' => [Rule::requiredIf($isPublishing), 'nullable', 'string', 'max:255'],
            'category_id' => 'nullable|integer',
            'category_ids' => [Rule::requiredIf($isPublishing), 'nullable', 'array', 'min:1'],
            'category_ids.*' => 'integer|exists:categories,id',
            'primary_model' => ['nullable', 'string'],
            'ai_provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'fallback_providers' => 'nullable|array',
            'fallback_providers.*' => Rule::in(ProviderStatus::PROVIDERS),
            'fallback_enabled' => ['nullable', 'boolean'],
            'fallback_models' => [Rule::requiredIf($isPublishing && $request->boolean('fallback_enabled')), 'nullable', 'array', 'min:1', 'max:5'],
            'fallback_models.*' => ['string'],
            'model_configuration' => 'nullable|array',
            'model_configuration.max_retries' => 'nullable|integer|min:0|max:2',
            'model_configuration.standard' => 'nullable|array',
            'model_configuration.standard.model_id' => 'nullable|string|max:255',
            'model_configuration.standard.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'model_configuration.premium' => 'nullable|array',
            'model_configuration.premium.model_id' => 'nullable|string|max:255',
            'model_configuration.premium.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'model_configuration.fallback' => 'nullable|array',
            'model_configuration.fallback.model_id' => 'nullable|string|max:255',
            'model_configuration.fallback.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            ...$this->modelTierRules(),
            ...$this->creatorRewardRules($request),
            'prompt_template' => [Rule::requiredIf($isPublishing), 'nullable', 'string'],
            'identity_preservation' => ['required', 'boolean'],
            'identity_model' => ['nullable', 'string'],
            'identity_model_provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'identity_credit_cost' => ['nullable', 'integer', 'min:0'],
            'identity_instructions' => ['nullable', 'string'],
            'identity_instructions_fa' => ['nullable', 'string'],
            'min_reference_images' => ['nullable', 'integer', 'min:0', 'max:3'],
            'max_reference_images' => ['nullable', 'integer', 'min:1', 'max:3'],
            'status' => 'nullable|in:active,draft,inactive',
            'description_fa' => 'nullable|string',
            'description_en' => 'nullable|string',
            'base_likes_count' => 'nullable|integer|min:0|max:999999999',
            'allowed_aspect_ratios' => 'nullable|array',
            'allowed_aspect_ratios.*' => ['string', Rule::in(Product::supportedAspectRatios())],
            'allowed_resolutions' => 'nullable|array',
            'allowed_resolutions.*' => ['string', Rule::in(Product::supportedOutputResolutions())],
            'output_quality_selector_enabled' => ['nullable', 'boolean'],
            'pipeline_enabled' => ['nullable', 'boolean'],
            'main_images' => [Rule::requiredIf($isPublishing), 'nullable', 'array', 'min:1', 'max:20'],
            'main_images.*' => 'image|mimes:jpeg,png,jpg,webp|max:12288',
            'before_images' => 'nullable|array|max:20',
            'before_images.*' => 'image|mimes:jpeg,png,jpg,webp|max:12288',
            'preview_video' => 'nullable|file|mimes:mp4,webm,mov|max:102400',
            'preview_video_url' => 'nullable|string|max:2048',
            'video_config.workflow' => ['nullable', Rule::in(VideoProductConfigService::WORKFLOWS)],
            'video_config.face_profile_mode' => ['nullable', Rule::in(['disabled', 'optional', 'required'])],
            'video_config.durations' => 'nullable|array',
            'video_config.durations.*' => 'integer|min:1|max:15',
            'video_config.aspect_ratios' => 'nullable|array',
            'video_config.aspect_ratios.*' => ['string', Rule::in(VideoProductConfigService::ASPECT_RATIOS)],
            'video_config.resolutions' => 'nullable|array',
            'video_config.resolutions.*' => ['string', Rule::in(VideoProductConfigService::RESOLUTIONS)],
            'video_quality_credit_costs' => 'nullable|array',
            'video_quality_credit_costs.*' => 'integer|min:1|max:1000000',
            'video_related_photo_product_ids' => ['nullable', 'array', 'max:100'],
            'video_related_photo_product_ids.*' => ['integer', 'distinct', Rule::exists('products', 'id')->where(fn ($query) => $query->whereIn('media_type', ['photo', 'both'])->where('output_type', 'image'))],
            ...$this->inputSchemaRules(),
        ]);
        $this->validateAiProviderSelection($request);
        $this->validateModelTierConfiguration($request, $isPublishing);

        // ۲. ساخت یک نمونه جدید از مدل (برای دور زدن محدودیت fillable دیتابیس)
        $product = new Product();

        // ۳. مقداردهی فیلدهای اصلی (اگر در فرم خالی باشند، مقدار پیش‌فرض تست قرار می‌گیرد)
        $product->name_fa = self::stripCopySuffix($request->input('name_fa')) ?? 'محصول تست ' . rand(100, 999);
        $product->name_en = $request->input('name_en') ?? 'Test Product ' . rand(100, 999);
        
        $slugSource = $request->input('slug') ?? $product->name_en;
        $baseSlug = Str::slug($slugSource);
        $slug = $baseSlug ?: 'test-product-' . rand(100, 999);
        $i = 1;
        while (Product::where('slug', $slug)->exists()) {
            $slug = $baseSlug . '-' . (++$i);
        }
        $product->slug = $slug;

        // ۳.۰.۱ کد ۶ رقمی یکتای محصول — همان کدی که در لینک عمومی محصول و ستون «کد محصول»
        // لیست ادمین استفاده می‌شود؛ برای هر محصول جدید همین‌جا ساخته می‌شود.
        $product->product_code = Product::generateUniqueProductCode();
        $product->base_likes_count = $request->filled('base_likes_count')
            ? max(0, (int) $request->input('base_likes_count'))
            : random_int(120, 250);

        // ۳.۱ توضیحات فارسی/انگلیسی محصول (متن کامل نمایش داده‌شده در صفحه محصول)
        // نکته مهم: این دو خط عمداً اضافه شده‌اند — پیش‌تر در این متد اصلاً ذخیره نمی‌شدند
        // و همین باعث می‌شد توضیحات محصولات جدید با وجود پرشدن فرم، هرگز در دیتابیس ثبت نشود.
        $product->description_fa = $request->input('description_fa');
        $product->description_en = $request->input('description_en');

        // ۴. دسته‌بندی چندگانه (سرشاخه + زیرشاخه‌ها)
        $categoryIds = array_values(array_unique(array_filter(array_map('intval', (array) $request->input('category_ids', [])))));
        if (empty($categoryIds) && $request->filled('category_id')) {
            $categoryIds = [(int) $request->input('category_id')];
        }
        $primaryId = $categoryIds[0] ?? (Category::first()->id ?? null);
        $product->category_id = $primaryId;
        $product->category = $primaryId ? (Category::where('id', $primaryId)->value('name') ?? 'عمومی') : 'عمومی';
        $product->subcategory = $request->input('subcategory');

        // ۵. تصاویر محصول: اولین عکس اصلی = کاور/تصویر کارت، بقیه = گالری.
        // ستون legacy thumbnail عمداً حذف نمی‌شود تا داده محصولات قدیمی دست‌نخورده بماند.
        $duplicateSource = $request->filled('duplicate_from') ? Product::find($request->input('duplicate_from')) : null;

        $mainPaths = $this->storeOptimizedImages($request->file('main_images', []), 'products/main');
        if ($mainPaths) {
            $product->cover = array_shift($mainPaths);
            $product->sample_outputs = $mainPaths;
        } elseif ($duplicateSource && $duplicateSource->cover && Storage::disk('public')->exists($duplicateSource->cover)) {
            $product->cover = $this->copyDuplicateFile($duplicateSource->cover, 'products/covers');
            $product->sample_outputs = $this->copyDuplicateFiles((array) $duplicateSource->sample_outputs, 'products/samples');
        }
        // ستون thumbnail در دیتابیس قدیمی NOT NULL است؛ برای محصول جدید فقط همان مسیر
        // عکس اصلی را alias می‌کنیم و هیچ فایل دوم یا سایز دومی ساخته نمی‌شود.
        $product->thumbnail = $product->cover ?: 'products/thumbnails/default_placeholder.jpg';

        if ($request->hasFile('new_product_icon')) {
            $product->new_product_icon = $request->file('new_product_icon')->store('product_icons', 'public');
        } elseif ($duplicateSource && $duplicateSource->new_product_icon && Storage::disk('public')->exists($duplicateSource->new_product_icon)) {
            $product->new_product_icon = $this->copyDuplicateFile($duplicateSource->new_product_icon, 'product_icons');
        }

        $product->before_images = $this->storeOptimizedImages($request->file('before_images', []), 'products/before_images');
        if ($request->hasFile('main_images') || $request->hasFile('before_images')) {
            $product->images_optimized_at = now();
        } elseif ($duplicateSource) {
            $product->images_optimized_at = $duplicateSource->images_optimized_at;
        }

        // ۶. فیلدهای سیستمی و هوش مصنوعی
        // اگر ادمین مدلی انتخاب نکرده باشد، به‌جای اولین مدل ثبت‌شده در سیستم
        // (که ممکن است متعلق به providerِ خاموش‌شده باشد) اولین مدل فعال از
        // یک provider روشن انتخاب می‌شود.
        $selectedModel = $this->selectedAiModel($request);
        $fallbackModel = $selectedModel ?: AiModel::where('is_active', true)
                ->whereIn('provider', ProviderStatus::enabled() ?: ['__none__'])
                ->first();
        $product->primary_model = $fallbackModel?->openrouter_model_id
            ?? 'stabilityai/stable-diffusion-3';
        $product->ai_provider = $fallbackModel?->provider ?? 'openrouter';
        $fallbackEnabled = $request->boolean('fallback_enabled');
        $product->fallback_models = $fallbackEnabled ? $request->input('fallback_models', []) : [];
        $product->fallback_model_providers = $fallbackEnabled ? $request->input('fallback_providers', []) : [];
        $product->model_configuration = $this->normalizeModelConfiguration($request->input('model_configuration', []));
        $this->applyBusinessTierAsLegacyExecution($product, $product->model_configuration);
        $this->applyQualityCreditPricingAsLegacyFields($product, $product->model_configuration);
        $product->creator_reward_enabled = $request->boolean('creator_reward_enabled');
        $product->creator_reward_owner_id = $product->creator_reward_enabled
            ? (int) $request->input('creator_reward_owner_id')
            : null;
        $product->creator_reward_settings = $this->normalizeCreatorRewardSettings(
            (array) $request->input('creator_reward_settings', [])
        );
        $product->prompt_template = $request->input('prompt_template') ?? 'A high tech digital art illustration of {prompt}';
        $product->input_schema = $validated['input_schema'] ?? [];
        $product->timeout = $request->input('timeout') ?? 60;
        $product->pipeline_type = $request->input('pipeline_type') ?? 'image_generation';

        // ۶.۱ پارامترهای واقعی کیفیت + پرامپت‌های تکمیلی
        $product->system_prompt    = $request->input('system_prompt');
        $product->negative_prompt  = $request->input('negative_prompt');
        $product->seed             = $request->filled('seed') ? (int) $request->input('seed') : null;
        $providerOptionsRaw        = $request->input('provider_options');
        $product->provider_options = $providerOptionsRaw ? (json_decode($providerOptionsRaw, true) ?: null) : null;

        // ۶.۲ نوع سوژه و حفظ هویت (چهره/هیکل)
        $product->subject_type          = $request->input('subject_type') ?? 'generic';
        $product->identity_preservation = $request->boolean('identity_preservation');
        $product->identity_strength     = $request->input('identity_strength') ?? 80;
        $product->preserve_body         = $request->has('preserve_body');
        $product->identity_instructions = $request->input('identity_instructions')
            ?: \App\Services\ProductPromptBuilder::defaultIdentityInstructions();
        $product->identity_instructions_fa = $request->input('identity_instructions_fa')
            ?: \App\Services\ProductPromptBuilder::defaultIdentityInstructionsFa();
        $product->identity_model        = $request->input('identity_model');
        $product->identity_model_provider = $request->input('identity_model_provider');
        $product->identity_credit_cost  = max(0, (int) $request->input('identity_credit_cost', 0));
        $product->min_reference_images  = min(3, max(0, (int) $request->input('min_reference_images', 1)));
        $product->max_reference_images  = min(3, max(1, (int) $request->input('max_reference_images', 3)));

        // ۶.۳ سئو
        $product->meta_title       = $request->input('meta_title');
        $product->meta_description = $request->input('meta_description');
        $product->meta_keywords    = $request->input('meta_keywords');
        if ($request->hasFile('og_image')) {
            $product->og_image = $request->file('og_image')->store('products/seo', 'public');
        } elseif ($duplicateSource && $duplicateSource->og_image && Storage::disk('public')->exists($duplicateSource->og_image)) {
            $product->og_image = $this->copyDuplicateFile($duplicateSource->og_image, 'products/seo');
        }

        // ۷. وضعیت‌ها و چک‌باکس‌ها
        $product->status = $request->input('status') ?? 'draft';
        $product->new_display_order = $request->input('new_display_order') ?? 1;
        $product->new_internal_code = $request->input('new_internal_code');
        $product->new_admin_note = $request->input('new_admin_note');
        
        $product->is_featured = $request->has('is_featured');
        $product->is_new = $request->has('is_new');
        $product->is_trending = $request->has('is_trending');
        $product->watermark_enabled = $request->has('watermark_enabled');
        $product->new_is_premium = $request->has('new_is_premium');
        $product->new_is_recommended = $request->has('new_is_recommended');
        $product->new_is_beta = $request->has('new_is_beta');

        // ۸. تنظیمات ظاهری و فنی
        $product->media_type = $request->input('media_type') ?? 'photo';
        $product->preview_video_url = $request->input('preview_video_url');
        if ($request->hasFile('preview_video')) {
            $product->preview_video_url = $this->videoPreviewOptimizer->store($request->file('preview_video'));
        }
        $product->watermark_position = $request->input('watermark_position') ?? 'corner';
        $product->display_mode = $request->input('display_mode') ?? 'card';
        $product->card_shape = $request->input('card_shape') ?? 'portrait';
        $product->gallery_layout = $request->input('gallery_layout') ?? 'grid';
        $product->card_label = $request->input('card_label');
        $product->card_label_enabled = $request->boolean('card_label_enabled');
        $product->card_label_position = $request->input('card_label_position', 'top-right');
        $product->output_type = $request->input('output_type') ?? 'image';
        $product->output_format = $request->input('output_format') ?? 'jpg';
        $product->output_count = $request->input('output_count') ?? 1;
        $product->allowed_aspect_ratios = $this->normalizedAspectRatios(
            $request->input('allowed_aspect_ratios', Product::supportedAspectRatios())
        );
        $product->aspect_ratio = in_array('3:4', $product->allowed_aspect_ratios, true)
            ? '3:4'
            : $product->allowed_aspect_ratios[0];
        $product->allowed_resolutions = $this->normalizedResolutions(
            $request->input('allowed_resolutions', Product::DEFAULT_OUTPUT_RESOLUTIONS)
        );
        $product->output_quality_selector_enabled = $request->boolean('output_quality_selector_enabled');
        $product->pipeline_enabled = $request->boolean('pipeline_enabled');
        $product->resolution = in_array('720', $product->allowed_resolutions, true)
            ? '720'
            : $product->allowed_resolutions[0];
        $product->delivery_method = $request->input('delivery_method') ?? 'instant';
        $product->estimated_time = $request->input('estimated_time') ?? 30;
        $product->price_tier = $request->input('price_tier') ?? 'standard';
        $product->discount_percentage = $request->input('discount_percentage') ?? 0;
        $product->platform = $request->input('platform') ?? 'both';
        $product->accent_color = $request->input('accent_color') ?? '#a07af5';
        $product->tags = $request->input('tags', []);

        // حالت‌های نمایش کاشی در اکسپلور — حداقل یکی؛ مقدار خالی نباید ناخواسته همهٔ قاب‌ها را فعال کند.
        $exploreTiles = array_values(array_intersect(['1x1','2x2','1x2','2x1'], (array) $request->input('explore_tiles', [])));
        $product->explore_tiles = $exploreTiles ?: ['1x1'];

        // ۹. فیلدهای فاز جدید توسعه
        $product->new_watermark_corner_precise = $request->input('new_watermark_corner_precise') ?? 'tr';
        $product->new_watermark_opacity = $request->input('new_watermark_opacity') ?? 70;
        $product->new_watermark_size = $request->input('new_watermark_size') ?? 30;
        $product->new_watermark_type = $request->input('new_watermark_type') ?? 'logo';
        $product->new_watermark_text_color = $request->input('new_watermark_text_color') ?? '#FFFFFF';
        // ۱۰. ذخیره نهایی به‌صورت اتمیک: محصول، دسته‌بندی‌ها و تست‌ها یا همگی
        // ثبت می‌شوند یا در صورت هر خطا همگی rollback می‌شوند؛ محصول نیمه‌کاره
        // در دیتابیس باقی نمی‌ماند و محصولات قبلی نیز دست‌نخورده می‌مانند.
        DB::transaction(function () use ($product, $request, $categoryIds) {
            $product->save();
            if (!empty($categoryIds)) {
                $product->categories()->sync($categoryIds);
            }
            $this->attachDraftTests($request, $product);
            if ($request->boolean('video_mode')) {
                $this->syncVideoPhotoRelations($product, $request);
            }
        });

        if ($request->expectsJson()) {
            session()->flash('success', $isPublishing ? 'محصول با موفقیت ثبت و منتشر شد.' : 'پیش‌نویس محصول با موفقیت ذخیره شد.');
            return response()->json([
                'ok' => true,
                'redirect' => $request->boolean('open_lab_after_save')
                    ? route('admin.lab.create', ['product_id' => $product->id])
                    : ($request->boolean('video_mode') ? route('admin.products.videos') : route('admin.products')),
                'message' => $isPublishing ? 'محصول با موفقیت ثبت و منتشر شد.' : 'پیش‌نویس محصول با موفقیت ذخیره شد.',
            ]);
        }

        if ($request->boolean('open_lab_after_save')) {
            return redirect()->route('admin.lab.create', ['product_id' => $product->id])->with('success', 'محصول ذخیره شد؛ حالا تصاویر و مدل‌های آزمایش را انتخاب کنید.');
        }

        return redirect()->route($request->boolean('video_mode') ? 'admin.products.videos' : 'admin.products')
            ->with('success', 'محصول جدید با موفقیت و بدون خطای ساختاری ثبت شد.');
    }

    /**
     * نمایش فرم ویرایش محصول
     */
    public function edit(Product $product)
    {
        // فقط مدل‌های فعالِ providerهای روشن در فرم ویرایش نمایش داده می‌شوند.
        $aiModels = $this->assignableAiModels()->get();
        return view('admin.products.edit', compact('product', 'aiModels'));
    }

    /**
     * به‌روزرسانی اطلاعات محصول
     */
    public function update(Request $request, Product $product)
    {
        $this->mergeInputSchemaJson($request);
        if (!$request->boolean('special_features_enabled')) {
            $request->merge(['input_schema' => []]);
        }
        $isPublishing = $request->input('status') === 'active';

        $validated = $request->validate([
            'name_fa' => 'required|string|max:255',
            'name_en' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:products,slug,' . $product->id,
            'category_id' => 'nullable|integer',
            'category_ids' => [Rule::requiredIf($isPublishing), 'nullable', 'array', 'min:1'],
            'category_ids.*' => 'integer|exists:categories,id',
            'primary_model' => ['nullable', 'string'],
            'ai_provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'fallback_providers' => 'nullable|array',
            'fallback_providers.*' => Rule::in(ProviderStatus::PROVIDERS),
            'fallback_enabled' => ['nullable', 'boolean'],
            'fallback_models' => [Rule::requiredIf($isPublishing && $request->boolean('fallback_enabled')), 'nullable', 'array', 'min:1', 'max:5'],
            'fallback_models.*' => ['string'],
            'model_configuration' => 'nullable|array',
            'model_configuration.max_retries' => 'nullable|integer|min:0|max:2',
            'model_configuration.standard' => 'nullable|array',
            'model_configuration.standard.model_id' => 'nullable|string|max:255',
            'model_configuration.standard.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'model_configuration.premium' => 'nullable|array',
            'model_configuration.premium.model_id' => 'nullable|string|max:255',
            'model_configuration.premium.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'model_configuration.fallback' => 'nullable|array',
            'model_configuration.fallback.model_id' => 'nullable|string|max:255',
            'model_configuration.fallback.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            ...$this->modelTierRules(),
            ...$this->creatorRewardRules($request),
            'prompt_template' => [Rule::requiredIf($isPublishing), 'nullable', 'string'],
            'system_prompt' => 'nullable|string',
            'negative_prompt' => 'nullable|string',
            'seed' => 'nullable|integer',
            'provider_options' => 'nullable|string',
            'subject_type' => 'nullable|in:generic,face,body,product,scene',
            'identity_preservation' => ['required', 'boolean'],
            'identity_model' => ['nullable', 'string'],
            'identity_model_provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'identity_credit_cost' => ['nullable', 'integer', 'min:0'],
            'identity_strength' => 'nullable|integer|min:0|max:100',
            'identity_instructions' => 'nullable|string',
            'identity_instructions_fa' => 'nullable|string',
            'min_reference_images' => 'nullable|integer|min:0|max:3',
            'max_reference_images' => 'nullable|integer|min:1|max:3',
            'description_fa' => 'nullable|string',
            'description_en' => 'nullable|string',
            'base_likes_count' => 'nullable|integer|min:0|max:999999999',
            'meta_title' => 'nullable|string|max:255',
            'meta_description' => 'nullable|string|max:300',
            'meta_keywords' => 'nullable|string|max:255',
            'og_image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:4096',
            'explore_tiles' => 'nullable|array',
            'explore_tiles.*' => 'in:1x1,2x2,1x2,2x1',
            'status' => 'nullable|in:active,draft,inactive',
            'main_images' => [Rule::requiredIf($isPublishing && !$product->cover), 'nullable', 'array', 'min:1', 'max:20'],
            'main_images.*' => 'image|mimes:jpeg,png,jpg,webp|max:12288',
            'before_images' => 'nullable|array|max:20',
            'before_images.*' => 'image|mimes:jpeg,png,jpg,webp|max:12288',
            'preview_video' => 'nullable|file|mimes:mp4,webm,mov|max:102400',
            'video_config.workflow' => ['nullable', Rule::in(VideoProductConfigService::WORKFLOWS)],
            'video_config.face_profile_mode' => ['nullable', Rule::in(['disabled', 'optional', 'required'])],
            'video_config.durations' => 'nullable|array',
            'video_config.durations.*' => 'integer|min:1|max:15',
            'video_config.aspect_ratios' => 'nullable|array',
            'video_config.aspect_ratios.*' => ['string', Rule::in(VideoProductConfigService::ASPECT_RATIOS)],
            'video_config.resolutions' => 'nullable|array',
            'video_config.resolutions.*' => ['string', Rule::in(VideoProductConfigService::RESOLUTIONS)],
            'video_quality_credit_costs' => 'nullable|array',
            'video_quality_credit_costs.*' => 'integer|min:1|max:1000000',
            'video_related_photo_product_ids' => ['nullable', 'array', 'max:100'],
            'video_related_photo_product_ids.*' => ['integer', 'distinct', Rule::exists('products', 'id')->where(fn ($query) => $query->whereIn('media_type', ['photo', 'both'])->where('output_type', 'image'))],
            'media_type' => 'nullable|in:photo,video,both',
            'preview_video_url' => 'nullable|string|max:2048',
            'pipeline_type' => 'nullable|string',
            'timeout' => 'nullable|integer',
            'watermark_position' => 'nullable|string',
            'display_mode' => 'nullable|string',
            'card_shape' => 'nullable|string',
            'gallery_layout' => 'nullable|string',
            'card_label' => 'nullable|string|max:100',
            'card_label_enabled' => 'nullable|boolean',
            'card_label_position' => 'nullable|in:top-right,top-left,bottom-right,bottom-left',
            'new_display_order' => 'nullable|integer',
            'new_internal_code' => 'nullable|string|max:100',
            'new_admin_note' => 'nullable|string',
            'new_product_icon' => 'nullable|file|mimes:svg,png|max:2048',
            'new_card_color' => 'nullable|string',
            'new_gallery_preview_mode' => 'nullable|string',
            'new_watermark_corner_precise' => 'nullable|string',
            'new_watermark_opacity' => 'nullable|integer',
            'new_watermark_size' => 'nullable|integer',
            'new_watermark_type' => 'nullable|string',
            'new_watermark_text_color' => 'nullable|string',
            'allowed_aspect_ratios' => 'nullable|array',
            'allowed_aspect_ratios.*' => ['string', Rule::in(Product::supportedAspectRatios())],
            'allowed_resolutions' => 'nullable|array',
            'allowed_resolutions.*' => ['string', Rule::in(Product::supportedOutputResolutions())],
            'output_quality_selector_enabled' => ['nullable', 'boolean'],
            'pipeline_enabled' => ['nullable', 'boolean'],
            ...$this->inputSchemaRules(),
        ]);
        $this->validateAiProviderSelection($request);
        $this->validateModelTierConfiguration($request, $isPublishing, (array) $product->model_configuration);

        // ═══════════════════════════════════════════════════════════════════════════
        // محافظ حیاتی در برابر خالی‌شدن ناخواسته‌ی فیلدها (Phantom-Null Guard):
        // در Laravel، وقتی یک کلید در آرایه‌ی قوانین ولیدیشن با قانون nullable تعریف شده باشد
        // ولی آن کلید اصلاً در بدنه‌ی درخواست ارسالی وجود نداشته باشد (نه اینکه خالی باشد، بلکه
        // اصلاً ارسال نشده باشد)، Validator آن را معتبر تشخیص می‌دهد و $validated آن کلید را با
        // مقدار null برمی‌گرداند. اگر این $validated مستقیماً به $product->update() داده شود،
        // مقدار واقعی و قبلاً ذخیره‌شده‌ی آن ستون در دیتابیس با NULL جایگزین می‌شود — دقیقاً همین
        // باگ باعث خالی‌شدن توضیحات فارسی/انگلیسی محصولات موجود شده بود (فرمی که این فیلد را
        // شامل نمی‌شد، هنگام ثبت هر تغییر دیگری آن را بی‌سروصدا پاک می‌کرد).
        // راه‌حل قطعی: فقط کلیدهایی که واقعاً در درخواست ارسالی حاضرند اجازه‌ی ورود به آرایه‌ی
        // نهایی آپدیت را دارند؛ فیلدهای چک‌باکس/فایل/محاسبه‌شده که در ادامه‌ی این متد صراحتاً
        // دوباره مقداردهی می‌شوند (is_featured, category, thumbnail و غیره) از این فیلتر تأثیر
        // نمی‌پذیرند چون بعداً به‌صورت مستقیم روی $validated بازنویسی می‌شوند.
        $validated = array_intersect_key($validated, $request->all());

        $creatorRewardEnabled = $request->boolean('creator_reward_enabled');
        $validated['creator_reward_enabled'] = $creatorRewardEnabled;
        $validated['creator_reward_owner_id'] = $creatorRewardEnabled
            ? (int) $request->input('creator_reward_owner_id')
            : null;
        $validated['creator_reward_settings'] = $this->normalizeCreatorRewardSettings(
            (array) $request->input('creator_reward_settings', []),
            (array) ($product->creator_reward_settings ?? [])
        );
        $this->ensureCreatorRewardOwnerCanBeChanged(
            $product,
            $creatorRewardEnabled ? (int) $request->input('creator_reward_owner_id') : null
        );

        // مقدار ذخیره‌شده دقیقاً از همان رکورد مرکب provider + model گرفته
        // می‌شود؛ نه از اولین رکوردی که فقط شناسه مدل یکسان دارد.
        if ($selectedModel = $this->selectedAiModel($request)) {
            $validated['primary_model'] = $selectedModel->openrouter_model_id;
            $validated['ai_provider'] = $selectedModel->provider;
        }

        // نرمال‌سازی فیلدهای NOT NULL: فرم گاهی این فیلدها را خالی می‌فرستد،
        // قانون nullable|integer آن را به null تبدیل می‌کند و چون ستون در دیتابیس
        // NOT NULL است خطای 1048 (cannot be null) رخ می‌دهد. null را با پیش‌فرض جایگزین می‌کنیم.
        $notNullDefaults = [
            'new_display_order'            => 1,
            'new_card_color'               => '#A07AF5',
            'new_gallery_preview_mode'     => 'grid',
            'new_watermark_corner_precise' => 'tr',
            'new_watermark_opacity'        => 70,
            'new_watermark_size'           => 30,
            'new_watermark_type'           => 'logo',
            'new_watermark_text_color'     => '#FFFFFF',
        ];
        foreach ($notNullDefaults as $__nnKey => $__nnDefault) {
            if (array_key_exists($__nnKey, $validated) && $validated[$__nnKey] === null) {
                $validated[$__nnKey] = $__nnDefault;
            }
        }

        // گارد قطعی باگ «کپی»: هنگام ویرایش/ثبت هیچ‌وقت نباید پسوند «(کپی)» به نام محصول
        // بچسبد (این پسوند فقط محصول باگ‌های قبلیِ فرم تکثیر/پیش‌نویس محلی بود). اگر به هر
        // مسیری در نام ارسالی باقی مانده باشد، همین‌جا پاک می‌شود.
        if (array_key_exists('name_fa', $validated)) {
            $validated['name_fa'] = self::stripCopySuffix($validated['name_fa']);
        }

        // اگر محصول قدیمی هنوز کد ۶ رقمی نداشته باشد، هنگام اولین ویرایش برایش ساخته می‌شود
        if (!$product->product_code) {
            $validated['product_code'] = Product::generateUniqueProductCode();
        }

        $categoryIds = array_values(array_unique(array_filter(array_map('intval', (array) $request->input('category_ids', [])))));
        if (!empty($categoryIds)) {
            $validated['category_id'] = $categoryIds[0];
        }
        if (isset($validated['category_id'])) {
            $validated['category'] = Category::where('id', $validated['category_id'])->value('name') ?? 'عمومی';
        }

        if ($request->hasFile('main_images')) {
            $mainPaths = $this->storeOptimizedImages($request->file('main_images'), 'products/main');
            $oldMainPaths = array_filter(array_merge([$product->cover], (array) $product->sample_outputs));
            $validated['cover'] = array_shift($mainPaths);
            $validated['sample_outputs'] = $mainPaths;
            Storage::disk('public')->delete($oldMainPaths);
        }

        if ($request->hasFile('before_images')) {
            $beforePaths = $this->storeOptimizedImages($request->file('before_images'), 'products/before_images');
            $oldBeforePaths = array_filter((array) $product->before_images);
            $validated['before_images'] = $beforePaths;
            Storage::disk('public')->delete($oldBeforePaths);
        }

        if ($request->hasFile('main_images') || $request->hasFile('before_images')) {
            $validated['images_optimized_at'] = now();
        }

        if ($request->hasFile('new_product_icon')) {
            if ($product->new_product_icon) Storage::disk('public')->delete($product->new_product_icon);
            $validated['new_product_icon'] = $request->file('new_product_icon')->store('product_icons', 'public');
        }

        if ($request->hasFile('og_image')) {
            if ($product->og_image) Storage::disk('public')->delete($product->og_image);
            $validated['og_image'] = $request->file('og_image')->store('products/seo', 'public');
        }

        $validated['is_featured'] = $request->has('is_featured');
        $validated['is_new'] = $request->has('is_new');
        $validated['is_trending'] = $request->has('is_trending');
        $validated['watermark_enabled'] = $request->has('watermark_enabled');
        $validated['card_label_enabled'] = $request->has('card_label_enabled');
        // حفظ هویت — چک‌باکس‌ها و provider_options
        $validated['identity_preservation'] = $request->boolean('identity_preservation');
        $validated['preserve_body'] = $request->has('preserve_body');
        $validated['identity_credit_cost'] = max(0, (int) $request->input('identity_credit_cost', 0));
        $validated['min_reference_images'] = min(3, max(0, (int) $request->input('min_reference_images', 1)));
        $validated['max_reference_images'] = min(3, max(1, (int) $request->input('max_reference_images', 3)));
        $validated['identity_instructions'] = $request->input('identity_instructions')
            ?: ($product->identity_instructions ?: \App\Services\ProductPromptBuilder::defaultIdentityInstructions());
        $validated['identity_instructions_fa'] = $request->input('identity_instructions_fa')
            ?: ($product->identity_instructions_fa ?: \App\Services\ProductPromptBuilder::defaultIdentityInstructionsFa());
        $providerOptionsRaw = $request->input('provider_options');
        $validated['provider_options'] = $providerOptionsRaw ? (json_decode($providerOptionsRaw, true) ?: null) : null;
        if ($request->hasFile('preview_video')) {
            $validated['preview_video_url'] = $this->videoPreviewOptimizer->store($request->file('preview_video'));
        }
        unset($validated['preview_video'], $validated['video_related_photo_product_ids']);
        $validated['seed'] = $request->filled('seed') ? (int) $request->input('seed') : null;

        $exploreTiles = array_values(array_intersect(['1x1','2x2','1x2','2x1'], (array) $request->input('explore_tiles', [])));
        $validated['explore_tiles'] = $exploreTiles ?: ['1x1'];
        // پایپ‌لاین و مدل جایگزین دیگر بخشی از فرم اصلی ثبت محصول نیستند.
        // اگر فرم قدیمی یا یک endpoint تخصصی این فیلدها را صراحتاً فرستاد،
        // رفتار قبلی حفظ می‌شود؛ در غیر این صورت مقدار ذخیره‌شده نباید با
        // ذخیره‌ی یک ویرایش عادی پاک یا خاموش شود.
        if ($request->hasAny(['fallback_enabled', 'fallback_models', 'fallback_providers'])) {
            $fallbackEnabled = $request->boolean('fallback_enabled');
            $validated['fallback_models'] = $fallbackEnabled ? $request->input('fallback_models', []) : [];
            $validated['fallback_model_providers'] = $fallbackEnabled ? $request->input('fallback_providers', []) : [];
        } else {
            unset($validated['fallback_models'], $validated['fallback_model_providers'], $validated['fallback_enabled']);
        }
        $validated['model_configuration'] = $this->normalizeModelConfiguration(
            $request->input('model_configuration', []),
            (array) ($product->model_configuration ?? [])
        );
        $this->applyBusinessTierAsLegacyExecution($product, $validated['model_configuration'], $validated);
        $this->applyQualityCreditPricingAsLegacyFields($product, $validated['model_configuration'], $validated);
        $validated['input_schema'] = $validated['input_schema'] ?? [];
        $validated['allowed_aspect_ratios'] = $this->normalizedAspectRatios(
            $request->input('allowed_aspect_ratios', $product->allowedAspectRatioList())
        );
        $validated['aspect_ratio'] = in_array('3:4', $validated['allowed_aspect_ratios'], true)
            ? '3:4'
            : $validated['allowed_aspect_ratios'][0];
        $validated['allowed_resolutions'] = $this->normalizedResolutions(
            $request->input('allowed_resolutions', $product->allowedResolutionList())
        );
        $validated['output_quality_selector_enabled'] = $request->boolean('output_quality_selector_enabled');
        if ($request->has('pipeline_enabled')) {
            $validated['pipeline_enabled'] = $request->boolean('pipeline_enabled');
        } else {
            unset($validated['pipeline_enabled']);
        }
        $validated['resolution'] = in_array('720', $validated['allowed_resolutions'], true)
            ? '720'
            : $validated['allowed_resolutions'][0];

        $validated['slug'] = Str::slug($validated['slug']);

        if ($request->filled('prompt_template') && $product->prompt_template !== $request->input('prompt_template')) {
            $currentMaxVersion = ProductPromptHistory::where('product_id', $product->id)->max('version_number') ?? 0;
            ProductPromptHistory::create([
                'product_id'     => $product->id,
                'prompt_text'    => $product->prompt_template,
                'version_number' => $currentMaxVersion + 1,
                'user_id'        => auth()->id(),
            ]);
        }

        $product->update($validated);
        $this->attachDraftTests($request, $product);

        if (!empty($categoryIds)) {
            $product->categories()->sync($categoryIds);
        }
        if ($request->boolean('video_mode')) {
            $this->syncVideoPhotoRelations($product, $request);
        }

        if ($request->expectsJson()) {
            session()->flash('success', $request->input('status') === 'draft' ? 'تغییرات محصول به‌صورت پیش‌نویس ذخیره شد.' : 'تغییرات محصول با موفقیت ثبت شد.');
            return response()->json([
                'ok' => true,
                'redirect' => $request->boolean('video_mode') ? route('admin.products.videos') : route('admin.products'),
                'message' => 'تغییرات با موفقیت ثبت شد.',
            ]);
        }

        return redirect()->route($request->boolean('video_mode') ? 'admin.products.videos' : 'admin.products')
            ->with('success', 'تغییرات با موفقیت ثبت شد.');
    }

    /**
     * حذف محصول به همراه فایل‌های فیزیکی
     */
    public function destroy(Product $product)
    {
        $this->removeProduct($product);
        return redirect()->route('admin.products')->with('success', 'محصول حذف شد.');
    }

    /**
     * میانبر جدول محصولات برای بهینه‌سازی امن تمام عکس‌های اصلی و قبل.
     * تا قبل از موفقیت کامل هیچ مسیر قبلی حذف یا در دیتابیس جایگزین نمی‌شود.
     */
    public function optimizeImages(Product $product)
    {
        $lock = Cache::lock('product-image-optimization:' . $product->id, 180);
        if (!$lock->get()) {
            return response()->json(['message' => 'بهینه‌سازی این محصول توسط مدیر دیگری در حال انجام است.'], 409);
        }

        $newlyCreated = [];
        $committed = false;
        try {
            $product->refresh();
            $oldCover = $product->cover;
            $oldSamples = array_values(array_filter((array) $product->sample_outputs));
            $oldBefore = array_values(array_filter((array) $product->before_images));
            $allOldPaths = array_values(array_unique(array_filter(array_merge([$oldCover], $oldSamples, $oldBefore))));

            if ($allOldPaths === []) {
                return response()->json(['message' => 'این محصول تصویری برای بهینه‌سازی ندارد.'], 422);
            }

            $beforeBytes = 0;
            foreach ($allOldPaths as $path) {
                if (Storage::disk('public')->exists($path)) $beforeBytes += (int) Storage::disk('public')->size($path);
            }

            $mapped = [];
            $optimize = function (?string $path, string $directory) use (&$mapped, &$newlyCreated): ?string {
                if (!$path) return null;
                if (isset($mapped[$path])) return $mapped[$path];
                $newPath = $this->imageOptimizer->optimizeStored($path, $directory);
                $mapped[$path] = $newPath;
                if ($newPath !== $path) $newlyCreated[] = $newPath;
                return $newPath;
            };

            $newCover = $optimize($oldCover, 'products/main');
            $newSamples = array_map(fn (string $path) => $optimize($path, 'products/main'), $oldSamples);
            $newBefore = array_map(fn (string $path) => $optimize($path, 'products/before_images'), $oldBefore);

            DB::transaction(function () use ($product, $oldCover, $newCover, $newSamples, $newBefore) {
                $product->cover = $newCover;
                $product->sample_outputs = $newSamples;
                $product->before_images = $newBefore;
                $product->images_optimized_at = now();
                if ($oldCover && $product->thumbnail === $oldCover) $product->thumbnail = $newCover;
                $product->save();
            });
            $committed = true;

            $keptPaths = array_values(array_unique(array_filter(array_merge(
                [$newCover, $product->thumbnail], $newSamples, $newBefore
            ))));
            $obsolete = array_values(array_diff($allOldPaths, $keptPaths));
            if ($obsolete) Storage::disk('public')->delete($obsolete);

            $afterBytes = 0;
            foreach ($keptPaths as $path) {
                if (Storage::disk('public')->exists($path)) $afterBytes += (int) Storage::disk('public')->size($path);
            }

            return response()->json([
                'message' => $newlyCreated
                    ? 'تمام تصاویر محصول با موفقیت بهینه شدند.'
                    : 'تصاویر این محصول از قبل استاندارد بودند.',
                'optimized_count' => count($newlyCreated),
                'image_count' => count($allOldPaths),
                'before_bytes' => $beforeBytes,
                'after_bytes' => $afterBytes,
                'cover_url' => $product->fresh()->displayImageUrl(),
            ]);
        } catch (\Throwable $error) {
            if (!$committed && $newlyCreated) Storage::disk('public')->delete($newlyCreated);
            report($error);
            return response()->json(['message' => 'بهینه‌سازی تصاویر انجام نشد؛ فایل‌های قبلی بدون تغییر حفظ شدند.'], 500);
        } finally {
            $lock->release();
        }
    }

    /**
     * کپی محصول
     */
    public function duplicate(Product $product)
    {
        // نام محصول کپی‌شده دقیقاً همان نام محصول اصلی می‌ماند — هیچ پسوند «(کپی)» یا «-copy»
        // به نام اضافه نمی‌شود (خواسته صریح مدیر). فقط slug و کد محصول، چون باید یکتا باشند،
        // مقدار جدید می‌گیرند.
        $clone = $product->replicate();
        $clone->name_fa = $product->name_fa;
        $clone->name_en = $product->name_en;

        $baseSlug = Str::slug($product->slug . '-2');
        $slug = $baseSlug;
        $i = 1;
        while (Product::where('slug', $slug)->exists()) {
            $slug = $baseSlug . '-' . (++$i);
        }
        $clone->slug = $slug;
        $clone->product_code = Product::generateUniqueProductCode();
        $clone->base_likes_count = random_int(120, 250);
        $clone->status = 'draft';
        $clone->save();

        return redirect()->route('admin.products')->with('success', 'کپی محصول ساخته شد.');
    }

    public function toggleStatus(Product $product)
    {
        $product->status = $product->status === 'active' ? 'inactive' : 'active';
        $product->save();

        return request()->wantsJson() 
            ? response()->json(['status' => $product->status]) 
            : redirect()->route('admin.products');
    }

    /**
     * ویرایش سریع هزینه کردیت از منوی همان ردیف در لیست محصولات.
     */
    public function updateCredit(Request $request, Product $product)
    {
        $validated = $request->validate([
            'credit_cost' => ['required', 'integer', 'min:0', 'max:1000000'],
            'note' => ['nullable', 'string', 'max:255'],
        ]);

        [$product, $log] = DB::transaction(function () use ($request, $product, $validated) {
            $lockedProduct = Product::whereKey($product->id)->lockForUpdate()->firstOrFail();
            $before = (int) $lockedProduct->credit_cost;
            $after = (int) $validated['credit_cost'];

            $lockedProduct->forceFill([
                'credit_cost' => $after,
                'pricing_model' => $after === 0 ? 'free' : 'per_credit',
            ])->save();

            $log = ProductCreditLog::create([
                'product_id' => $lockedProduct->id,
                'admin_id' => $request->user('admin')?->id,
                'action' => 'set',
                'amount' => $after,
                'credit_before' => $before,
                'credit_after' => $after,
                'note' => $validated['note'] ?? null,
                'ip_address' => $request->ip(),
                'user_agent' => Str::limit((string) $request->userAgent(), 1000, ''),
            ]);

            return [$lockedProduct, $log];
        });

        return response()->json([
            'ok' => true,
            'credit_cost' => $product->credit_cost,
            'pricing_model' => $product->pricing_model,
            'message' => 'کردیت محصول با موفقیت تغییر کرد و در تاریخچه ثبت شد.',
            'log' => [
                'id' => $log->id,
                'credit_before' => $log->credit_before,
                'credit_after' => $log->credit_after,
                'admin' => $request->user('admin')?->name,
                'created_at' => $log->created_at?->toDateTimeString(),
            ],
        ]);
    }

    /** تغییر سریع مدل اصلی یک محصول، مستقل از فرم چندمرحله‌ای ثبت محصول. */
    public function updateAiModel(Request $request, Product $product)
    {
        $model = $this->validateAssignableAiModel($request);

        $product->forceFill([
            'primary_model' => $model->openrouter_model_id,
            'ai_provider' => $model->provider,
        ])->save();

        return response()->json([
            'ok' => true,
            'product_id' => $product->id,
            'provider' => $model->provider,
            'model_id' => $model->openrouter_model_id,
            'model_name' => $model->shortDisplayName(),
            'message' => 'مدل هوش مصنوعی محصول ذخیره شد.',
        ]);
    }

    /** تغییر مدل اصلی چند محصول انتخاب‌شده، بدون تغییر سایر تنظیمات AI آن‌ها. */
    public function bulkUpdateAiModel(Request $request)
    {
        $validated = $request->validate([
            'ids' => ['required', 'array', 'min:1', 'max:500'],
            'ids.*' => ['integer', 'distinct', 'exists:products,id'],
        ]);
        $model = $this->validateAssignableAiModel($request);

        $updated = Product::whereIn('id', $validated['ids'])->update([
            'primary_model' => $model->openrouter_model_id,
            'ai_provider' => $model->provider,
            'updated_at' => now(),
        ]);

        return response()->json([
            'ok' => true,
            'updated' => $updated,
            'provider' => $model->provider,
            'model_id' => $model->openrouter_model_id,
            'model_name' => $model->shortDisplayName(),
            'message' => "مدل هوش مصنوعی {$updated} محصول تغییر کرد.",
        ]);
    }

    /** اعمال یکی از چهار پیش‌تنظیم مدل روی یک محصول، بدون پاک‌شدن سایر تنظیمات آن. */
    public function applyModelTierPreset(Request $request, Product $product)
    {
        $tierKey = $this->validatedTierPreset($request);
        $this->applyTierPresetToProduct($product, $tierKey);

        return response()->json([
            'ok' => true,
            'product_id' => $product->id,
            'tier_key' => $tierKey,
            'message' => 'چهار سطح مدل محصول با پیش‌تنظیم انتخاب‌شده به‌روزرسانی شد.',
        ]);
    }

    /** ذخیره مستقیم چهار سطح مدل از پنجره‌ی تغییر سریع لیست محصولات. */
    public function updateModelTierConfiguration(Request $request, Product $product)
    {
        $data = $request->validate([
            'tiers' => ['required', 'array'],
            'tiers.*.primary.model_id' => ['nullable', 'string', 'max:255'],
            'tiers.*.primary.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'tiers.*.fallback.model_id' => ['nullable', 'string', 'max:255'],
            'tiers.*.fallback.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
        ]);
        $this->validateModelTierEntries($data['tiers'], true);

        $configuration = $this->normalizeModelConfiguration(
            ['tiers' => $data['tiers']],
            (array) ($product->model_configuration ?? [])
        );
        $configuration['applied_preset'] = 'custom';
        $product->model_configuration = $configuration;
        $this->applyBusinessTierAsLegacyExecution($product, $configuration);
        $this->applyQualityCreditPricingAsLegacyFields($product, $configuration);
        $product->save();

        return response()->json([
            'ok' => true,
            'product_id' => $product->id,
            'configuration' => $product->fresh()->model_configuration,
            'message' => 'چهار سطح مدل محصول ذخیره شد.',
        ]);
    }

    /**
     * ذخیره معماری سه کیفیت پرداختی و دو مسیر کاربر رایگان از پنجره‌ی یکپارچه
     * لیست محصولات. این همان ساختاری است که گام دوم فرم ثبت محصول ذخیره می‌کند.
     */
    public function updateModelQualityConfiguration(Request $request, Product $product)
    {
        $data = $request->validate([
            'model_configuration' => ['required', 'array'],
            'update_preset' => ['sometimes', 'boolean'],
            ...$this->modelTierRules(),
        ]);

        $configuration = $this->normalizeAndValidateQualityModelConfiguration(
            (array) $data['model_configuration'],
            (array) ($product->model_configuration ?? [])
        );

        DB::transaction(function () use ($request, $product, $configuration): void {
            if ($request->boolean('update_preset')) {
                $this->updateSelectedQualityPreset($configuration);
            }
            $product->model_configuration = $configuration;
            $this->applyBusinessTierAsLegacyExecution($product, $configuration);
            $this->applyQualityCreditPricingAsLegacyFields($product, $configuration);
            $product->save();
        });

        return response()->json([
            'ok' => true,
            'product_id' => $product->id,
            'configuration' => $product->fresh()->model_configuration,
            'message' => 'معماری مدل‌های هوش مصنوعی محصول ذخیره شد.',
        ]);
    }

    /** اعمال فقط پیش‌فرض مصرف اعتبار؛ مدل‌های اصلی و جایگزین دست‌نخورده می‌مانند. */
    public function applyQualityCreditPreset(Request $request, Product $product)
    {
        $data = $request->validate([
            'preset_key' => ['required', Rule::exists('product_credit_presets', 'preset_key')],
        ]);
        $preset = ProductCreditPreset::query()->where('preset_key', $data['preset_key'])->firstOrFail();
        $costs = $preset->costs();
        $product->model_configuration = $this->normalizeModelConfiguration([
            'quality_credit_costs' => $costs,
            'quality_credit_preset_key' => $preset->preset_key,
        ], (array) ($product->model_configuration ?? []));
        $this->applyQualityCreditPricingAsLegacyFields($product, $product->model_configuration);
        $product->save();

        return response()->json([
            'ok' => true,
            'product_id' => $product->id,
            'preset_key' => $preset->preset_key,
            'costs' => $costs,
            'message' => "پیش‌فرض مصرف اعتبار «{$preset->name}» روی محصول اعمال شد.",
        ]);
    }

    /** اعمال فقط پیش‌فرض مصرف اعتبار روی محصولات انتخاب‌شده در لیست. */
    public function bulkApplyQualityCreditPreset(Request $request)
    {
        $data = $request->validate([
            'ids' => ['required', 'array', 'min:1', 'max:500'],
            'ids.*' => ['integer', 'distinct', 'exists:products,id'],
            'preset_key' => ['nullable', Rule::exists('product_credit_presets', 'preset_key')],
            'costs' => ['nullable', 'array'],
            'costs.standard' => ['nullable', 'integer', 'min:1', 'max:1000000'],
            'costs.professional' => ['nullable', 'integer', 'min:1', 'max:1000000'],
            'costs.best' => ['nullable', 'integer', 'min:1', 'max:1000000'],
        ]);
        if (blank($data['preset_key'] ?? null) && ! $this->hasCompleteCreditCosts($data['costs'] ?? [])) {
            throw ValidationException::withMessages(['costs' => 'یا یک پیش‌فرض انتخاب کنید یا هر سه مقدار اعتبار را کامل وارد کنید.']);
        }
        $preset = filled($data['preset_key'] ?? null)
            ? ProductCreditPreset::query()->where('preset_key', $data['preset_key'])->firstOrFail()
            : null;
        $costs = $preset?->costs() ?: $this->normalizeCreditCosts((array) $data['costs']);
        $presetKey = $preset?->preset_key ?: 'custom';

        $updated = DB::transaction(function () use ($data, $costs, $presetKey): int {
            $products = Product::query()->whereIn('id', $data['ids'])->lockForUpdate()->get();
            foreach ($products as $product) {
                $product->model_configuration = $this->normalizeModelConfiguration([
                    'quality_credit_costs' => $costs,
                    'quality_credit_preset_key' => $presetKey,
                ], (array) ($product->model_configuration ?? []));
                $this->applyQualityCreditPricingAsLegacyFields($product, $product->model_configuration);
                $product->save();
            }
            return $products->count();
        });

        return response()->json([
            'ok' => true,
            'updated' => $updated,
            'preset_key' => $presetKey,
            'costs' => $costs,
            'message' => $preset
                ? "پیش‌فرض مصرف اعتبار «{$preset->name}» روی {$updated} محصول اعمال شد."
                : "مصرف اعتبار سفارشی روی {$updated} محصول اعمال شد.",
        ]);
    }

    private function hasCompleteCreditCosts(array $costs): bool
    {
        foreach (array_keys(Product::DEFAULT_QUALITY_CREDIT_COSTS) as $quality) {
            if (! is_numeric($costs[$quality] ?? null) || (int) $costs[$quality] < 1 || (int) $costs[$quality] > 1000000) {
                return false;
            }
        }
        return true;
    }

    private function normalizeCreditCosts(array $costs): array
    {
        return collect(Product::DEFAULT_QUALITY_CREDIT_COSTS)
            ->mapWithKeys(fn (int $default, string $quality) => [$quality => max(1, min(1000000, (int) ($costs[$quality] ?? $default)))])
            ->all();
    }

    /** اعمال یک معماری کیفیت واحد روی همهٔ محصولات انتخاب‌شده. */
    public function bulkUpdateModelQualityConfiguration(Request $request)
    {
        $data = $request->validate([
            'ids' => ['required', 'array', 'min:1', 'max:500'],
            'ids.*' => ['integer', 'distinct', 'exists:products,id'],
            // در حالت «اعمال پیش‌فرض»، فقط کلید پیش‌فرض ارسال می‌شود و
            // پیکربندی معتبر از خود دیتابیس خوانده می‌شود؛ این کار جلوی
            // وابستگی عملیات گروهی به داده‌ی ناقص یا قدیمیِ مرورگر را می‌گیرد.
            'preset_key' => ['nullable', Rule::exists('model_quality_presets', 'preset_key')],
            'model_configuration' => ['nullable', 'array'],
            'update_preset' => ['sometimes', 'boolean'],
            ...$this->modelTierRules(),
        ]);

        if ($request->boolean('update_preset') && filled($data['preset_key'] ?? null)) {
            throw ValidationException::withMessages([
                'update_preset' => 'برای ویرایش پیش‌فرض، تنظیمات کامل مدل را ارسال کنید.',
            ]);
        }

        $presetKey = filled($data['preset_key'] ?? null) ? (string) $data['preset_key'] : null;
        $rawConfiguration = (array) ($data['model_configuration'] ?? []);

        if ($presetKey) {
            $preset = ModelQualityPreset::query()->where('preset_key', $presetKey)->first();
            if (! $preset) {
                throw ValidationException::withMessages([
                    'preset_key' => 'پیش‌فرض انتخاب‌شده در نسخه‌ی فعلی سایت موجود نیست. ابتدا migrationهای دیتابیس را اجرا کنید.',
                ]);
            }
            $rawConfiguration = array_replace(
                (array) $preset->configuration,
                ['quality_preset_key' => $preset->preset_key]
            );
        }

        if (! $rawConfiguration) {
            throw ValidationException::withMessages([
                'model_configuration' => 'ابتدا یک پیش‌فرض یا تنظیمات کامل مدل را انتخاب کنید.',
            ]);
        }

        // اعتبارسنجی مستقل از محصول انجام می‌شود؛ سپس برای هر محصول با تنظیمات
        // قبلی ادغام می‌کنیم تا داده‌های نامرتبط (پرامپت/سطوح قدیمی) از بین نروند.
        $this->normalizeAndValidateQualityModelConfiguration($rawConfiguration);

        $updated = DB::transaction(function () use ($data, $rawConfiguration, $request) {
            if ($request->boolean('update_preset')) {
                $this->updateSelectedQualityPreset($rawConfiguration);
            }
            $products = Product::whereIn('id', $data['ids'])->lockForUpdate()->get();
            foreach ($products as $product) {
                $configuration = $this->normalizeAndValidateQualityModelConfiguration(
                    $rawConfiguration,
                    (array) ($product->model_configuration ?? [])
                );
                $product->model_configuration = $configuration;
                $this->applyBusinessTierAsLegacyExecution($product, $configuration);
                $this->applyQualityCreditPricingAsLegacyFields($product, $configuration);
                $product->save();
            }
            return $products->count();
        });

        return response()->json([
            'ok' => true,
            'updated' => $updated,
            'preset_key' => $presetKey,
            'message' => $presetKey
                ? "پیش‌فرض مدل «{$presetKey}» روی {$updated} محصول اعمال شد."
                : "معماری مدل‌های هوش مصنوعی {$updated} محصول ذخیره شد.",
        ]);
    }

    /** ذخیره یک معماری کامل روی همان پیش‌فرض و همهٔ محصولات متصل به آن. */
    private function updateSelectedQualityPreset(array $configuration): void
    {
        $key = (string) ($configuration['quality_preset_key'] ?? '');
        $preset = $key !== 'custom'
            ? ModelQualityPreset::query()->where('preset_key', $key)->lockForUpdate()->first()
            : null;
        if (! $preset) {
            throw ValidationException::withMessages([
                'model_configuration.quality_preset_key' => 'یک پیش‌فرض معتبر را برای ذخیره انتخاب کنید.',
            ]);
        }

        $modelConfiguration = $this->mergeQualityModelConfiguration($configuration);
        $this->validateQualityModelEntries(
            (array) $modelConfiguration['quality_models'],
            (array) $modelConfiguration['free_quality_models'],
            true
        );

        $preset->configuration = app(ImageGenerationRetryPolicy::class)->withDefaults(
            array_replace(
                (array) $preset->configuration,
                $modelConfiguration,
                ['quality_architecture_enabled' => filter_var(
                    $configuration['quality_architecture_enabled'] ?? true,
                    FILTER_VALIDATE_BOOLEAN
                )]
            )
        );
        $preset->save();
        app(ModelQualityPresetSync::class)->synchronize($preset);
    }

    /** اعمال یک پیش‌تنظیم روی همه محصولات منتخب در لیست. */
    public function bulkApplyModelTierPreset(Request $request)
    {
        $validated = $request->validate([
            'ids' => ['required', 'array', 'min:1', 'max:500'],
            'ids.*' => ['integer', 'distinct', 'exists:products,id'],
        ]);
        $tierKey = $this->validatedTierPreset($request);
        $products = Product::whereIn('id', $validated['ids'])->get();
        foreach ($products as $product) {
            $this->applyTierPresetToProduct($product, $tierKey);
        }

        return response()->json([
            'ok' => true,
            'updated' => $products->count(),
            'tier_key' => $tierKey,
            'message' => "چهار سطح مدل {$products->count()} محصول به‌روزرسانی شد.",
        ]);
    }

    public function bulkAction(Request $request)
    {
        $validated = $request->validate([
            'action'     => 'required|in:activate,deactivate,delete,change_category,set_credit',
            'ids'        => 'required|array|min:1|max:5000',
            'ids.*'      => 'integer|exists:products,id',
            'category_id' => 'nullable|integer|exists:categories,id',
            'credit_cost' => ['required_if:action,set_credit', 'nullable', 'integer', 'min:0', 'max:1000000'],
            'note'        => ['nullable', 'string', 'max:255'],
        ]);

        $products = Product::whereIn('id', $validated['ids']);

        switch ($validated['action']) {
            case 'activate':
                $products->update(['status' => 'active']);
                break;
            case 'deactivate':
                $products->update(['status' => 'inactive']);
                break;
            case 'change_category':
                $categoryName = Category::where('id', $validated['category_id'])->value('name') ?? 'عمومی';
                $products->update(['category_id' => $validated['category_id'], 'category' => $categoryName]);
                break;
            case 'set_credit':
                $creditCost = (int) $validated['credit_cost'];
                $note = $validated['note'] ?? 'تغییر گروهی هزینه‌ی محصول';
                $adminId = $request->user('admin')?->id;
                $userAgent = Str::limit((string) $request->userAgent(), 1000, '');

                DB::transaction(function () use ($validated, $creditCost, $note, $adminId, $request, $userAgent) {
                    $lockedProducts = Product::whereIn('id', $validated['ids'])
                        ->lockForUpdate()
                        ->get();

                    foreach ($lockedProducts as $product) {
                        $before = (int) $product->credit_cost;
                        $product->forceFill([
                            'credit_cost' => $creditCost,
                            'pricing_model' => $creditCost === 0 ? 'free' : 'per_credit',
                        ])->save();

                        ProductCreditLog::create([
                            'product_id' => $product->id,
                            'admin_id' => $adminId,
                            'action' => 'set',
                            'amount' => $creditCost,
                            'credit_before' => $before,
                            'credit_after' => $creditCost,
                            'note' => $note,
                            'ip_address' => $request->ip(),
                            'user_agent' => $userAgent,
                        ]);
                    }
                });
                break;
            case 'delete':
                foreach ($products->get() as $product) {
                    $this->removeProduct($product);
                }
                break;
        }

        $message = $validated['action'] === 'set_credit'
            ? 'هزینه‌ی کردیت محصولات انتخاب‌شده با موفقیت تغییر کرد.'
            : 'عملیات گروهی انجام شد.';

        return redirect()->route('admin.products')->with('success', $message);
    }

    /**
     * حذف قطعی از فهرست عمومی: وضعیت را غیرفعال و رکورد را soft-delete می‌کند.
     * این ترکیب حتی مسیرهای قدیمیِ فیلترشده فقط با status را هم پوشش می‌دهد.
     */
    private function removeProduct(Product $product): void
    {
        foreach ([
            $product->thumbnail,
            $product->cover,
            $product->new_product_icon,
            $product->og_image,
            ...((array) $product->sample_outputs),
            ...((array) $product->before_images),
        ] as $path) {
            if (is_string($path) && $path !== '') {
                Storage::disk('public')->delete($path);
            }
        }

        $product->forceFill(['status' => 'inactive'])->saveQuietly();
        $product->delete();
    }

    /** اتصال آزمایش‌هایی که پیش از اولین ذخیره محصول اجرا شده‌اند به رکورد محصول. */
    private function attachDraftTests(Request $request, Product $product): void
    {
        $draftUuid = $request->input('test_draft_uuid');
        if (!$draftUuid || !Str::isUuid($draftUuid)) return;

        ProductTestRun::whereNull('product_id')->where('draft_uuid', $draftUuid)->update(['product_id' => $product->id]);
        $latestDuration = ProductTestRun::where('product_id', $product->id)->where('status', 'completed')->latest()->value('duration_ms');
        $totalTokens = ProductTestRun::where('product_id', $product->id)->where('status', 'completed')->sum('total_tokens');
        $product->forceFill(['last_test_duration_ms' => $latestDuration, 'total_test_tokens' => $totalTokens])->saveQuietly();
    }

    /**
     * حذف پسوند سیستمی «(کپی)» از انتهای نام فارسی محصول.
     * این پسوند فقط توسط باگ‌های قبلی فرم تکثیر/بازیابی پیش‌نویس محلی ساخته می‌شد؛
     * حالت چندباره «نام (کپی) (کپی)» هم پوشش داده می‌شود. عمداً فقط شکل پرانتزدار
     * حذف می‌شود تا نام‌هایی که واقعاً به کلمه «کپی» ختم می‌شوند دست‌نخورده بمانند.
     */
    private static function stripCopySuffix(?string $name): ?string
    {
        if ($name === null) {
            return null;
        }

        $clean = trim($name);
        while (preg_match('/^(.*?)\s*\(\s*کپی\s*\)$/u', $clean, $m) && trim($m[1]) !== '') {
            $clean = trim($m[1]);
        }

        return $clean !== '' ? $clean : trim($name);
    }

    /** قواعد مستقل پاداش مالک محصول؛ رفرال و هزینه‌ی اجرای کاربر وارد این قرارداد نیستند. */
    private function creatorRewardRules(Request $request): array
    {
        $enabled = $request->boolean('creator_reward_enabled');
        $required = Rule::requiredIf($enabled);

        return [
            'creator_reward_enabled' => ['nullable', 'boolean'],
            'creator_reward_owner_id' => [$required, 'nullable', 'integer', 'exists:users,id'],
            'creator_reward_settings' => [$required, 'nullable', 'array'],
            'creator_reward_settings.image_free' => [$required, 'nullable', 'integer', 'min:0', 'max:1000000'],
            'creator_reward_settings.video_free' => [$required, 'nullable', 'integer', 'min:0', 'max:1000000'],
            'creator_reward_settings.image_paid' => [$required, 'nullable', 'integer', 'min:0', 'max:1000000'],
            'creator_reward_settings.video_paid' => [$required, 'nullable', 'integer', 'min:0', 'max:1000000'],
        ];
    }

    /** مالک قبلی محصول تا زمان آزادشدن، قابل جایگزینی با کاربر دیگری نیست. */
    private function ensureCreatorRewardOwnerCanBeChanged(Product $product, ?int $requestedOwnerId): void
    {
        $currentOwnerId = (int) ($product->getRawOriginal('creator_reward_owner_id') ?? 0);
        $requestedOwnerId = (int) ($requestedOwnerId ?? 0);

        if ($currentOwnerId > 0 && $requestedOwnerId > 0 && $currentOwnerId !== $requestedOwnerId) {
            throw ValidationException::withMessages([
                'creator_reward_owner_id' => 'این محصول قبلاً به کاربر دیگری اختصاص داده شده و قابل اختصاص به کاربر دوم نیست.',
            ]);
        }
    }

    /** مقدارهای پاداش با کلیدهای محدود و عددهای غیرمنفی در دیتابیس ذخیره می‌شوند. */
    private function normalizeCreatorRewardSettings(array $settings, array $fallback = []): array
    {
        $defaults = [
            'image_free' => 1,
            'video_free' => 2,
            'image_paid' => 2,
            'video_paid' => 4,
        ];

        return collect($defaults)->mapWithKeys(function (int $default, string $key) use ($settings, $fallback): array {
            $value = $settings[$key] ?? $fallback[$key] ?? $default;
            return [$key => is_numeric($value) ? max(0, (int) $value) : $default];
        })->all();
    }

    /**
     * قرارداد بک‌اند سازنده «ویژگی‌های خاص».
     * فقط کلیدهای شناخته‌شده را وارد JSON محصول می‌کند تا ساختار ناقص یا داده
     * دلخواه سمت کلاینت، رندر فرم کاربر و ساخت پرامپت را خراب نکند.
     */
    private function inputSchemaRules(): array
    {
        return [
            'input_schema' => ['nullable', 'array', 'max:50'],
            'input_schema.*' => ['array'],
            'input_schema.*.field_id' => ['required', 'string', 'max:80', 'regex:/^[a-z][a-z0-9_]*$/', 'distinct:strict'],
            'input_schema.*.label_fa' => ['required', 'string', 'max:150'],
            'input_schema.*.type' => ['required', 'string', Rule::in(array_keys(config('product_schema_types.types', [])))],
            'input_schema.*.required' => ['required', Rule::in(['0', '1', 0, 1])],
            'input_schema.*.hidden' => ['nullable', Rule::in(['0', '1', 0, 1])],
            'input_schema.*.order' => ['nullable', 'integer', 'min:0', 'max:49'],
            'input_schema.*.description' => ['nullable', 'string', 'max:500'],
            'input_schema.*.help_text' => ['nullable', 'string', 'max:500'],
            'input_schema.*.placeholder' => ['nullable', 'string', 'max:255'],
            'input_schema.*.default' => ['nullable'],
            'input_schema.*.credit_cost' => ['nullable', 'integer', 'min:0'],
            'input_schema.*.variant' => ['nullable', Rule::in(['info', 'warning', 'success'])],
            'input_schema.*.min' => ['nullable', 'numeric'],
            'input_schema.*.max' => ['nullable', 'numeric'],
            'input_schema.*.step' => ['nullable', 'numeric', 'gt:0'],
            'input_schema.*.regex' => ['nullable', 'string', 'max:255'],
            'input_schema.*.unit' => ['nullable', 'string', 'max:30'],
            'input_schema.*.max_files' => ['nullable', 'integer', 'min:1', 'max:20'],
            'input_schema.*.max_size_mb' => ['nullable', 'integer', 'min:1', 'max:100'],
            'input_schema.*.accept' => ['nullable', 'string', 'max:255'],
            'input_schema.*.prompt_mode' => ['nullable', Rule::in(['token', 'append', 'off'])],
            'input_schema.*.prompt_wrap' => ['nullable', 'string', 'max:500'],
            'input_schema.*.show_if' => ['nullable', 'array'],
            'input_schema.*.show_if.field' => ['nullable', 'string', 'max:80'],
            'input_schema.*.show_if.op' => ['nullable', Rule::in(['eq', 'neq', 'has', 'not_empty'])],
            'input_schema.*.show_if.value' => ['nullable', 'string', 'max:255'],
            'input_schema.*.options' => ['nullable', 'array', 'max:100'],
            'input_schema.*.options.*' => ['array'],
            'input_schema.*.options.*.label' => ['nullable', 'string', 'max:150'],
            'input_schema.*.options.*.value' => ['nullable', 'string', 'max:150'],
            'input_schema.*.options.*.prompt' => ['nullable', 'string', 'max:500'],
            'input_schema.*.options.*.credit' => ['nullable', 'integer', 'min:0'],
            'input_schema.*.options.*.image' => ['nullable', 'string', 'max:2048'],
        ];
    }

    /**
     * JSON واحد سازنده ویژگی‌ها را به قرارداد داخلی input_schema تبدیل می‌کند.
     *
     * این مسیر تعداد متغیرهای multipart را مستقل از تعداد گزینه‌های هر ویژگی
     * نگه می‌دارد و از قطع/ناقص‌شدن درخواست توسط max_input_vars جلوگیری می‌کند.
     * اگر کلاینت قدیمی JSON نفرستد، input_schema تو‌در‌تو بدون تغییر پذیرفته
     * می‌شود تا سازگاری عقب‌رو حفظ شود.
     */
    private function mergeInputSchemaJson(Request $request): void
    {
        if (!$request->exists('input_schema_json')) {
            return;
        }

        $request->validate([
            'input_schema_json' => ['required', 'string', 'max:524288', 'json'],
        ]);

        $schema = json_decode((string) $request->input('input_schema_json'), true);
        $request->merge(['input_schema' => $schema]);
    }

    private function copyDuplicateFile(string $sourcePath, string $targetDir): string
    {
        $extension = pathinfo($sourcePath, PATHINFO_EXTENSION) ?: 'jpg';
        $newPath = $targetDir . '/' . (string) Str::uuid() . '.' . $extension;
        Storage::disk('public')->copy($sourcePath, $newPath);
        return $newPath;
    }

    private function copyDuplicateFiles(array $sourcePaths, string $targetDir): array
    {
        $copies = [];
        foreach ($sourcePaths as $sourcePath) {
            if (is_string($sourcePath) && Storage::disk('public')->exists($sourcePath)) {
                $copies[] = $this->copyDuplicateFile($sourcePath, $targetDir);
            }
        }
        return $copies;
    }

    /**
     * شناسه مدل ممکن است بین providerها یکسان باشد؛ بنابراین علاوه
     * بر شناسه، تعلق مدل به provider انتخاب‌شده را هم در سمت سرور قطعی می‌کنیم.
     */
    private function validateAiProviderSelection(Request $request): void
    {
        if ((is_array($request->input('model_configuration.tiers')) && !empty($request->input('model_configuration.tiers')))
            || (is_array($request->input('model_configuration.quality_models')) && !empty($request->input('model_configuration.quality_models')))) {
            return;
        }
        $provider = $request->input('ai_provider');
        $primaryModel = $request->input('primary_model');

        if (!$provider || !$primaryModel) {
            return;
        }

        $primaryIsValid = $this->assignableAiModels()
            ->where('provider', $provider)
            ->where('openrouter_model_id', $primaryModel)
            ->exists();

        if (!$request->boolean('fallback_enabled')) {
            if (!$primaryIsValid) {
                throw ValidationException::withMessages([
                    'primary_model' => 'مدل اصلی باید متعلق به سرویس انتخاب‌شده و فعال باشد.',
                ]);
            }
            return;
        }

        $fallbacks = array_values(array_filter((array) $request->input('fallback_models', [])));
        $fallbackProviders = array_values((array) $request->input('fallback_providers', []));
        $fallbacksAreValid = count($fallbacks) === count($fallbackProviders);
        foreach ($fallbacks as $index => $fallbackModel) {
            $fallbackProvider = $fallbackProviders[$index] ?? null;
            if (!$fallbackProvider || !$this->assignableAiModels()
                ->where('provider', $fallbackProvider)
                ->where('openrouter_model_id', $fallbackModel)
                ->exists()) {
                $fallbacksAreValid = false;
                break;
            }
        }

        $hasPrimaryAsFallback = collect($fallbacks)->contains(function ($fallbackModel, $index) use ($primaryModel, $provider, $fallbackProviders) {
            return $fallbackModel === $primaryModel && ($fallbackProviders[$index] ?? null) === $provider;
        });
        if (count($fallbacks) < 1 || count($fallbacks) > 5 || $hasPrimaryAsFallback) {
            $fallbacksAreValid = false;
        }

        if (!$primaryIsValid || !$fallbacksAreValid) {
            throw ValidationException::withMessages([
                'primary_model' => 'مدل اصلی باید متعلق به سرویس انتخاب‌شده باشد و تمام مدل‌های جایگزین باید فعال باشند.',
            ]);
        }
    }

    /**
     * مدل اصلی را با کلید مرکب provider + model id برمی‌گرداند.
     * شناسه مدل به‌تنهایی یکتا نیست و ممکن است بین providerها مشترک باشد.
     */
    private function selectedAiModel(Request $request): ?AiModel
    {
        $provider = (string) $request->input('ai_provider');
        $modelId = (string) $request->input('primary_model');

        if ($provider === '' || $modelId === '') {
            return null;
        }

        return $this->assignableAiModels()
            ->where('provider', $provider)
            ->where('openrouter_model_id', $modelId)
            ->first();
    }

    /** Query واحد مدل‌های مجاز برای ثبت محصول، ویرایش و تغییر سریع از لیست. */
    private function assignableAiModels()
    {
        return AiModel::query()->selectableForProduct();
    }

    private function validateAssignableAiModel(Request $request): AiModel
    {
        $validated = $request->validate([
            'ai_provider' => ['required', Rule::in(ProviderStatus::PROVIDERS)],
            'primary_model' => ['required', 'string', 'max:255'],
        ]);

        $model = $this->assignableAiModels()
            ->where('provider', $validated['ai_provider'])
            ->where('openrouter_model_id', $validated['primary_model'])
            ->first();

        if (!$model) {
            throw ValidationException::withMessages([
                'primary_model' => 'مدل انتخاب‌شده معتبر یا قابل استفاده نیست.',
            ]);
        }

        return $model;
    }

    private function applyAiModelStatusFilter($query, string $status, array $validModelsByProvider): void
    {
        $validCondition = function ($validQuery) use ($validModelsByProvider) {
            foreach ($validModelsByProvider as $provider => $modelIds) {
                $validQuery->orWhere(function ($providerQuery) use ($provider, $modelIds) {
                    $providerQuery->where('ai_provider', $provider)
                        ->whereIn('primary_model', $modelIds ?: ['__none__']);
                });
            }
        };

        if ($status === 'valid') {
            $query->where($validCondition);
        } elseif ($status === 'unassigned') {
            $query->where(function ($missing) {
                $missing->whereNull('primary_model')->orWhere('primary_model', '')
                    ->orWhereNull('ai_provider')->orWhere('ai_provider', '');
            });
        } elseif ($status === 'invalid') {
            $query->where(function ($invalid) use ($validCondition) {
                $invalid->whereNull('primary_model')->orWhere('primary_model', '')
                    ->orWhereNull('ai_provider')->orWhere('ai_provider', '')
                    ->orWhereNot($validCondition);
            });
        }
    }

    /** تنظیمات اختصاصی ویدیو را به همان فرم اصلی محصول وصل می‌کند. */
    private function prepareVideoAdminRequest(Request $request, ?Product $product = null): void
    {
        $rawVideo = (array) $request->input('video_config', []);
        $existingVideo = $product?->videoConfiguration() ?? [];
        $video = [
            'workflow' => $rawVideo['workflow'] ?? data_get($existingVideo, 'workflow', 'image_to_video'),
            'face_profile_mode' => $rawVideo['face_profile_mode'] ?? data_get($existingVideo, 'face_profile_mode', 'disabled'),
            'durations' => $rawVideo['durations'] ?? data_get($existingVideo, 'durations', [4, 6, 8]),
            'default_duration' => $rawVideo['default_duration'] ?? data_get($existingVideo, 'default_duration', 6),
            'aspect_ratios' => $rawVideo['aspect_ratios'] ?? data_get($existingVideo, 'aspect_ratios', ['16:9', '9:16', '1:1']),
            'default_aspect_ratio' => $rawVideo['default_aspect_ratio'] ?? data_get($existingVideo, 'default_aspect_ratio', '16:9'),
            'preserve_source_aspect_ratio' => $request->boolean('video_preserve_source_aspect_ratio'),
            'resolutions' => $rawVideo['resolutions'] ?? data_get($existingVideo, 'resolutions', ['480p', '720p', '1080p']),
            'default_resolution' => $rawVideo['default_resolution'] ?? data_get($existingVideo, 'default_resolution', '720p'),
            'fps' => $rawVideo['fps'] ?? data_get($existingVideo, 'fps', 24),
            'motion_presets' => $rawVideo['motion_presets'] ?? data_get($existingVideo, 'motion_presets', ['static', 'dolly_in']),
            'audio_allowed' => $request->boolean('video_audio_allowed'),
            'audio_default' => $request->boolean('video_audio_default'),
            'prompt_enhance' => $request->boolean('video_prompt_enhance'),
            'credit_costs_by_duration' => $rawVideo['credit_costs_by_duration'] ?? data_get($existingVideo, 'credit_costs_by_duration', []),
            'quality_costs' => $rawVideo['quality_costs'] ?? data_get($existingVideo, 'quality_costs', []),
            'quality_tiers' => $rawVideo['quality_tiers'] ?? data_get($existingVideo, 'quality_tiers', []),
            'quality_credit_costs' => (array) $request->input('video_quality_credit_costs', $request->input('model_configuration.quality_credit_costs', data_get($existingVideo, 'quality_credit_costs', Product::DEFAULT_QUALITY_CREDIT_COSTS))),
        ];
        $video = app(VideoProductConfigService::class)->normalize($video);

        $providerOptions = (array) (json_decode((string) $request->input('provider_options', ''), true) ?: []);
        $providerOptions['video'] = $video;
        $modelConfiguration = (array) $request->input('model_configuration', []);
        $modelConfiguration['quality_credit_costs'] = $video['quality_credit_costs'];

        $ratioMap = ['480p' => '480', '720p' => '720', '1080p' => '1080', '4K' => '2160'];
        $allowedResolutions = array_values(array_unique(array_filter(array_map(
            fn (string $value): ?string => $ratioMap[$value] ?? null,
            $video['resolutions']
        ))));
        $allowedResolutions = $allowedResolutions ?: ['720'];
        $allowedRatios = array_values(array_intersect(Product::supportedAspectRatios(), $video['aspect_ratios']));
        $allowedRatios = $allowedRatios ?: ['16:9'];

        $request->merge([
            'video_mode' => true,
            'media_type' => 'video',
            'output_type' => 'video',
            'output_format' => 'mp4',
            'pipeline_type' => 'video_generation',
            'delivery_method' => 'queued',
            'output_quality_selector_enabled' => true,
            'allowed_aspect_ratios' => $allowedRatios,
            'allowed_resolutions' => $allowedResolutions,
            'provider_options' => json_encode($providerOptions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'model_configuration' => $modelConfiguration,
        ]);
    }

    private function syncVideoPhotoRelations(Product $videoProduct, Request $request): void
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', (array) $request->input('video_related_photo_product_ids', [])))));
        $videoProduct->sourcePhotoProducts()->sync(
            collect($ids)->values()->mapWithKeys(fn (int $id, int $index): array => [$id => ['sort_order' => $index, 'is_active' => true]])->all()
        );
    }

    private function storeOptimizedImages(array $files, string $directory): array
    {
        $paths = [];
        try {
            foreach ($files as $file) {
                $paths[] = $this->imageOptimizer->store($file, $directory);
            }
        } catch (\Throwable $e) {
            if ($paths) Storage::disk('public')->delete($paths);
            throw $e;
        }
        return $paths;
    }

    private function normalizeModelConfiguration(array $configuration, array $fallback = []): array
    {
        // تنظیمات کیفیت ممکن است در محصولات قدیمی ناقص یا فقط بخشی از فرم
        // ارسال شده باشد. پیش‌فرض کامل، سپس تنظیم قبلی محصول و در پایان
        // انتخاب تازه‌ی مدیر روی هم می‌نشینند تا ذخیره‌ی یک تغییر کوچک،
        // کیفیت‌های دیگر را خالی نکند.
        $qualityFallback = $this->mergeQualityModelConfiguration([], $fallback);
        $levels = ['standard', 'premium', 'fallback'];
        $normalized = [
            'max_retries' => min(2, max(0, (int) data_get($configuration, 'max_retries', data_get($fallback, 'max_retries', 2)))),
        ];

        foreach ($levels as $level) {
            $value = (array) data_get($configuration, $level, data_get($fallback, $level, []));
            $modelId = trim((string) ($value['model_id'] ?? ''));
            $provider = trim((string) ($value['provider'] ?? ''));
            if ($modelId === '') {
                $normalized[$level] = ['model_id' => null, 'provider' => $provider ?: null];
                continue;
            }
            $normalized[$level] = ['model_id' => $modelId, 'provider' => $provider ?: null];
        }

        foreach (['free', 'economy', 'pro', 'business'] as $tierKey) {
            $tier = (array) data_get($configuration, "tiers.{$tierKey}", data_get($fallback, "tiers.{$tierKey}", []));
            $primary = (array) ($tier['primary'] ?? []);
            $fallbackModel = (array) ($tier['fallback'] ?? []);
            $normalized['tiers'][$tierKey] = [
                'primary' => [
                    'model_id' => filled($primary['model_id'] ?? null) ? trim((string) $primary['model_id']) : null,
                    'provider' => filled($primary['provider'] ?? null) ? trim((string) $primary['provider']) : null,
                ],
                'fallback' => [
                    'model_id' => filled($fallbackModel['model_id'] ?? null) ? trim((string) $fallbackModel['model_id']) : null,
                    'provider' => filled($fallbackModel['provider'] ?? null) ? trim((string) $fallbackModel['provider']) : null,
                ],
            ];
        }

        $presetKey = (string) data_get($configuration, 'quality_preset_key', data_get($fallback, 'quality_preset_key', ModelQualityPreset::defaultKey()));
        // کلید پیش‌فرض عمداً حفظ می‌شود تا ویرایش‌های گام دوم و پنجره‌ی فهرست
        // روی همان پیش‌فرض ذخیره شوند. فقط انتخاب صریح «سفارشی» این پیوند را قطع می‌کند.
        $normalized['quality_preset_key'] = $presetKey === 'custom' || in_array($presetKey, ModelQualityPreset::availableKeys(), true)
            ? $presetKey
            : ModelQualityPreset::defaultKey();
        $normalized['quality_architecture_enabled'] = filter_var(
            data_get($configuration, 'quality_architecture_enabled', data_get($fallback, 'quality_architecture_enabled', true)),
            FILTER_VALIDATE_BOOLEAN
        );

        $defaultCreditCosts = ProductCreditPreset::query()
            ->where('is_default_for_product_creation', true)
            ->first()?->costs() ?: Product::DEFAULT_QUALITY_CREDIT_COSTS;
        $creditFallback = (array) data_get($fallback, 'quality_credit_costs', $defaultCreditCosts);
        $creditCosts = (array) data_get($configuration, 'quality_credit_costs', $creditFallback);
        $normalized['quality_credit_costs'] = collect(Product::DEFAULT_QUALITY_CREDIT_COSTS)
            ->mapWithKeys(function (int $default, string $key) use ($creditCosts): array {
                $value = $creditCosts[$key] ?? $default;
                return [$key => (is_numeric($value) && (int) $value > 0) ? min(1000000, (int) $value) : $default];
            })
            ->all();
        $creditPresetKey = (string) data_get(
            $configuration,
            'quality_credit_preset_key',
            data_get($fallback, 'quality_credit_preset_key', ProductCreditPreset::defaultKey())
        );
        $normalized['quality_credit_preset_key'] = $creditPresetKey === 'custom'
            || in_array($creditPresetKey, ProductCreditPreset::availableKeys(), true)
            ? $creditPresetKey
            : ProductCreditPreset::defaultKey();

        $resolutionDefaults = (array) data_get(
            $configuration,
            'output_resolution_defaults',
            data_get($fallback, 'output_resolution_defaults', Product::DEFAULT_PLAN_OUTPUT_RESOLUTIONS)
        );
        $normalized['output_resolution_defaults'] = [
            'free' => in_array((string) ($resolutionDefaults['free'] ?? ''), Product::supportedOutputResolutions(), true)
                ? (string) $resolutionDefaults['free']
                : Product::DEFAULT_PLAN_OUTPUT_RESOLUTIONS['free'],
            'paid' => in_array((string) ($resolutionDefaults['paid'] ?? ''), Product::supportedOutputResolutions(), true)
                ? (string) $resolutionDefaults['paid']
                : Product::DEFAULT_PLAN_OUTPUT_RESOLUTIONS['paid'],
        ];

        foreach ([
            'quality_models' => ['standard', 'professional', 'best'],
            'free_quality_models' => ['standard', 'best'],
        ] as $group => $qualities) {
            foreach ($qualities as $quality) {
                // فرم‌های ویرایش سریع ممکن است فقط یک نقش را بفرستند؛
                // نقش و کیفیت‌های دیگر باید از تنظیم قبلی/پیش‌فرض حفظ شوند.
                $selection = array_replace_recursive(
                    (array) data_get($qualityFallback, "{$group}.{$quality}", []),
                    (array) data_get($configuration, "{$group}.{$quality}", [])
                );
                foreach (['primary', 'fallback'] as $role) {
                    $pair = (array) ($selection[$role] ?? []);
                    $normalized[$group][$quality][$role] = [
                        'model_id' => filled($pair['model_id'] ?? null) ? trim((string) $pair['model_id']) : null,
                        'provider' => filled($pair['provider'] ?? null) ? trim((string) $pair['provider']) : null,
                    ];
                }
            }
        }

        return $normalized;
    }

    private function modelTierRules(): array
    {
        return [
            'model_configuration.tiers' => ['nullable', 'array'],
            'model_configuration.tiers.free' => ['nullable', 'array'],
            'model_configuration.tiers.economy' => ['nullable', 'array'],
            'model_configuration.tiers.pro' => ['nullable', 'array'],
            'model_configuration.tiers.business' => ['nullable', 'array'],
            'model_configuration.tiers.*.primary.model_id' => ['nullable', 'string', 'max:255'],
            'model_configuration.tiers.*.primary.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'model_configuration.tiers.*.fallback.model_id' => ['nullable', 'string', 'max:255'],
            'model_configuration.tiers.*.fallback.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'model_configuration.quality_preset_key' => ['nullable', Rule::in(array_merge(ModelQualityPreset::availableKeys(), ['custom']))],
            'model_configuration.quality_architecture_enabled' => ['nullable', 'boolean'],
            'model_configuration.quality_credit_preset_key' => ['nullable', Rule::in(array_merge(ProductCreditPreset::availableKeys(), ['custom']))],
            'model_configuration.quality_credit_costs' => ['nullable', 'array'],
            'model_configuration.quality_credit_costs.standard' => ['nullable', 'integer', 'min:1', 'max:1000000'],
            'model_configuration.quality_credit_costs.professional' => ['nullable', 'integer', 'min:1', 'max:1000000'],
            'model_configuration.quality_credit_costs.best' => ['nullable', 'integer', 'min:1', 'max:1000000'],
            'model_configuration.output_resolution_defaults' => ['nullable', 'array'],
            'model_configuration.output_resolution_defaults.free' => ['nullable', Rule::in(Product::supportedOutputResolutions())],
            'model_configuration.output_resolution_defaults.paid' => ['nullable', Rule::in(Product::supportedOutputResolutions())],
            'model_configuration.quality_models' => ['nullable', 'array'],
            'model_configuration.free_quality_models' => ['nullable', 'array'],
            'model_configuration.quality_models.*.primary.model_id' => ['nullable', 'string', 'max:255'],
            'model_configuration.quality_models.*.primary.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'model_configuration.quality_models.*.fallback.model_id' => ['nullable', 'string', 'max:255'],
            'model_configuration.quality_models.*.fallback.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'model_configuration.free_quality_models.*.primary.model_id' => ['nullable', 'string', 'max:255'],
            'model_configuration.free_quality_models.*.primary.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
            'model_configuration.free_quality_models.*.fallback.model_id' => ['nullable', 'string', 'max:255'],
            'model_configuration.free_quality_models.*.fallback.provider' => ['nullable', Rule::in(ProviderStatus::PROVIDERS)],
        ];
    }

    private function validateModelTierConfiguration(Request $request, bool $isPublishing, array $fallback = []): void
    {
        $rawQualityConfiguration = (array) $request->input('model_configuration', []);
        $completeQualityConfiguration = $this->mergeQualityModelConfiguration($rawQualityConfiguration, $fallback);
        $qualityModels = $request->input('model_configuration.quality_models');
        // وقتی معماری سه‌سطحی در درخواست وجود دارد، همین ساختار منبع نهایی
        // حقیقت است؛ خاموش‌بودن فلگ قدیمی نباید اعتبارسنجی را به primary_model برگرداند.
        if (is_array($qualityModels) && !empty($qualityModels)) {
            $this->validateQualityModelEntries(
                (array) data_get($completeQualityConfiguration, 'quality_models', []),
                (array) data_get($completeQualityConfiguration, 'free_quality_models', []),
                $isPublishing
            );
            return;
        }

        $tiers = $request->input('model_configuration.tiers');
        if (!is_array($tiers) || empty($tiers)) {
            if ($isPublishing && (!$request->filled('primary_model') || !$request->filled('ai_provider'))) {
                throw ValidationException::withMessages(['model_configuration' => 'برای انتشار، چهار سطح مدل یا یک مدل اصلی معتبر انتخاب کنید.']);
            }
            return;
        }

        $this->validateModelTierEntries($tiers, $isPublishing);
    }

    /** اعتبارسنجی پنج انتخاب کیفیت جدید: سه کیفیت عمومی و دو مسیر کاربر رایگان. */
    private function validateQualityModelEntries(array $qualityModels, array $freeQualityModels, bool $requireComplete): void
    {
        $errors = [];
        $qualityLabels = [
            'quality_models.standard' => 'استاندارد',
            'quality_models.professional' => 'حرفه‌ای',
            'quality_models.best' => 'بهترین خروجی',
            'free_quality_models.standard' => 'استاندارد کاربران رایگان',
            'free_quality_models.best' => 'بهترین خروجی کاربران رایگان',
        ];
        foreach ([
            'quality_models' => ['standard', 'professional', 'best'],
            'free_quality_models' => ['standard', 'best'],
        ] as $group => $qualities) {
            $source = $group === 'quality_models' ? $qualityModels : $freeQualityModels;
            foreach ($qualities as $quality) {
                $primary = (array) data_get($source, "{$quality}.primary", []);
                $fallback = (array) data_get($source, "{$quality}.fallback", []);
                $prefix = "model_configuration.{$group}.{$quality}";
                if (empty($primary['model_id']) || empty($primary['provider']) || empty($fallback['model_id']) || empty($fallback['provider'])) {
                    if ($requireComplete) {
                        $label = $qualityLabels["{$group}.{$quality}"] ?? $quality;
                        $errors[$prefix] = "مدل اصلی و جایگزین کیفیت «{$label}» را کامل انتخاب کنید.";
                    }
                    continue;
                }
                foreach (['primary' => $primary, 'fallback' => $fallback] as $role => $selection) {
                    $valid = $this->assignableAiModels()
                        ->where('provider', $selection['provider'])
                        ->where('openrouter_model_id', $selection['model_id'])
                        ->exists();
                    if (! $valid) $errors["{$prefix}.{$role}.model_id"] = 'مدل انتخاب‌شده در کاتالوگ فعال و قابل انتخاب نیست.';
                }
                if (($primary['provider'] ?? null) === ($fallback['provider'] ?? null)
                    && ($primary['model_id'] ?? null) === ($fallback['model_id'] ?? null)) {
                    $errors["{$prefix}.fallback.model_id"] = 'مدل جایگزین نمی‌تواند همان مدل اصلی باشد.';
                }
            }
        }
        if ($errors) throw ValidationException::withMessages($errors);
    }

    /** اعتبارسنجی و نرمال‌سازی مشترک گام دوم و پنجره‌ی ویرایش سریع مدل‌ها. */
    private function normalizeAndValidateQualityModelConfiguration(array $configuration, array $fallback = []): array
    {
        $enabled = filter_var(
            data_get($configuration, 'quality_architecture_enabled', data_get($fallback, 'quality_architecture_enabled', true)),
            FILTER_VALIDATE_BOOLEAN
        );

        if ($enabled) {
            $completeConfiguration = $this->mergeQualityModelConfiguration($configuration, $fallback);
            $this->validateQualityModelEntries(
                (array) data_get($completeConfiguration, 'quality_models', []),
                (array) data_get($completeConfiguration, 'free_quality_models', []),
                true
            );
        }

        return $this->normalizeModelConfiguration($configuration, $fallback);
    }

    /**
     * ساختار کیفیت کامل را برای ورودی‌های ناقص فرم آماده می‌کند.
     * ترتیب اولویت: پیش‌فرض سراسری → تنظیم ذخیره‌شده‌ی محصول → ورودی جدید.
     */
    private function mergeQualityModelConfiguration(array $configuration, array $fallback = []): array
    {
        $selectedKey = (string) ($configuration['quality_preset_key'] ?? '');
        $default = $selectedKey !== '' && $selectedKey !== 'custom'
            ? ModelQualityPreset::query()->where('preset_key', $selectedKey)->value('configuration')
            : null;

        if (! $default) {
            $default = ModelQualityPreset::query()
                ->where('is_default_for_product_creation', true)
                ->value('configuration');
        }

        if (!$default) {
            $default = ModelQualityPreset::query()->orderBy('id')->value('configuration');
        }

        $default = is_string($default) ? (json_decode($default, true) ?: []) : (array) $default;
        $groups = ['quality_models', 'free_quality_models'];
        $merged = [];
        foreach ($groups as $group) {
            $merged[$group] = array_replace_recursive(
                (array) data_get($default, $group, []),
                (array) data_get($fallback, $group, []),
                (array) data_get($configuration, $group, [])
            );
        }

        return $merged;
    }

    private function validateModelTierEntries(array $tiers, bool $requireComplete): void
    {
        $errors = [];
        foreach (['free', 'economy', 'pro', 'business'] as $tierKey) {
            $primary = (array) data_get($tiers, "{$tierKey}.primary", []);
            $fallback = (array) data_get($tiers, "{$tierKey}.fallback", []);
            $prefix = "model_configuration.tiers.{$tierKey}";
            if (empty($primary['model_id']) || empty($primary['provider']) || empty($fallback['model_id']) || empty($fallback['provider'])) {
                if ($requireComplete) $errors[$prefix] = 'مدل اصلی و جایگزین این سطح را کامل انتخاب کنید.';
                continue;
            }
            foreach (['primary' => $primary, 'fallback' => $fallback] as $type => $selection) {
                $valid = $this->assignableAiModels()
                    ->where('provider', $selection['provider'])
                    ->where('openrouter_model_id', $selection['model_id'])
                    ->exists();
                if (!$valid) $errors["{$prefix}.{$type}.model_id"] = 'مدل انتخاب‌شده در کاتالوگ فعال و قابل انتخاب نیست.';
            }
            if (($primary['provider'] ?? null) === ($fallback['provider'] ?? null)
                && ($primary['model_id'] ?? null) === ($fallback['model_id'] ?? null)) {
                $errors["{$prefix}.fallback.model_id"] = 'مدل جایگزین نمی‌تواند همان مدل اصلی باشد.';
            }
        }
        if ($errors) throw ValidationException::withMessages($errors);
    }

    private function applyBusinessTierAsLegacyExecution(Product $product, array $configuration, ?array &$validated = null): void
    {
        // برای سازگاری با مسیرهای قدیمی، بهترین خروجی به‌عنوان مدل اصلی محصول
        // ذخیره می‌شود؛ اجرای واقعی پایین‌تر بر اساس کیفیت انتخابی کاربر تصمیم می‌گیرد.
        $business = (array) data_get($configuration, 'quality_models.best', data_get($configuration, 'tiers.business', []));
        $primary = (array) ($business['primary'] ?? []);
        $fallback = (array) ($business['fallback'] ?? []);
        if (empty($primary['model_id']) || empty($primary['provider'])) return;

        $values = [
            'primary_model' => $primary['model_id'],
            'ai_provider' => $primary['provider'],
            'fallback_models' => !empty($fallback['model_id']) ? [$fallback['model_id']] : [],
            'fallback_model_providers' => !empty($fallback['provider']) ? [$fallback['provider']] : [],
        ];
        if ($validated !== null) {
            $validated = array_replace($validated, $values);
            return;
        }
        $product->forceFill($values);
    }

    /**
     * منبع قطعی قیمت محصول، مصرف اعتبار سه‌سطحی است. دو ستون قدیمی فقط برای
     * سازگاری نمایش‌ها و مسیرهای اجرای فعلی، از هزینه سطح استاندارد پر می‌شوند
     * و مقدار مستقیم ارسالی کاربر را نمی‌پذیرند.
     */
    private function applyQualityCreditPricingAsLegacyFields(Product $product, array $configuration, ?array &$validated = null): void
    {
        $standardCreditCost = max(1, min(
            1000000,
            (int) data_get($configuration, 'quality_credit_costs.standard', Product::DEFAULT_QUALITY_CREDIT_COSTS['standard'])
        ));
        $values = [
            'pricing_model' => 'per_credit',
            'credit_cost' => $standardCreditCost,
        ];

        if ($validated !== null) {
            $validated = array_replace($validated, $values);
            return;
        }

        $product->forceFill($values);
    }

    private function validatedTierPreset(Request $request): string
    {
        $request->validate(['preset_key' => ['required', Rule::in(['global'])]]);
        return 'global';
    }

    private function applyTierPresetToProduct(Product $product, string $presetKey): void
    {
        $defaults = ModelTierDefault::query()->get()->keyBy('tier_key');
        $configuration = (array) ($product->model_configuration ?? []);
        foreach (['free', 'economy', 'pro', 'business'] as $tierKey) {
            $default = $defaults->get($tierKey);
            if (!$default || !$default->primary_model_id || !$default->fallback_model_id) {
                throw ValidationException::withMessages(['preset_key' => 'پیش‌تنظیم انتخاب‌شده هنوز مدل اصلی و جایگزین کامل ندارد.']);
            }
            $configuration['tiers'][$tierKey] = [
                'primary' => ['model_id' => $default->primary_model_id, 'provider' => $default->primary_provider],
                'fallback' => ['model_id' => $default->fallback_model_id, 'provider' => $default->fallback_provider],
            ];
        }
        $configuration['applied_preset'] = $presetKey;
        $product->model_configuration = $this->normalizeModelConfiguration($configuration, (array) $product->model_configuration);
        $this->applyBusinessTierAsLegacyExecution($product, $product->model_configuration);
        $this->applyQualityCreditPricingAsLegacyFields($product, $product->model_configuration);
        $product->save();
    }

    private function normalizedAspectRatios(mixed $ratios, array $fallback = ['3:4']): array
    {
        $allowed = Product::supportedAspectRatios();
        $selected = array_values(array_unique(array_intersect($allowed, array_map('strval', (array) $ratios))));
        return $selected ?: $this->normalizedAspectRatios($fallback, ['3:4']);
    }

    private function normalizedResolutions(mixed $resolutions): array
    {
        $allowed = Product::supportedOutputResolutions();
        $selected = array_map('strval', (array) $resolutions);

        return array_values(array_intersect(
            $allowed,
            array_unique(array_merge(Product::DEFAULT_OUTPUT_RESOLUTIONS, $selected))
        ));
    }

    private function aspectRatiosFromSchema(array $schema, array $fallback): array
    {
        foreach ($schema as $field) {
            if (!is_array($field) || ($field['type'] ?? null) !== 'aspect_ratio') continue;
            $ratios = array_map(
                fn ($option) => is_array($option) ? ($option['value'] ?? null) : null,
                (array) ($field['options'] ?? [])
            );
            return $this->normalizedAspectRatios(array_filter($ratios), $fallback);
        }

        return $this->normalizedAspectRatios($fallback, $fallback);
    }
}
