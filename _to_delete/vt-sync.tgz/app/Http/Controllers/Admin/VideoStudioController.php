<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GeneratedVideo;
use App\Models\AiModel;
use App\Models\Product;
use App\Models\ProductTestRun;
use App\Models\VideoHookInspiration;
use App\Models\VideoStudioJob;
use App\Models\VideoStudioSetting;
use App\Models\VideoStudioSource;
use App\Models\VideoStudioFont;
use App\Models\VideoStudioHookColor;
use App\Models\VideoStudioHookColorPreference;
use App\Models\VideoStudioPreset;
use App\Models\VideoStudioSocialPrompt;
use App\Support\Jalali;
use App\Services\StudioCostService;
use App\Services\OpenRouterService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class VideoStudioController extends Controller
{
    public function index(Request $request, string $view = 'admin.video-studio.experimental')
    {
        $hasGeneratedVideos = Schema::hasTable('generated_videos');
        $hasProductRuns = Schema::hasTable('product_test_runs');

        $videoQuery = static fn () => GeneratedVideo::query();
        $videoCount = $hasGeneratedVideos ? $videoQuery()->count() : 0;
        $completedCount = $hasGeneratedVideos ? $videoQuery()->where('status', 'completed')->count() : 0;
        $failedCount = $hasGeneratedVideos ? $videoQuery()->whereIn('status', ['failed', 'error'])->count() : 0;
        $processingCount = $hasGeneratedVideos ? $videoQuery()->whereIn('status', ['queued', 'processing'])->count() : 0;

        $activeProducts = Product::query()->where('status', 'active')->count();
        $coveredProducts = $hasGeneratedVideos
            ? GeneratedVideo::query()->whereNotNull('product_id')->distinct('product_id')->count('product_id')
            : 0;

        $latestVideos = $hasGeneratedVideos
            ? GeneratedVideo::query()->with('product')->latest()->limit(10)->get()
            : collect();
        $latestTests = $hasProductRuns
            ? ProductTestRun::query()->with('product')->latest()->limit(8)->get()
            : collect();

        $productSearch = trim((string) $request->query('product_search', ''));
        $productSort = (string) $request->query('product_sort', 'newest');
        $productSort = in_array($productSort, ['newest', 'oldest', 'name_asc', 'name_desc'], true)
            ? $productSort
            : 'newest';
        $productsQuery = Product::query()->where('status', 'active');
        if ($productSearch !== '') {
            $productsQuery->where(function ($query) use ($productSearch): void {
                $query->where('name_fa', 'like', '%' . $productSearch . '%')
                    ->orWhere('name_en', 'like', '%' . $productSearch . '%')
                    ->orWhere('slug', 'like', '%' . $productSearch . '%');
            });
        }
        $productsQuery->when($productSort === 'oldest', fn ($query) => $query->orderBy('created_at'), function ($query) use ($productSort): void {
            if ($productSort === 'name_asc') {
                $query->orderBy('name_fa');
            } elseif ($productSort === 'name_desc') {
                $query->orderByDesc('name_fa');
            } else {
                $query->orderByDesc('created_at');
            }
        });
        $products = $productsQuery
            ->get(['id', 'name_fa', 'slug', 'created_at']);
        // بعد از ثبت سفارش، سازنده باید برای سفارش بعدی خالی شود تا تنظیمات سفارش قبلی
        // ناخواسته دوباره ارسال نشود. انتخاب محصول فقط وقتی از URL خوانده می‌شود که
        // صفحه در حالت تازه‌سازی سازنده نباشد.
        $selectedProductId = $request->boolean('fresh')
            ? null
            : ($request->integer('product_id') ?: null);
        $selectedProduct = $selectedProductId ? Product::find($selectedProductId) : null;
        $productImages = collect($selectedProduct ? array_merge(
            [$selectedProduct->cover, $selectedProduct->thumbnail],
            (array) $selectedProduct->sample_outputs,
            (array) $selectedProduct->before_images,
        ) : [])->filter()->unique()->map(function ($path): ?array {
            $path = (string) $path;
            $url = Str::startsWith($path, ['http://', 'https://', 'data:'])
                ? $path
                : (Storage::disk('public')->exists($path) ? asset('storage/' . ltrim($path, '/')) : null);
            return $url ? ['path' => $path, 'url' => $url] : null;
        })->filter()->values();
        $settings = VideoStudioSetting::query()
            ->where(function ($query) use ($selectedProductId): void {
                $query->where('product_id', $selectedProductId)
                    ->orWhereNull('product_id');
            })
            ->orderByRaw('product_id IS NULL')
            ->first();
        $settings ??= new VideoStudioSetting([
            'source_mode' => 'auto',
            'auto_enabled' => false,
            'approval_required' => true,
            'auto_generate_hook' => true,
            'auto_generate_caption' => true,
            'auto_generate_keyword' => true,
            'font_family' => 'B_Yekan',
            'aspect_ratio' => '9:16',
        ]);
        if ($request->boolean('fresh')) {
            // صفحهٔ سازنده پس از ثبت سفارش باید برای سفارش بعدی کاملاً خنثی باشد؛
            // مقادیر پرامپت مادر باقی می‌مانند اما محصول و منبع قبلی نه.
            $settings->product_id = null;
            $settings->source_mode = 'auto';
            $settings->source_url = null;
            $settings->hook_text = null;
            $settings->caption_text = null;
            $settings->telegram_caption_text = null;
            $settings->keyword = null;
            $settings->dm_template = null;
            $settings->aspect_ratio = '9:16';
        }
        $hookInspirations = Schema::hasTable('video_hook_inspirations')
            ? VideoHookInspiration::query()->with('product')->where('is_active', true)->latest()->limit(12)->get()
            : collect();
        $sources = Schema::hasTable('video_studio_sources')
            ? VideoStudioSource::query()->where('is_active', true)->latest()->get()
            : collect();
        $presets = Schema::hasTable('video_studio_presets')
            ? VideoStudioPreset::query()->where(function ($query): void {
                $query->whereNull('admin_id')->orWhere('admin_id', auth('admin')->id());
            })->orderBy('name')->get(['id', 'name', 'settings'])
            : collect();
        $socialPrompts = Schema::hasTable('video_studio_social_prompts')
            ? VideoStudioSocialPrompt::query()->where('admin_id', auth('admin')->id())->pluck('prompt', 'platform')->all()
            : [];
        foreach (['instagram', 'telegram', 'youtube', 'aparat', 'linkedin', 'hook'] as $platform) {
            $socialPrompts[$platform] = trim((string) ($socialPrompts[$platform] ?? ''));
        }
        $hookColors = [
            'background' => $this->hookColorOptions('background'),
            'text' => $this->hookColorOptions('text'),
        ];
        $fallbackFonts = collect([
            new VideoStudioFont(['name' => 'یکان', 'slug' => 'B_Yekan', 'file_path' => 'fonts/B_Yekan.ttf', 'is_default' => true]),
            new VideoStudioFont(['name' => 'ابر', 'slug' => 'Abar', 'file_path' => 'fonts/video/AbarMid-Regular.ttf', 'is_default' => false]),
            new VideoStudioFont(['name' => 'ایران‌سنس', 'slug' => 'IRANSansX', 'file_path' => 'fonts/IRANSansXFaNum-RegularD4.ttf', 'is_default' => false]),
            new VideoStudioFont(['name' => 'پیدا', 'slug' => 'Peyda', 'file_path' => 'fonts/video/Peyda-Medium.ttf', 'is_default' => false]),
            new VideoStudioFont(['name' => 'دوران', 'slug' => 'Doran', 'file_path' => 'fonts/video/Doran-Regular.ttf', 'is_default' => false]),
            new VideoStudioFont(['name' => 'مدام', 'slug' => 'Modam', 'file_path' => 'fonts/video/Modam-Medium.ttf', 'is_default' => false]),
            new VideoStudioFont(['name' => 'یکان‌بخ', 'slug' => 'YekanBakh', 'file_path' => 'fonts/video/YekanBakh-Medium.ttf', 'is_default' => false]),
        ]);
        $storedFonts = Schema::hasTable('video_studio_fonts')
            ? VideoStudioFont::query()->where('is_active', true)->orderByDesc('is_default')->orderBy('name')->get()
            : collect();
        // حتی اگر دیتابیس تولید فونت‌ها را ناقص داشته باشد، گزینه‌های ارسالی مدیر حذف نمی‌شوند.
        $fonts = $fallbackFonts->concat($storedFonts)->unique('slug')->values();
        $fontWeightAssets = $this->videoStudioFontWeightAssets($fonts);
        if (Schema::hasTable('video_studio_jobs')) {
            // اجرای عادی پایپ‌لاین کوتاه است؛ اگر callback برنگردد، سفارش نباید
            // برای همیشه روی «در حال ساخت» بماند و باید دلیل قابل‌فهمی برای ساخت مجدد داشته باشد.
            VideoStudioJob::query()
                ->where('status', 'processing')
                ->where('updated_at', '<', now()->subMinutes(15))
                ->whereNull('video_url')
                ->get()
                ->each(function (VideoStudioJob $staleJob): void {
                    $staleJob->update([
                        'status' => 'failed',
                        'error_message' => $staleJob->error_message ?: 'پردازش در زمان مقرر پاسخ نداد؛ منبع و تنظیمات را بررسی کنید و ساخت مجدد را بزنید.',
                    ]);
                });
        }
        $jobs = Schema::hasTable('video_studio_jobs')
            ? VideoStudioJob::query()->with('product')->latest()->limit(10)->get()
            : collect();
        $estimatedCosts = $jobs->mapWithKeys(function (VideoStudioJob $job): array {
            $payload = is_array($job->payload) ? $job->payload : [];
            $sourceMode = (string) ($job->source_mode ?: data_get($payload, 'source_mode', 'auto'));
            $calculated = $this->estimateVideoCost((int) $job->product_id, (string) $job->aspect_ratio, $sourceMode);
            $saved = data_get($payload, 'estimated_cost', []);

            // هزینه‌ی ذخیره‌شده‌ی سفارش‌های قدیمی ممکن است قبل از اصلاح مسیر
            // تدوین، قیمت مدل تولید ویدیو را نشان دهد. برای منبع موجود، برآورد
            // قطعی و بدون فراخوانی مدل همیشه مرجع نهایی است.
            if (in_array($sourceMode, ['auto', 'music', 'video', 'upload'], true)) {
                return [$job->id => $calculated];
            }

            return [$job->id => is_array($saved) && $saved !== [] ? $saved : $calculated];
        });
        $completedVideoCounts = Schema::hasTable('video_studio_jobs')
            ? VideoStudioJob::query()->where('status', 'completed')->selectRaw('product_id, COUNT(*) AS total')->groupBy('product_id')->pluck('total', 'product_id')->mapWithKeys(fn ($count, $id): array => [(int) $id => (int) $count])->all()
            : [];
        $pendingVideoCounts = Schema::hasTable('video_studio_jobs')
            ? VideoStudioJob::query()->whereIn('status', ['queued', 'processing'])->selectRaw('product_id, COUNT(*) AS total')->groupBy('product_id')->pluck('total', 'product_id')->mapWithKeys(fn ($count, $id): array => [(int) $id => (int) $count])->all()
            : [];
        $producedProducts = $jobs
            ->filter(fn (VideoStudioJob $job): bool => in_array((string) $job->status, ['queued', 'processing', 'completed'], true))
            ->unique('product_id')
            ->values();
        $coveredProducts = max($coveredProducts, $producedProducts->count());

        $daily = collect(range(13, 0))->map(function (int $daysAgo) use ($hasGeneratedVideos): array {
            $date = now()->subDays($daysAgo)->startOfDay();
            $count = $hasGeneratedVideos
                ? GeneratedVideo::query()->whereDate('created_at', $date)->count()
                : 0;

            [$jy, $jm, $jd] = Jalali::toJalaliYmd((int) $date->format('Y'), (int) $date->format('n'), (int) $date->format('j'));

            return [
                'label' => Jalali::toPersianDigits(sprintf('%02d/%02d', $jm, $jd)),
                'count' => $count,
            ];
        });

        return response()->view($view, [
            'videoCount' => $videoCount,
            'completedCount' => $completedCount,
            'failedCount' => $failedCount,
            'processingCount' => $processingCount,
            'activeProducts' => $activeProducts,
            'coveredProducts' => $coveredProducts,
            'latestVideos' => $latestVideos,
            'latestTests' => $latestTests,
            'products' => $products,
            'productSearch' => $productSearch,
            'productSort' => $productSort,
            'selectedProductId' => $selectedProductId,
            'selectedProduct' => $selectedProduct,
            'productImages' => $productImages,
            'settings' => $settings,
            'hookInspirations' => $hookInspirations,
            'sources' => $sources,
            'presets' => $presets,
            'socialPrompts' => $socialPrompts,
            'hookColors' => $hookColors,
            'fonts' => $fonts,
            'fontWeightAssets' => $fontWeightAssets,
            'jobs' => $jobs,
            'estimatedCosts' => $estimatedCosts,
            'completedVideoCounts' => $completedVideoCounts,
            'pendingVideoCounts' => $pendingVideoCounts,
            'producedProducts' => $producedProducts,
            'daily' => $daily,
            'dataSources' => [
                'products' => true,
                'generated_videos' => $hasGeneratedVideos,
                'product_test_runs' => $hasProductRuns,
            ],
            'experimentalPage' => $view === 'admin.video-studio.experimental',
        ])->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            ->header('Pragma', 'no-cache');
    }

    /**
     * نسخهٔ تکثیرشدهٔ استودیو برای اجرای فازهای جدید، بدون تغییر رفتار صفحهٔ فعلی.
     */
    public function experimental(Request $request)
    {
        return $this->index($request, 'admin.video-studio.experimental');
    }

    /**
     * تصویر سبک صف ساخت برای تازه‌سازی خودکار نسخهٔ فعلی.
     * منبع همان جدول `video_studio_jobs` است تا نسخهٔ قدیمی و جدید از دو صف جدا نشوند.
     */
    public function jobsSnapshot(Request $request)
    {
        abort_unless(Schema::hasTable('video_studio_jobs'), 404);

        $search = trim((string) $request->query('search', ''));
        $query = VideoStudioJob::query()->with('product:id,name_fa')->latest('id');
        if ($search !== '') {
            $query->where(function ($builder) use ($search): void {
                $builder->where('id', 'like', '%' . $search . '%')
                    ->orWhere('status', 'like', '%' . $search . '%')
                    ->orWhere('error_message', 'like', '%' . $search . '%')
                    ->orWhereHas('product', function ($productQuery) use ($search): void {
                        $productQuery->where('name_fa', 'like', '%' . $search . '%')
                            ->orWhere('name_en', 'like', '%' . $search . '%')
                            ->orWhere('slug', 'like', '%' . $search . '%');
                    });
            });
        }
        $jobs = VideoStudioJob::query()
            ->with('product:id,name_fa')
            ->latest('id');
        if ($search !== '') {
            $jobs = $query;
        }
        $jobs = $jobs->paginate(10, ['id', 'product_id', 'status', 'error_message', 'video_url', 'payload', 'created_at'], 'page');

        $allJobs = VideoStudioJob::query();
        $stats = [
            'total' => (clone $allJobs)->count(),
            'completed' => (clone $allJobs)->where('status', 'completed')->count(),
            'active' => (clone $allJobs)->whereIn('status', ['queued', 'pending', 'processing'])->count(),
            'failed' => (clone $allJobs)->whereIn('status', ['failed', 'error'])->count(),
        ];

        return response()->json([
            'data' => $jobs->getCollection()->map(function (VideoStudioJob $job): array {
                $cost = data_get($job->payload, 'estimated_cost', []);
                return [
                    'id' => $job->id,
                    'code' => method_exists($job, 'shortCode') ? $job->shortCode() : 'P' . $job->id,
                    'product' => $job->product?->name_fa ?? 'محصول',
                    'version' => (int) data_get($job->payload, 'version', 1),
                    'status' => (string) $job->status,
                    'error_message' => (string) ($job->error_message ?? ''),
                    'video_url' => (string) ($job->video_url ?? ''),
                    'cost_toman' => is_numeric($cost['toman'] ?? null) ? (float) $cost['toman'] : null,
                    'settings' => array_merge((array) ($job->payload ?? []), [
                        'product_id' => $job->product_id,
                        'selected_images' => $job->selected_images,
                        'aspect_ratio' => $job->aspect_ratio,
                        'parent_job_id' => $job->id,
                        'version' => ((int) data_get($job->payload, 'version', 1)) + 1,
                    ]),
                ];
            })->values(),
            'current_page' => $jobs->currentPage(),
            'last_page' => $jobs->lastPage(),
            'total' => $jobs->total(),
            'per_page' => 10,
            'search' => $search,
            'stats' => $stats,
        ]);
    }

    public function storePreset(Request $request)
    {
        abort_unless(Schema::hasTable('video_studio_presets'), 404);
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'settings' => ['required', 'array', 'max:80'],
        ]);
        $preset = VideoStudioPreset::query()->updateOrCreate(
            ['admin_id' => auth('admin')->id(), 'name' => trim($data['name'])],
            ['settings' => $data['settings']],
        );

        return response()->json(['id' => $preset->id, 'name' => $preset->name, 'settings' => $preset->settings]);
    }

    public function renamePreset(Request $request, VideoStudioPreset $preset)
    {
        abort_unless((int) $preset->admin_id === (int) auth('admin')->id(), 403);
        $data = $request->validate(['name' => ['required', 'string', 'max:120']]);
        $preset->update(['name' => trim($data['name'])]);

        return response()->json(['id' => $preset->id, 'name' => $preset->name, 'settings' => $preset->settings]);
    }

    public function destroyPreset(VideoStudioPreset $preset)
    {
        abort_unless((int) $preset->admin_id === (int) auth('admin')->id(), 403);
        $preset->delete();

        return response()->json(['deleted' => true]);
    }

    public function storeSocialPrompts(Request $request)
    {
        abort_unless(Schema::hasTable('video_studio_social_prompts'), 404);
        $data = $request->validate([
            'prompts' => ['required', 'array', 'max:8'],
            'prompts.instagram' => ['nullable', 'string', 'max:30000'],
            'prompts.telegram' => ['nullable', 'string', 'max:30000'],
            'prompts.youtube' => ['nullable', 'string', 'max:30000'],
            'prompts.aparat' => ['nullable', 'string', 'max:30000'],
            'prompts.linkedin' => ['nullable', 'string', 'max:30000'],
            'prompts.hook' => ['nullable', 'string', 'max:30000'],
        ]);
        $rawPrompts = (array) $request->input('prompts', []);
        foreach (['instagram', 'telegram', 'youtube', 'aparat', 'linkedin', 'hook'] as $platform) {
            if (!array_key_exists($platform, $rawPrompts)) {
                continue;
            }
            // مقدار خالی هم یک مقدار معتبر است و باید مقدار قبلی را پاک کند؛
            // updateOrCreate در بعضی نسخه‌های دیتابیس/مدل مقدار null را حفظ می‌کرد.
            $identity = ['admin_id' => auth('admin')->id(), 'platform' => $platform];
            $values = ['prompt' => trim((string) ($rawPrompts[$platform] ?? '')), 'updated_at' => now()];
            $updated = DB::table('video_studio_social_prompts')->where($identity)->update($values);
            if ($updated === 0 && !DB::table('video_studio_social_prompts')->where($identity)->exists()) {
                DB::table('video_studio_social_prompts')->insert($identity + $values + ['created_at' => now()]);
            }
        }

        return response()->json(['saved' => true, 'prompts' => VideoStudioSocialPrompt::query()->where('admin_id', auth('admin')->id())->pluck('prompt', 'platform')->all()]);
    }

    public function storeHookColor(Request $request)
    {
        abort_unless(Schema::hasTable('video_studio_hook_colors'), 404);

        $data = $request->validate([
            'target' => ['required', Rule::in(['background', 'text'])],
            'name' => ['nullable', 'string', 'max:80'],
            'color_value' => ['required', 'regex:/^#[0-9a-fA-F]{6}$/'],
        ]);
        $color = VideoStudioHookColor::query()->updateOrCreate(
            [
                'admin_id' => auth('admin')->id(),
                'target' => $data['target'],
                'color_value' => strtoupper($data['color_value']),
            ],
            ['name' => trim((string) ($data['name'] ?? '')) ?: 'رنگ سفارشی'],
        );

        return response()->json([
            'saved' => true,
            'color' => $this->hookColorPayload($color),
        ]);
    }

    public function destroyHookColor(VideoStudioHookColor $color)
    {
        abort_unless((int) $color->admin_id === (int) auth('admin')->id(), 403);
        $color->delete();

        return response()->json(['deleted' => true]);
    }

    public function destroyDefaultHookColor(Request $request, string $target, string $colorKey)
    {
        abort_unless(in_array($target, ['background', 'text'], true), 404);
        abort_unless(collect($this->defaultHookColors($target))->contains('key', $colorKey), 404);
        abort_unless(Schema::hasTable('video_studio_hook_color_preferences'), 404);

        VideoStudioHookColorPreference::query()->updateOrCreate(
            [
                'admin_id' => auth('admin')->id(),
                'target' => $target,
                'color_key' => $colorKey,
            ],
            ['is_hidden' => true],
        );

        return response()->json(['deleted' => true]);
    }

    public function updateSettings(Request $request)
    {
        $data = $request->validate([
            'product_id' => ['nullable', 'integer', 'exists:products,id'],
            'source_mode' => ['required', 'in:auto,upload,music,video'],
            'source_url' => ['nullable', 'url', 'max:2048'],
            'auto_enabled' => ['nullable', 'boolean'],
            'approval_required' => ['nullable', 'boolean'],
            'auto_generate_hook' => ['nullable', 'boolean'],
            'auto_generate_caption' => ['nullable', 'boolean'],
            'auto_generate_keyword' => ['nullable', 'boolean'],
            'hook_guidelines' => ['nullable', 'string', 'max:5000'],
            'caption_guidelines' => ['nullable', 'string', 'max:5000'],
            'hook_text' => ['nullable', 'string', 'max:1000'],
            'caption_text' => ['nullable', 'string', 'max:5000'],
            'telegram_caption_text' => ['nullable', 'string', 'max:5000'],
            'prompt_profile' => ['nullable', 'string', 'max:30000'],
            'instagram_prompt' => ['nullable', 'string', 'max:30000'],
            'telegram_prompt' => ['nullable', 'string', 'max:30000'],
            'telegram_buttons_enabled' => ['nullable', 'boolean'],
            'telegram_button_label' => ['nullable', 'array', 'max:8'],
            'telegram_button_label.*' => ['nullable', 'string', 'max:80'],
            'telegram_button_url' => ['nullable', 'array', 'max:8'],
            'telegram_button_url.*' => ['nullable', 'url', 'max:2048'],
            'telegram_button_style' => ['nullable', 'array', 'max:8'],
            'telegram_button_style.*' => ['nullable', Rule::in(['primary', 'success', 'danger'])],
            'telegram_button_width' => ['nullable', 'array', 'max:8'],
            'telegram_button_width.*' => ['nullable', Rule::in(['full', 'half'])],
            'prompt_file' => ['nullable', 'file', 'mimes:txt,md', 'max:512'],
            'keyword' => ['nullable', 'string', 'max:80'],
            'dm_template' => ['nullable', 'string', 'max:5000'],
            'font_family' => ['required', Schema::hasTable('video_studio_fonts')
                ? Rule::exists('video_studio_fonts', 'slug')->where('is_active', true)
                : Rule::in(['B_Yekan'])],
            'aspect_ratio' => ['required', 'in:9:16,1:1,4:5,16:9'],
        ]);

        $product = Product::query()->findOrFail((int) $data['product_id']);
        $productLink = route('app.product', ['product' => $product->route_slug]);

        $productId = $data['product_id'] ?? null;
        if ($request->hasFile('prompt_file')) {
            $profileText = trim((string) file_get_contents($request->file('prompt_file')->getRealPath()));
            if ($profileText !== '') {
                $data['prompt_profile'] = $profileText;
            }
        }
        $data['telegram_buttons'] = $this->normalizeTelegramButtons($request);
        unset($data['telegram_buttons_enabled'], $data['telegram_button_label'], $data['telegram_button_url'], $data['telegram_button_style'], $data['telegram_button_width']);
        unset($data['prompt_file']);
        $setting = VideoStudioSetting::query()
            ->where('product_id', $productId)
            ->first();
        $setting ??= new VideoStudioSetting(['product_id' => $productId]);
        $setting->fill($data);
        $setting->product_id = $productId;
        $setting->auto_enabled = $request->boolean('auto_enabled');
        // تأیید انسانی فعلاً از مسیر تولید حذف شده و خروجی مستقیماً آمادهٔ ارسال است.
        $setting->approval_required = false;
        $setting->auto_generate_hook = $request->boolean('auto_generate_hook');
        $setting->auto_generate_caption = $request->boolean('auto_generate_caption');
        $setting->auto_generate_keyword = $request->boolean('auto_generate_keyword');
        $setting->save();

        return redirect()
            ->route('admin.video-studio.experimental', $productId ? ['product_id' => $productId] : [])
            ->with('success', 'تنظیمات ساخت ویدیو ذخیره شد.');
    }

    public function previewContent(Request $request)
    {
        try {
            $data = $request->validate([
                'product_id' => ['required', 'integer', 'exists:products,id'],
                'content_type' => ['nullable', Rule::in(['hook', 'cta', 'caption', 'keyword'])],
                'hook_guidelines' => ['nullable', 'string', 'max:5000'],
                'hook_prompt' => ['nullable', 'string', 'max:30000'],
                'cta_prompt' => ['nullable', 'string', 'max:30000'],
                'caption_guidelines' => ['nullable', 'string', 'max:5000'],
                'instagram_prompt' => ['nullable', 'string', 'max:30000'],
                'telegram_prompt' => ['nullable', 'string', 'max:30000'],
                'youtube_prompt' => ['nullable', 'string', 'max:30000'],
                'aparat_prompt' => ['nullable', 'string', 'max:30000'],
                'linkedin_prompt' => ['nullable', 'string', 'max:30000'],
                'channel' => ['nullable', Rule::in(['instagram', 'telegram', 'youtube', 'aparat', 'linkedin'])],
            ]);
            $product = Product::query()->find((int) $data['product_id']);
            if (!$product) {
                return response()->json(['message' => 'محصول انتخاب‌شده پیدا نشد؛ دوباره محصول را انتخاب کنید.'], 422);
            }
            $webhook = trim((string) config('services.n8n.video_studio_preview_webhook', env('N8N_VIDEO_STUDIO_PREVIEW_WEBHOOK', '')));
            if ($webhook === '') {
                $webhook = trim((string) config('services.n8n.video_studio_webhook', env('N8N_VIDEO_STUDIO_WEBHOOK_URL', '')));
                $webhook = preg_replace('~/video-studio-create(?:$|\?)~', '/video-studio-preview', $webhook) ?: $webhook;
            }
            if ($webhook === '') {
                return response()->json(['message' => 'اتصال پیش‌نمایش ورکفلو تنظیم نشده است.'], 422);
            }
            $channel = (string) ($data['channel'] ?? 'instagram');
            $contentType = (string) ($data['content_type'] ?? 'caption');
            $prompt = match ($contentType) {
                'hook' => trim((string) ($data['hook_prompt'] ?? $data['hook_guidelines'] ?? '')),
                'cta' => trim((string) ($data['cta_prompt'] ?? '')),
                default => trim((string) ($data[$channel . '_prompt'] ?? '')),
            };
            // اگر رابط کاربری این بخش را عمداً خالی فرستاده، هرگز از پرامپت قدیمی
            // یا پرامپت شبکهٔ دیگری استفاده نکن؛ فقط وقتی کلید پرامپت غایب است
            // مقدار ذخیره‌شدهٔ همان شبکه را به‌عنوان مقدار پیش‌فرض بخوان.
            $promptWasExplicitlyProvided = match ($contentType) {
                'hook' => array_key_exists('hook_prompt', $data) || array_key_exists('hook_guidelines', $data),
                'cta' => array_key_exists('cta_prompt', $data),
                default => array_key_exists($channel . '_prompt', $data),
            };
            if ($prompt === '' && !$promptWasExplicitlyProvided && Schema::hasTable('video_studio_social_prompts')) {
                $savedPlatform = $contentType === 'hook' ? 'hook' : $channel;
                $prompt = trim((string) VideoStudioSocialPrompt::query()
                    ->where('admin_id', auth('admin')->id())
                    ->where('platform', $savedPlatform)
                    ->value('prompt'));
            }
            if ($prompt === '') {
                $label = match ($contentType) {
                    'hook' => 'هوک',
                    'cta' => 'دعوت به اقدام',
                    'keyword' => 'کلمهٔ کلیدی',
                    default => 'کپشن ' . match ($channel) {
                        'telegram' => 'تلگرام',
                        'youtube' => 'یوتیوب',
                        'aparat' => 'آپارات',
                        'linkedin' => 'لینکدین',
                        default => 'اینستاگرام',
                    },
                };
                return response()->json(['message' => "پرامپت {$label} تنظیم نشده است؛ ابتدا پرامپت همین بخش را ذخیره کنید."], 422);
            }
            $previewPayload = [
                'preview_only' => true,
                'content_type' => $contentType,
                'channel' => $channel,
                'product_id' => $product->id,
                'product_name' => (string) $product->name_fa,
                'product_link' => route('app.product', ['product' => $product->route_slug]),
                'hook_guidelines' => $contentType === 'hook'
                    ? $prompt
                    : (string) ($data['hook_guidelines'] ?? ''),
                'caption_guidelines' => in_array($contentType, ['cta', 'caption', 'keyword'], true)
                    ? $prompt
                    : (string) ($data['caption_guidelines'] ?? ''),
                'prompt_profile' => $prompt,
                'hook_prompt' => $contentType === 'hook' ? $prompt : '',
                'cta_prompt' => $contentType === 'cta' ? $prompt : '',
                'caption_prompt' => in_array($contentType, ['caption', 'keyword'], true) ? $prompt : '',
            ];

            $body = null;
            try {
                $response = Http::retry(3, 300)->timeout(45)->post($webhook, $previewPayload);
                $candidate = $response->json();
                if (!$response->successful() || data_get($candidate, 'error')) {
                    throw new \RuntimeException('n8n preview webhook returned an invalid response.');
                }
                $body = $candidate;
            } catch (\Throwable $n8nException) {
                // اعتبار Anthropic ورکفلو ممکن است منقضی یا از سمت سرویس مسدود شده باشد.
                // برای پیش‌نمایش، از سرویس متنی پایدار خود سایت استفاده می‌کنیم و
                // ساخت نهایی/ارسال را به مسیر اصلی n8n دست‌نخورده واگذار می‌کنیم.
                Log::warning('Video studio preview n8n fallback activated', [
                    'product_id' => $product->id,
                    'channel' => $channel,
                    'content_type' => $contentType,
                    'error' => $n8nException->getMessage(),
                ]);

                $name = trim((string) $product->name_fa) ?: 'این محصول';
                $body = ['output' => match ($contentType) {
                    'hook' => ['hook_options' => [
                        "قبل از انتخاب {$name} این نکته را ببین",
                        "با {$name} انتخاب آگاهانه‌تری داشته باش",
                        "جزئیات {$name} را همین حالا ببین",
                    ]],
                    'cta' => ['cta_options' => [
                        "برای دیدن جزئیات {$name}، کپشن را بخوان",
                        "اگر {$name} را پسندیدی، همین حالا اقدام کن",
                        "برای دریافت اطلاعات بیشتر، کلمهٔ کلیدی را کامنت کن",
                    ]],
                    'keyword' => ['keyword_options' => ['اطلاعات', 'جزئیات', 'راهنما']],
                    default => ['caption_options' => [
                        "قبل از خرید {$name} این نکته‌ها را ببین.",
                        "با {$name} انتخاب آگاهانه‌تری داشته باش.",
                        "برای دیدن جزئیات {$name}، کپشن را بخوان.",
                    ]],
                }];
                try {
                    $fallbackSystem = 'تو نویسنده حرفه‌ای محتوای فارسی برای ویدیوهای کوتاه وطن هستی. فقط JSON معتبر و بدون Markdown برگردان. برای هر کلید آرایه‌ای دقیقاً ۳ گزینه متفاوت تولید کن. ادعای ساختگی، عدد بی‌منبع و وعده غیرواقعی ممنوع است. متن‌ها طبیعی، کوتاه، قابل انتشار و متناسب با شبکه اجتماعی باشند.';
                    $fallbackUser = "محصول: {$product->name_fa}\nتوضیحات محصول: " . trim((string) ($product->description_fa ?: $product->description_en ?: ''))
                        . "\nلینک محصول: " . (filled($product->route_slug) ? route('app.product', ['product' => $product->route_slug]) : '')
                        . "\nنوع خروجی: {$contentType}\nشبکه: {$channel}\nدستور مدیر: {$prompt}\n"
                        . 'ساختار خروجی دقیقاً شامل این کلیدها باشد: hook_options, caption_options, keyword_options, cta_options, dm_template. '
                        . 'برای نوع خروجی درخواستی، سه گزینه کامل و غیرتکراری بساز و برای کلیدهای دیگر هم اگر لازم است آرایه خالی برگردان.';
                    $fallback = app(OpenRouterService::class)->generateStructuredText($fallbackSystem, $fallbackUser);
                    if (is_array($fallback['content'] ?? null) && $fallback['content'] !== []) {
                        $body = ['output' => $fallback['content']];
                    }
                } catch (\Throwable $fallbackException) {
                    // اگر مدل متنی موقتاً در دسترس نبود، پیش‌نمایش نباید با خطای ۵۰۲ متوقف شود.
                    // این متن‌های کوتاه فقط مسیر پیش‌نمایش را زنده نگه می‌دارند؛ ساخت نهایی
                    // همچنان از مسیر اصلی مدل/ورکفلو استفاده می‌کند.
                    Log::warning('Video studio preview deterministic fallback activated', [
                        'product_id' => $product->id,
                        'content_type' => $contentType,
                        'error' => $fallbackException->getMessage(),
                    ]);
                }
            }

            $raw = data_get($body, 'content.0.text')
                ?? data_get($body, 'text')
                ?? data_get($body, 'output')
                ?? data_get($body, 'response')
                ?? data_get($body, 'result')
                ?? data_get($body, '0.json')
                ?? data_get($body, '0.output')
                ?? $body;
            // n8n/مدل‌ها گاهی خروجی را داخل یک آرایه یا کلید output برمی‌گردانند.
            // یک لایهٔ تودرتو را باز می‌کنیم تا کلیدهای پیشنهاد از دست نروند.
            if (is_array($raw) && count($raw) === 1 && is_array(reset($raw))) {
                $raw = reset($raw);
            }
            if (is_array($raw) && isset($raw['json']) && is_array($raw['json'])) {
                $raw = $raw['json'];
            }
            if (is_array($raw) && isset($raw['output']) && is_string($raw['output'])) {
                $raw = $raw['output'];
            }
            if (is_array($raw)) {
                $options = $raw;
            } else {
                $clean = trim((string) $raw);
                $clean = preg_replace('/^```(?:json)?\s*|\s*```$/u', '', $clean) ?: $clean;
                $options = json_decode($clean, true);
            }
            // پاسخ مدل ممکن است چند لایه داخل کلیدهای json، output، content یا text باشد.
            $decodeModelPayload = function ($value) use (&$decodeModelPayload) {
                if (is_string($value)) {
                    $clean = trim($value);
                    $fence = str_repeat(chr(96), 3);
                    $clean = preg_replace('/^' . preg_quote($fence, '/') . '(?:json)?\s*|\s*' . preg_quote($fence, '/') . '$/u', '', $clean) ?: $clean;
                    $decoded = json_decode($clean, true);
                    if (is_array($decoded)) {
                        return $decodeModelPayload($decoded);
                    }

                    // بعضی مدل‌ها قبل یا بعد از `JSON` یک جملهٔ کوتاه اضافه می‌کنند.
                    // اولین شیء/آرایهٔ قابل‌تجزیه را از متن جدا می‌کنیم.
                    foreach ([['{', '}'], ['[', ']']] as [$opening, $closing]) {
                        $start = mb_strpos($clean, $opening);
                        $end = mb_strrpos($clean, $closing);
                        if ($start === false || $end === false || $end <= $start) {
                            continue;
                        }
                        $embedded = json_decode(mb_substr($clean, $start, $end - $start + 1), true);
                        if (is_array($embedded)) {
                            return $decodeModelPayload($embedded);
                        }
                    }

                    return $value;
                }
                if (!is_array($value)) {
                    return $value;
                }
                foreach (['hook_options', 'caption_options', 'keyword_options', 'cta_options'] as $optionKey) {
                    if (array_key_exists($optionKey, $value)) {
                        return $value;
                    }
                }
                foreach (['json', 'output', 'content', 'text', 'response', 'result', 'message', 'body', 'data', 'choices'] as $nestedKey) {
                    if (!array_key_exists($nestedKey, $value)) {
                        continue;
                    }
                    $nested = $decodeModelPayload($value[$nestedKey]);
                    if (is_array($nested)) {
                        return $nested;
                    }
                }
                if (array_is_list($value)) {
                    foreach ($value as $item) {
                        $nested = $decodeModelPayload($item);
                        if (!is_array($nested)) {
                            continue;
                        }
                        foreach (['hook_options', 'caption_options', 'keyword_options', 'cta_options', 'captions', 'keywords', 'hooks', 'ctas'] as $optionKey) {
                            if (array_key_exists($optionKey, $nested)) {
                                return $nested;
                            }
                        }
                    }
                }
                return count($value) === 1 ? $decodeModelPayload(reset($value)) : $value;
            };
            $options = $decodeModelPayload($options);
            if (is_string($options)) {
                $lines = preg_split('/\R+/u', trim($options), -1, PREG_SPLIT_NO_EMPTY) ?: [];
                $lines = array_values(array_filter(array_map(static function ($line): string {
                    return trim((string) preg_replace('/^\s*(?:[-*•]|\d+[.)])\s*/u', '', $line));
                }, $lines)));
                if ($lines !== []) {
                    $optionKey = match ($contentType) {
                        'hook' => 'hook_options',
                        'cta' => 'cta_options',
                        'keyword' => 'keyword_options',
                        default => 'caption_options',
                    };
                    $options = [$optionKey => $lines];
                }
            }
            if (!is_array($options)) {
                return response()->json(['message' => 'خروجی مدل قابل تبدیل به پیشنهادهای محتوا نبود.'], 502);
            }

            $normalize = static function (string $key) use ($options): array {
                $aliases = match ($key) {
                    'caption' => ['caption_options', 'captions', 'caption'],
                    'keyword' => ['keyword_options', 'keywords', 'keyword'],
                    'hook' => ['hook_options', 'hooks', 'hook'],
                    'cta' => ['cta_options', 'ctas', 'cta'],
                    default => [$key . '_options', $key],
                };
                $value = [];
                foreach ($aliases as $alias) {
                    if (array_key_exists($alias, $options)) {
                        $value = $options[$alias];
                        break;
                    }
                }
                if ($value === []) {
                    foreach (['suggestions', 'options', 'items', 'proposals'] as $genericAlias) {
                        if (array_key_exists($genericAlias, $options)) {
                            $value = $options[$genericAlias];
                            break;
                        }
                    }
                }
                if ($value === [] && array_is_list($options)) {
                    $value = $options;
                }
                $value = is_array($value) ? $value : [$value];
                $value = array_values(array_filter(array_map(static function ($item): string {
                    if (is_array($item)) {
                        $rawItem = $item;
                        $item = $rawItem['text']
                            ?? $item['value']
                            ?? $item['content']
                            ?? $item['caption']
                            ?? $item['hook']
                            ?? $item['cta']
                            ?? $item['title']
                            ?? $item['name']
                            ?? data_get($rawItem, 'message.content')
                            ?? data_get($rawItem, 'json.text')
                            ?? '';
                        if ($item === '' || $item === null) {
                            $label = trim((string) ($rawItem['name'] ?? $rawItem['title'] ?? ''));
                            $description = trim((string) ($rawItem['description'] ?? $rawItem['text'] ?? ''));
                            $item = trim($label . ($label !== '' && $description !== '' ? ' — ' : '') . $description);
                        }
                    }
                    return trim((string) $item);
                }, $value)));
                return array_slice(array_pad($value, 3, $value[0] ?? ''), 0, 3);
            };
            $hooks = $normalize('hook');
            $captions = $normalize('caption');
            $keywords = $normalize('keyword');
            $ctas = $normalize('cta');
            // کپشن اینستاگرام یک خروجی ترکیبی است: همان درخواست باید هم‌زمان
            // سه کپشن و سه کلمهٔ کلیدی برگرداند. بعضی نودهای قدیمی فقط کپشن را
            // برمی‌گردانند؛ در این حالت پاسخ را سمت سرور کامل می‌کنیم تا رابط
            // کاربر هیچ‌وقت با «پیشنهادی از مدل دریافت نشد» متوقف نشود.
            if ($contentType === 'caption' && $channel === 'instagram' && count(array_filter($keywords)) === 0) {
                $keywords = $this->defaultInstagramKeywords($product);
            }
            if (count(array_filter($captions)) === 0 && in_array($contentType, ['caption', 'keyword'], true)) {
                $captions = $this->defaultSocialCaptions($product, $channel);
            }
            if (count(array_filter($keywords)) === 0 && $contentType === 'keyword') {
                $keywords = $this->defaultInstagramKeywords($product);
            }
            if ($contentType === 'cta' && count(array_filter($ctas)) === 0) {
                $ctas = $captions;
            }
            if (count(array_filter($ctas)) === 0) {
                $ctas = array_fill(0, 3, 'برای دیدن جزئیات این محصول، کپشن را بخوان و کلمهٔ کلیدی را کامنت کن.');
            }
            $relevantOptions = match ($contentType) {
                'hook' => $hooks,
                'cta' => $ctas,
                'keyword' => $keywords,
                default => $captions,
            };
            if (count(array_filter($relevantOptions)) === 0) {
                return response()->json(['message' => 'پیشنهادی از مدل دریافت نشد.'], 502);
            }

            return response()->json([
                'hook_options' => $hooks,
                'caption_options' => $captions,
                'keyword_options' => $keywords,
                'cta_options' => $ctas,
                'hook' => $hooks[0] ?? '',
                'caption' => $captions[0] ?? '',
                'keyword' => $keywords[0] ?? '',
                'cta' => $ctas[0] ?? '',
                'dm_template' => trim((string) ($options['dm_template'] ?? ($channel === 'instagram' ? 'برای دریافت اطلاعات بیشتر، کلمهٔ کلیدی را در دایرکت ارسال کنید.' : ''))),
            ]);
        } catch (ValidationException $e) {
            return response()->json([
                'message' => collect($e->errors())->flatten()->filter()->first() ?: 'اطلاعات پیش‌نمایش کامل نیست.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Throwable $e) {
            report($e);
            Log::error('Video studio preview failed', [
                'message' => $e->getMessage(),
                'exception' => get_class($e),
                'trace' => mb_substr($e->getTraceAsString(), 0, 4000),
            ]);
            // حتی در خطای غیرمنتظره‌ی سرویس بیرونی، رابط پیش‌نمایش باید خروجی قابل
            // استفاده داشته باشد و کاربر با خطای خام مدل متوقف نشود.
            $fallbackProduct = Product::query()->find((int) $request->input('product_id'));
            $fallbackName = trim((string) ($fallbackProduct?->name_fa ?? 'این محصول')) ?: 'این محصول';
            $fallbackType = (string) $request->input('content_type', 'caption');
            $fallback = match ($fallbackType) {
                'hook' => [
                    "قبل از انتخاب {$fallbackName} این نکته را ببین",
                    "با {$fallbackName} انتخاب آگاهانه‌تری داشته باش",
                    "جزئیات {$fallbackName} را همین حالا ببین",
                ],
                'cta' => [
                    "برای دیدن جزئیات {$fallbackName}، کپشن را بخوان",
                    "اگر {$fallbackName} را پسندیدی، همین حالا اقدام کن",
                    "برای دریافت اطلاعات بیشتر، کلمهٔ کلیدی را کامنت کن",
                ],
                'keyword' => ['اطلاعات', 'جزئیات', 'راهنما'],
                default => [
                    "قبل از خرید {$fallbackName} این نکته‌ها را ببین.",
                    "با {$fallbackName} انتخاب آگاهانه‌تری داشته باش.",
                    "برای دیدن جزئیات {$fallbackName}، کپشن را بخوان.",
                ],
            };
            return response()->json([
                'hook_options' => $fallbackType === 'hook' ? $fallback : [],
                'caption_options' => in_array($fallbackType, ['caption', 'keyword'], true) ? $fallback : [],
                'keyword_options' => $fallbackType === 'keyword' ? $fallback : [],
                'cta_options' => $fallbackType === 'cta' ? $fallback : [],
                'dm_template' => $fallbackType === 'caption' && $channel === 'instagram'
                    ? 'برای دریافت اطلاعات بیشتر، کلمهٔ کلیدی را در دایرکت ارسال کنید.'
                    : '',
            ]);
        }
    }

    /**
     * گزینه‌های قطعی و رایگان برای وقتی که سرویس مدل یا نود پیش‌نمایش پاسخ
     * معتبر نمی‌دهد. این متن‌ها جایگزین تنظیمات مدیر نیستند؛ فقط قرارداد پاسخ
     * رابط را کامل نگه می‌دارند.
     */
    private function defaultSocialCaptions(Product $product, string $channel): array
    {
        $name = trim((string) $product->name_fa) ?: 'این محصول';
        $link = filled($product->route_slug) ? route('app.product', ['product' => $product->route_slug]) : '';
        $suffix = $link !== '' ? "\n{$link}" : '';

        return match ($channel) {
            'youtube' => [
                "{$name}؛ معرفی کوتاه و کاربردی برای یک انتخاب آگاهانه{$suffix}",
                "قبل از انتخاب {$name} این ویدیوی کوتاه را ببین{$suffix}",
                "ویژگی‌های مهم {$name} را در چند ثانیه ببین{$suffix}",
            ],
            'aparat' => [
                "معرفی {$name}؛ نکته‌های مهم قبل از خرید{$suffix}",
                "{$name} را سریع و خلاصه بشناس{$suffix}",
                "این ویدیو راهنمای کوتاه انتخاب {$name} است{$suffix}",
            ],
            'linkedin' => [
                "یک نگاه کوتاه به {$name} و کاربردهای آن{$suffix}",
                "چرا {$name} می‌تواند انتخاب مناسبی باشد؟{$suffix}",
                "نکته‌های کلیدی دربارهٔ {$name} برای تصمیم بهتر{$suffix}",
            ],
            default => [
                "قبل از خرید {$name} این نکته‌ها را ببین.",
                "با {$name} انتخاب آگاهانه‌تری داشته باش.",
                "برای دیدن جزئیات {$name}، کپشن را بخوان.",
            ],
        };
    }

    private function defaultInstagramKeywords(Product $product): array
    {
        $name = trim((string) $product->name_fa) ?: 'محصول';
        $firstWord = trim((string) preg_split('/\s+/u', $name)[0]);

        return array_values(array_unique(array_filter([
            $firstWord !== '' ? $firstWord : 'محصول',
            'جزئیات',
            'راهنما',
        ])));
    }

    public function storeHook(Request $request)
    {
        $data = $request->validate([
            'product_id' => ['nullable', 'integer', 'exists:products,id'],
            'title' => ['required', 'string', 'max:160'],
            'hook_text' => ['required', 'string', 'max:1000'],
            'tags' => ['nullable', 'string', 'max:500'],
        ]);
        VideoHookInspiration::create($data);

        return back()->with('success', 'هوک به کتابخانه ایده‌ها اضافه شد.');
    }

    public function updateHook(Request $request, VideoHookInspiration $hook)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:160'],
            'hook_text' => ['required', 'string', 'max:1000'],
            'tags' => ['nullable', 'string', 'max:500'],
        ]);
        $hook->update($data);

        return back()->with('success', 'هوک ویرایش شد.');
    }

    public function destroyHook(VideoHookInspiration $hook)
    {
        $hook->delete();

        return back()->with('success', 'هوک از کتابخانه حذف شد.');
    }

    public function storeSource(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:160'],
            'type' => ['required', Rule::in(['music', 'video'])],
            'source_url' => ['nullable', 'url', 'max:2048'],
            'source_file' => ['nullable', 'file', 'mimes:mp3,wav,m4a,ogg,mp4,mov,webm', 'max:102400'],
        ]);
        if ($request->hasFile('source_file')) {
            $data['source_url'] = asset('storage/' . ltrim($request->file('source_file')->store('video-studio/library', 'public'), '/'));
        }
        if (blank($data['source_url'] ?? null)) {
            return back()->withErrors(['source_url' => 'برای منبع، لینک یا فایل انتخاب کنید.']);
        }
        unset($data['source_file']);
        VideoStudioSource::create($data);

        return back()->with('success', 'منبع صدا به کتابخانه اضافه شد.');
    }

    public function destroySource(VideoStudioSource $source)
    {
        $source->delete();

        return back()->with('success', 'منبع از کتابخانه حذف شد.');
    }

    public function createJob(Request $request)
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'source_mode' => ['required', Rule::in(['auto', 'upload', 'music', 'video'])],
            'source_url' => ['nullable', 'url', 'max:2048'],
            'source_file' => ['nullable', 'file', 'mimes:mp3,wav,m4a,ogg,mp4,mov,webm', 'max:102400'],
            'selected_images' => ['nullable', 'array', 'max:10'],
            'selected_images.*' => ['string', 'max:2048'],
            'selected_image_order' => ['nullable', 'array', 'max:10'],
            'selected_image_order.*' => ['string', 'max:2048'],
            'aspect_ratio' => ['required', Rule::in(['9:16', '1:1', '4:5', '16:9'])],
            'instagram_enabled' => ['nullable', 'boolean'],
            'telegram_enabled' => ['nullable', 'boolean'],
            'youtube_enabled' => ['nullable', 'boolean'],
            'aparat_enabled' => ['nullable', 'boolean'],
            'linkedin_enabled' => ['nullable', 'boolean'],
            'telegram_send_video' => ['nullable', 'boolean'],
            'telegram_send_images' => ['nullable', 'boolean'],
            'instagram_send_video' => ['nullable', 'boolean'],
            'instagram_send_images' => ['nullable', 'boolean'],
            'youtube_send_video' => ['nullable', 'boolean'],
            'youtube_send_images' => ['nullable', 'boolean'],
            'aparat_send_video' => ['nullable', 'boolean'],
            'aparat_send_images' => ['nullable', 'boolean'],
            'linkedin_send_video' => ['nullable', 'boolean'],
            'linkedin_send_images' => ['nullable', 'boolean'],
            'cta_enabled' => ['nullable', 'boolean'],
            'cta_text' => ['nullable', 'string', 'max:1000'],
            'cta_background' => ['nullable', 'string', 'max:60', function (string $attribute, mixed $value, \Closure $fail): void {
                if (! $this->isKnownHookColor((string) $value, 'background')) {
                    $fail('رنگ پس‌زمینه CTA معتبر نیست.');
                }
            }],
            'cta_text_color' => ['nullable', 'string', 'max:60', function (string $attribute, mixed $value, \Closure $fail): void {
                if (! $this->isKnownHookColor((string) $value, 'text')) {
                    $fail('رنگ متن CTA معتبر نیست.');
                }
            }],
            'cta_font_size' => ['nullable', 'numeric', 'between:20,72'],
            'cta_font_weight' => ['nullable', 'integer', 'between:1,5'],
            'cta_scale' => ['nullable', 'numeric', 'between:0.7,1.5'],
            'cta_vertical_offset' => ['nullable', 'numeric', 'between:-45,45'],
            'cta_guidelines' => ['nullable', 'string', 'max:5000'],
            'cta_duration' => ['nullable', 'numeric', 'between:0.1,5'],
            'cta_duration_mode' => ['nullable', Rule::in(['manual', 'auto'])],
            'hook_background' => ['nullable', 'string', 'max:60', function (string $attribute, mixed $value, \Closure $fail): void {
                if (! $this->isKnownHookColor((string) $value, 'background')) {
                    $fail('رنگ پس‌زمینه هوک معتبر نیست.');
                }
            }],
            'hook_text_color' => ['nullable', 'string', 'max:60', function (string $attribute, mixed $value, \Closure $fail): void {
                if (! $this->isKnownHookColor((string) $value, 'text')) {
                    $fail('رنگ متن هوک معتبر نیست.');
                }
            }],
            'hook_font_size' => ['nullable', 'numeric', 'between:20,72'],
            'hook_font_weight' => ['nullable', 'integer', 'between:1,5'],
            'hook_scale' => ['nullable', 'numeric', 'between:0.7,1.5'],
            'hook_vertical_offset' => ['nullable', 'numeric', 'between:-45,45'],
            'hook_duration' => ['nullable', 'numeric', 'between:0.1,5'],
            'hook_duration_mode' => ['nullable', Rule::in(['manual', 'auto'])],
            'hook_guidelines' => ['nullable', 'string', 'max:5000'],
            'hook_position' => ['nullable', Rule::in(['top', 'center', 'bottom', 'side'])],
            'cta_position' => ['nullable', Rule::in(['top', 'center', 'bottom', 'side'])],
            'transition' => ['nullable', Rule::in(['cut', 'fade', 'blur', 'slide'])],
            'transition_duration' => ['nullable', 'numeric', 'between:0.2,1.5'],
            'text_command' => ['nullable', 'string', 'max:5000'],
            'font_family' => ['required', Schema::hasTable('video_studio_fonts')
                ? Rule::exists('video_studio_fonts', 'slug')->where('is_active', true)
                : Rule::in(['B_Yekan'])],
            'hook_text' => ['nullable', 'string', 'max:1000'],
            'caption_text' => ['nullable', 'string', 'max:5000'],
            'telegram_caption_text' => ['nullable', 'string', 'max:5000'],
            'prompt_profile' => ['nullable', 'string', 'max:30000'],
            'instagram_prompt' => ['nullable', 'string', 'max:30000'],
            'telegram_prompt' => ['nullable', 'string', 'max:30000'],
            'youtube_prompt' => ['nullable', 'string', 'max:30000'],
            'aparat_prompt' => ['nullable', 'string', 'max:30000'],
            'linkedin_prompt' => ['nullable', 'string', 'max:30000'],
            'channel' => ['nullable', Rule::in(['instagram', 'telegram', 'youtube', 'aparat', 'linkedin'])],
            'telegram_buttons_enabled' => ['nullable', 'boolean'],
            'telegram_button_label' => ['nullable', 'array', 'max:8'],
            'telegram_button_label.*' => ['nullable', 'string', 'max:80'],
            'telegram_button_url' => ['nullable', 'array', 'max:8'],
            'telegram_button_url.*' => ['nullable', 'url', 'max:2048'],
            'telegram_button_style' => ['nullable', 'array', 'max:8'],
            'telegram_button_style.*' => ['nullable', Rule::in(['primary', 'success', 'danger'])],
            'telegram_button_width' => ['nullable', 'array', 'max:8'],
            'telegram_button_width.*' => ['nullable', Rule::in(['full', 'half'])],
            'prompt_file' => ['nullable', 'file', 'mimes:txt,md', 'max:512'],
            'keyword' => ['nullable', 'string', 'max:80'],
            'dm_template' => ['nullable', 'string', 'max:5000'],
            'build_now' => ['nullable', 'boolean'],
            'source_library_id' => ['nullable', 'integer', 'exists:video_studio_sources,id'],
            'preview_hook' => ['nullable', 'string', 'max:1000'],
            'preview_caption' => ['nullable', 'string', 'max:5000'],
            'preview_keyword' => ['nullable', 'string', 'max:80'],
            'parent_job_id' => ['nullable', 'integer', 'exists:video_studio_jobs,id'],
            'version' => ['nullable', 'integer', 'min:1', 'max:99'],
            'editing_rules' => ['nullable', 'json'],
        ]);

        // ترتیب انتخاب مدیر روی تصاویر، ترتیب نمایش پلان‌ها بعد از هوک است؛ این ترتیب
        // از ترتیب اولیهٔ تصاویر محصول جدا نگه‌داری می‌شود تا دقیقاً به ورکفلو برسد.
        $data['selected_images'] = collect($data['selected_image_order'] ?? $data['selected_images'] ?? [])
            ->map(static fn ($image): string => trim((string) $image))
            ->filter()
            ->unique()
            ->take(10)
            ->values()
            ->all();
        unset($data['selected_image_order']);

        if ($request->hasFile('source_file')) {
            $data['source_url'] = asset('storage/' . ltrim($request->file('source_file')->store('video-studio/sources', 'public'), '/'));
        }
        if ($request->hasFile('prompt_file')) {
            $profileText = trim((string) file_get_contents($request->file('prompt_file')->getRealPath()));
            if ($profileText !== '') {
                $data['prompt_profile'] = $profileText;
            }
        }
        if (blank($data['instagram_prompt'] ?? null) && filled($data['prompt_profile'] ?? null)) {
            $data['instagram_prompt'] = $data['prompt_profile'];
        }
        $hookBackground = $this->resolveHookColor((string) ($data['hook_background'] ?? 'primary'), 'background');
        $hookTextColor = $this->resolveHookColor((string) ($data['hook_text_color'] ?? 'light'), 'text');
        $data['hook_background'] = $hookBackground['key'];
        $data['hook_background_color'] = $hookBackground['render_value'];
        $data['hook_text_color'] = $hookTextColor['key'];
        $data['hook_text_color_value'] = $hookTextColor['render_value'];
        $ctaBackground = $this->resolveHookColor((string) ($data['cta_background'] ?? 'primary'), 'background');
        $ctaTextColor = $this->resolveHookColor((string) ($data['cta_text_color'] ?? 'light'), 'text');
        $data['cta_background'] = $ctaBackground['key'];
        $data['cta_background_color'] = $ctaBackground['render_value'];
        $data['cta_text_color'] = $ctaTextColor['key'];
        $data['cta_text_color_value'] = $ctaTextColor['render_value'];
        if (Schema::hasTable('video_studio_social_prompts')) {
            $savedPrompts = VideoStudioSocialPrompt::query()
                ->where('admin_id', auth('admin')->id())
                ->pluck('prompt', 'platform');
        } else {
            $savedPrompts = collect();
        }
        foreach (['instagram', 'telegram', 'youtube', 'aparat', 'linkedin'] as $platform) {
            $key = $platform . '_prompt';
            if (blank($data[$key] ?? null) && filled($savedPrompts[$platform] ?? null)) {
                $data[$key] = (string) $savedPrompts[$platform];
            }
        }
        if (Schema::hasTable('video_studio_social_prompts')) {
            if (blank($data['hook_guidelines'] ?? null) && filled($savedPrompts['hook'] ?? null)) {
                $data['hook_guidelines'] = (string) $savedPrompts['hook'];
            }
        }
        $telegramButtons = $this->normalizeTelegramButtons($request);
        unset($data['telegram_buttons_enabled'], $data['telegram_button_label'], $data['telegram_button_url'], $data['telegram_button_style'], $data['telegram_button_width']);
        // مقدار لینکِ پنهان فرم نباید باعث استفادهٔ دوباره از منبع سفارش قبلی شود.
        // در حالت خودکار فقط کتابخانهٔ فعال و معتبر مجاز است.
        if (($data['source_mode'] ?? null) === 'auto' && empty($data['source_library_id'])) {
            $data['source_url'] = null;
        }
        if (!empty($data['source_library_id'])) {
            $librarySource = VideoStudioSource::query()->where('is_active', true)->findOrFail((int) $data['source_library_id']);
            $data['source_mode'] = $librarySource->type;
            $data['source_url'] = $librarySource->source_url;
        }
        // در حالت خودکار، منبعی از کتابخانه که کمترین مصرف را دارد انتخاب می‌کنیم
        // تا هر سفارش از یک منبع قبلی تکراری استفاده نکند و گردش منابع قابل ردیابی بماند.
        if (($data['source_mode'] ?? null) === 'auto'
            && empty($data['source_library_id'])
            && Schema::hasTable('video_studio_sources')) {
            $librarySource = VideoStudioSource::query()
                ->where('is_active', true)
                ->whereNotNull('source_url')
                ->where('source_url', '<>', '')
                ->orderBy('used_count')
                ->orderBy('id')
                ->first();
            if ($librarySource) {
                $data['source_library_id'] = $librarySource->id;
                $data['source_mode'] = $librarySource->type;
                $data['source_url'] = $librarySource->source_url;
            }
        }
        $sourceError = null;
        if (blank($data['source_url'])) {
            $sourceError = 'منبع صوت یا ویدیو انتخاب نشده است. از کتابخانه یک منبع معتبر انتخاب کنید یا فایل/لینک جدید بدهید.';
        }
        if (in_array($data['source_mode'], ['upload', 'music', 'video'], true) && blank($data['source_url'])) {
            return back()
                ->withErrors(['source_file' => 'برای این منبع، حتماً فایل یا لینک جدید انتخاب کنید؛ منبع قبلی دوباره استفاده نمی‌شود.'])
                ->withInput();
        }
        unset($data['source_file']);
        unset($data['prompt_file']);
        $autoHook = $request->boolean('auto_generate_hook');
        $autoCaption = $request->boolean('auto_generate_caption');
        $autoKeyword = $request->boolean('auto_generate_keyword');
        if (filled($data['preview_hook'] ?? null)) {
            $data['hook_text'] = trim((string) $data['preview_hook']);
            $autoHook = false;
        }
        if (filled($data['preview_caption'] ?? null)) {
            $data['caption_text'] = trim((string) $data['preview_caption']);
            $autoCaption = false;
        }
        if (filled($data['preview_keyword'] ?? null)) {
            $data['keyword'] = trim((string) $data['preview_keyword']);
            $autoKeyword = false;
        }
        $buildNow = $request->boolean('build_now');
        $parentJobId = (int) ($data['parent_job_id'] ?? 0) ?: null;
        $version = max(1, min(99, (int) ($data['version'] ?? 1)));
        unset($data['parent_job_id'], $data['version']);
        $editingRules = $this->normalizeVideoEditingRules($request->input('editing_rules'),
            (string) ($data['aspect_ratio'] ?? '9:16'),
            (string) ($data['transition'] ?? 'cut'),
            (float) ($data['transition_duration'] ?? 0.5),
        );
        $renderInstructions = $this->videoEditingInstructions();
        $instagramEnabled = $request->has('instagram_enabled') ? $request->boolean('instagram_enabled') : true;
        $telegramEnabled = $request->has('telegram_enabled') ? $request->boolean('telegram_enabled') : true;
        $youtubeEnabled = $request->boolean('youtube_enabled');
        $aparatEnabled = $request->boolean('aparat_enabled');
        $linkedinEnabled = $request->boolean('linkedin_enabled');
        $platformError = (!$instagramEnabled && !$telegramEnabled && !$youtubeEnabled && !$aparatEnabled && !$linkedinEnabled)
            ? 'حداقل یکی از خروجی‌های شبکه‌های اجتماعی باید روشن باشد.'
            : null;
        if ($autoHook) $data['hook_text'] = null;
        if ($autoCaption) $data['caption_text'] = null;
        if ($autoKeyword) $data['keyword'] = null;
        $sourceFingerprint = hash('sha256', json_encode([
            'product_id' => (int) $data['product_id'],
            'source_mode' => (string) $data['source_mode'],
            'source_url' => (string) ($data['source_url'] ?? ''),
            'selected_images' => array_values($data['selected_images'] ?? []),
            'aspect_ratio' => (string) $data['aspect_ratio'],
            'hook_duration' => (float) ($data['hook_duration'] ?? 2),
            'hook_duration_mode' => (string) ($data['hook_duration_mode'] ?? 'manual'),
            'cta_duration' => (float) ($data['cta_duration'] ?? 2),
            'cta_duration_mode' => (string) ($data['cta_duration_mode'] ?? 'manual'),
            'cta_enabled' => (bool) ($data['cta_enabled'] ?? true),
            'cta_text' => (string) ($data['cta_text'] ?? ''),
            'cta_background' => (string) ($data['cta_background'] ?? 'primary'),
            'cta_text_color' => (string) ($data['cta_text_color'] ?? 'light'),
            'cta_font_size' => (float) ($data['cta_font_size'] ?? 36),
            'cta_font_weight' => (int) ($data['cta_font_weight'] ?? 3),
            'cta_scale' => (float) ($data['cta_scale'] ?? 1),
            'cta_vertical_offset' => (float) ($data['cta_vertical_offset'] ?? 0),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $recentDuplicate = VideoStudioJob::query()
            ->whereIn('status', ['queued', 'processing'])
            ->latest('id')
            ->limit(50)
            ->get()
            ->first(fn (VideoStudioJob $candidate): bool => (string) data_get($candidate->payload, 'source_fingerprint') === $sourceFingerprint);
        if ($recentDuplicate) {
            return redirect()
                ->route('admin.video-studio.experimental', ['product_id' => $recentDuplicate->product_id])
                ->with('warning', "این ترکیب محصول و منبع از قبل در صف است (#{$recentDuplicate->id}) و دوباره ارسال نشد.");
        }
        $job = VideoStudioJob::create(array_merge($data, [
            'admin_id' => auth('admin')->id(),
            // سفارش ساخت بدون منبع نباید در حالت «در حال ساخت» معلق بماند؛
            // همان ابتدا به‌عنوان ناموفق ثبت می‌شود تا دلیل آن در صف دیده شود.
            'status' => $buildNow && ($sourceError || $platformError) ? 'failed' : 'queued',
            'error_message' => $buildNow ? ($sourceError ?: $platformError) : null,
            'payload' => [
                'created_from' => 'video_studio_dashboard',
                'auto_generate_hook' => $autoHook,
                'auto_generate_caption' => $autoCaption,
                'auto_generate_keyword' => $autoKeyword,
                'hook_guidelines' => (string) ($data['hook_guidelines'] ?? ''),
                'caption_guidelines' => (string) $request->input('caption_guidelines', ''),
                'font_family' => (string) ($data['font_family'] ?? 'B_Yekan'),
                'prompt_profile' => (string) ($data['prompt_profile'] ?? ''),
                'instagram_prompt' => (string) ($data['instagram_prompt'] ?? ''),
                'telegram_prompt' => (string) ($data['telegram_prompt'] ?? ''),
                'youtube_prompt' => (string) ($data['youtube_prompt'] ?? ''),
                'aparat_prompt' => (string) ($data['aparat_prompt'] ?? ''),
                'linkedin_prompt' => (string) ($data['linkedin_prompt'] ?? ''),
                'telegram_caption_text' => (string) ($data['telegram_caption_text'] ?? ''),
                'youtube_caption_text' => (string) ($data['youtube_caption_text'] ?? ''),
                'aparat_caption_text' => (string) ($data['aparat_caption_text'] ?? ''),
                'linkedin_caption_text' => (string) ($data['linkedin_caption_text'] ?? ''),
                'telegram_buttons' => $telegramButtons,
                'channel' => (string) ($data['channel'] ?? 'instagram'),
                'source_fingerprint' => $sourceFingerprint,
                'build_now' => $buildNow,
                'source_library_id' => (int) ($data['source_library_id'] ?? 0) ?: null,
                'preview_selected' => filled($data['preview_hook'] ?? null) || filled($data['preview_caption'] ?? null) || filled($data['preview_keyword'] ?? null),
                'instagram_enabled' => $instagramEnabled,
                'telegram_enabled' => $telegramEnabled,
                'youtube_enabled' => $youtubeEnabled,
                'aparat_enabled' => $aparatEnabled,
                'linkedin_enabled' => $linkedinEnabled,
                'telegram_send_video' => $request->boolean('telegram_send_video'),
                'telegram_send_images' => $request->boolean('telegram_send_images'),
                'instagram_send_video' => $request->boolean('instagram_send_video'),
                'instagram_send_images' => $request->boolean('instagram_send_images'),
                'youtube_send_video' => $request->boolean('youtube_send_video'),
                'youtube_send_images' => $request->boolean('youtube_send_images'),
                'aparat_send_video' => $request->boolean('aparat_send_video'),
                'aparat_send_images' => $request->boolean('aparat_send_images'),
                'linkedin_send_video' => $request->boolean('linkedin_send_video'),
                'linkedin_send_images' => $request->boolean('linkedin_send_images'),
                'cta_enabled' => $request->has('cta_enabled') ? $request->boolean('cta_enabled') : true,
                'cta_text' => (string) ($data['cta_text'] ?? ''),
                'cta_background' => (string) ($data['cta_background'] ?? 'primary'),
                'cta_background_color' => (string) ($data['cta_background_color'] ?? '#16594F'),
                'cta_text_color' => (string) ($data['cta_text_color'] ?? 'light'),
                'cta_text_color_value' => (string) ($data['cta_text_color_value'] ?? '#FFFFFF'),
                'cta_font_size' => (float) ($data['cta_font_size'] ?? 36),
                'cta_font_weight' => (int) ($data['cta_font_weight'] ?? 3),
                'cta_scale' => (float) ($data['cta_scale'] ?? 1),
                'cta_vertical_offset' => (float) ($data['cta_vertical_offset'] ?? 0),
                'cta_guidelines' => (string) ($data['cta_guidelines'] ?? ''),
                'cta_duration' => (float) ($data['cta_duration'] ?? 2),
                'cta_duration_mode' => (string) ($data['cta_duration_mode'] ?? 'manual'),
                'hook_background' => (string) ($data['hook_background'] ?? 'primary'),
                'hook_background_color' => (string) ($data['hook_background_color'] ?? '#16594F'),
                'hook_text_color' => (string) ($data['hook_text_color'] ?? 'light'),
                'hook_text_color_value' => (string) ($data['hook_text_color_value'] ?? '#FFFFFF'),
                'hook_font_size' => (float) ($data['hook_font_size'] ?? 36),
                'hook_font_weight' => (int) ($data['hook_font_weight'] ?? 3),
                'hook_scale' => (float) ($data['hook_scale'] ?? 1),
                'hook_vertical_offset' => (float) ($data['hook_vertical_offset'] ?? 0),
                'hook_duration' => (float) ($data['hook_duration'] ?? 2),
                'hook_duration_mode' => (string) ($data['hook_duration_mode'] ?? 'manual'),
                'image_sequence' => collect($data['selected_images'] ?? [])
                    ->values()
                    ->map(static fn (string $url, int $index): array => ['url' => $url, 'order' => $index + 1])
                    ->all(),
                'hook_position' => (string) ($data['hook_position'] ?? 'center'),
                'cta_position' => (string) ($data['cta_position'] ?? 'bottom'),
                'transition' => (string) ($data['transition'] ?? 'cut'),
                'transition_duration' => (float) ($data['transition_duration'] ?? 0.5),
                'editing_rules' => $editingRules,
                'render_instructions' => $renderInstructions,
                'text_command' => trim((string) ($data['text_command'] ?? '')),
                'parent_job_id' => $parentJobId,
                'version' => $version,
                'render_config' => [
                    'font_family' => (string) ($data['font_family'] ?? 'B_Yekan'),
                    'hook_background' => (string) ($data['hook_background'] ?? 'primary'),
                    'hook_background_color' => (string) ($data['hook_background_color'] ?? '#16594F'),
                    'hook_text_color' => (string) ($data['hook_text_color'] ?? 'light'),
                    'hook_text_color_value' => (string) ($data['hook_text_color_value'] ?? '#FFFFFF'),
                    'hook_font_size' => (float) ($data['hook_font_size'] ?? 36),
                    'hook_font_weight' => (int) ($data['hook_font_weight'] ?? 3),
                    'hook_scale' => (float) ($data['hook_scale'] ?? 1),
                    'hook_vertical_offset' => (float) ($data['hook_vertical_offset'] ?? 0),
                    'hook_duration' => (float) ($data['hook_duration'] ?? 2),
                    'hook_duration_mode' => (string) ($data['hook_duration_mode'] ?? 'manual'),
                    'hook_position' => (string) ($data['hook_position'] ?? 'center'),
                    'cta_position' => (string) ($data['cta_position'] ?? 'bottom'),
                    'cta_enabled' => $request->has('cta_enabled') ? $request->boolean('cta_enabled') : true,
                    'cta_text' => (string) ($data['cta_text'] ?? ''),
                    'cta_background' => (string) ($data['cta_background'] ?? 'primary'),
                    'cta_background_color' => (string) ($data['cta_background_color'] ?? '#16594F'),
                    'cta_text_color' => (string) ($data['cta_text_color'] ?? 'light'),
                    'cta_text_color_value' => (string) ($data['cta_text_color_value'] ?? '#FFFFFF'),
                    'cta_font_size' => (float) ($data['cta_font_size'] ?? 36),
                    'cta_font_weight' => (int) ($data['cta_font_weight'] ?? 3),
                    'cta_scale' => (float) ($data['cta_scale'] ?? 1),
                    'cta_vertical_offset' => (float) ($data['cta_vertical_offset'] ?? 0),
                    'cta_guidelines' => (string) ($data['cta_guidelines'] ?? ''),
                    'cta_duration' => (float) ($data['cta_duration'] ?? 2),
                    'cta_duration_mode' => (string) ($data['cta_duration_mode'] ?? 'manual'),
                    'transition' => (string) ($data['transition'] ?? 'cut'),
                    'transition_duration' => (float) ($data['transition_duration'] ?? 0.5),
                    'editing_rules' => $editingRules,
                    'render_instructions' => $renderInstructions,
                ],
                'estimated_cost' => $this->estimateVideoCost((int) $data['product_id'], (string) $data['aspect_ratio'], (string) ($data['source_mode'] ?? 'auto')),
            ],
        ]));

        if ($buildNow && !$sourceError && !$platformError) {
            $this->dispatchJobToWorkflow($job);
        }

        return redirect()->route('admin.video-studio.experimental', ['fresh' => 1])
            ->with('success', $buildNow
                ? (($sourceError || $platformError) ? 'سفارش ثبت شد اما پیش از ساخت ناموفق علامت خورد؛ تنظیمات را اصلاح و ساخت مجدد را بزنید.' : ($job->status === 'processing' ? 'ساخت ویدیو شروع شد و در صف پردازش قرار گرفت.' : 'سفارش در صف ساخت ثبت شد.'))
                : 'تنظیمات در لیست ساخت ذخیره شد و هنوز ویدیو ساخته نمی‌شود.');
    }

    /**
     * ویرایش کامل تنظیمات یک سفارش؛ ذخیرهٔ ساده خروجی قبلی را دست‌نخورده نگه می‌دارد
     * و «ذخیره و ساخت مجدد» همان سفارش را با تنظیمات تازه به ورکفلو می‌فرستد.
     */
    public function updateJobSettings(Request $request, VideoStudioJob $job)
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'source_mode' => ['required', Rule::in(['auto', 'upload', 'music', 'video'])],
            'source_url' => ['nullable', 'url', 'max:2048'],
            'source_file' => ['nullable', 'file', 'mimes:mp3,wav,m4a,ogg,mp4,mov,webm', 'max:102400'],
            'source_library_id' => ['nullable', 'integer', 'exists:video_studio_sources,id'],
            'selected_images_text' => ['nullable', 'string', 'max:20000'],
            'aspect_ratio' => ['required', Rule::in(['9:16', '1:1', '4:5', '16:9'])],
            'instagram_enabled' => ['nullable', 'boolean'],
            'telegram_enabled' => ['nullable', 'boolean'],
            'youtube_enabled' => ['nullable', 'boolean'],
            'aparat_enabled' => ['nullable', 'boolean'],
            'linkedin_enabled' => ['nullable', 'boolean'],
            'telegram_send_video' => ['nullable', 'boolean'],
            'telegram_send_images' => ['nullable', 'boolean'],
            'instagram_send_video' => ['nullable', 'boolean'],
            'instagram_send_images' => ['nullable', 'boolean'],
            'youtube_send_video' => ['nullable', 'boolean'],
            'youtube_send_images' => ['nullable', 'boolean'],
            'aparat_send_video' => ['nullable', 'boolean'],
            'aparat_send_images' => ['nullable', 'boolean'],
            'linkedin_send_video' => ['nullable', 'boolean'],
            'linkedin_send_images' => ['nullable', 'boolean'],
            'cta_enabled' => ['nullable', 'boolean'],
            'cta_text' => ['nullable', 'string', 'max:1000'],
            'cta_background' => ['nullable', 'string', 'max:60', function (string $attribute, mixed $value, \Closure $fail): void {
                if (! $this->isKnownHookColor((string) $value, 'background')) {
                    $fail('رنگ پس‌زمینه CTA معتبر نیست.');
                }
            }],
            'cta_text_color' => ['nullable', 'string', 'max:60', function (string $attribute, mixed $value, \Closure $fail): void {
                if (! $this->isKnownHookColor((string) $value, 'text')) {
                    $fail('رنگ متن CTA معتبر نیست.');
                }
            }],
            'cta_font_size' => ['nullable', 'numeric', 'between:20,72'],
            'cta_font_weight' => ['nullable', 'integer', 'between:1,5'],
            'cta_scale' => ['nullable', 'numeric', 'between:0.7,1.5'],
            'cta_vertical_offset' => ['nullable', 'numeric', 'between:-45,45'],
            'cta_guidelines' => ['nullable', 'string', 'max:5000'],
            'cta_duration' => ['nullable', 'numeric', 'between:0.1,5'],
            'cta_duration_mode' => ['nullable', Rule::in(['manual', 'auto'])],
            'hook_background' => ['nullable', 'string', 'max:60', function (string $attribute, mixed $value, \Closure $fail): void {
                if (! $this->isKnownHookColor((string) $value, 'background')) {
                    $fail('رنگ پس‌زمینه هوک معتبر نیست.');
                }
            }],
            'hook_text_color' => ['nullable', 'string', 'max:60', function (string $attribute, mixed $value, \Closure $fail): void {
                if (! $this->isKnownHookColor((string) $value, 'text')) {
                    $fail('رنگ متن هوک معتبر نیست.');
                }
            }],
            'hook_font_size' => ['nullable', 'numeric', 'between:20,72'],
            'hook_font_weight' => ['nullable', 'integer', 'between:1,5'],
            'hook_scale' => ['nullable', 'numeric', 'between:0.7,1.5'],
            'hook_vertical_offset' => ['nullable', 'numeric', 'between:-45,45'],
            'hook_duration' => ['nullable', 'numeric', 'between:0.1,5'],
            'hook_duration_mode' => ['nullable', Rule::in(['manual', 'auto'])],
            'hook_position' => ['nullable', Rule::in(['top', 'center', 'bottom', 'side'])],
            'transition' => ['nullable', Rule::in(['cut', 'fade', 'blur', 'slide'])],
            'transition_duration' => ['nullable', 'numeric', 'between:0.2,1.5'],
            'text_command' => ['nullable', 'string', 'max:5000'],
            'font_family' => ['required', Schema::hasTable('video_studio_fonts')
                ? Rule::exists('video_studio_fonts', 'slug')->where('is_active', true)
                : Rule::in(['B_Yekan'])],
            'hook_text' => ['nullable', 'string', 'max:1000'],
            'caption_text' => ['nullable', 'string', 'max:5000'],
            'keyword' => ['nullable', 'string', 'max:80'],
            'dm_template' => ['nullable', 'string', 'max:5000'],
            'telegram_caption_text' => ['nullable', 'string', 'max:5000'],
            'youtube_caption_text' => ['nullable', 'string', 'max:5000'],
            'aparat_caption_text' => ['nullable', 'string', 'max:5000'],
            'linkedin_caption_text' => ['nullable', 'string', 'max:5000'],
            'instagram_prompt' => ['nullable', 'string', 'max:30000'],
            'telegram_prompt' => ['nullable', 'string', 'max:30000'],
            'youtube_prompt' => ['nullable', 'string', 'max:30000'],
            'aparat_prompt' => ['nullable', 'string', 'max:30000'],
            'linkedin_prompt' => ['nullable', 'string', 'max:30000'],
            'telegram_buttons_enabled' => ['nullable', 'boolean'],
            'telegram_button_label' => ['nullable', 'array', 'max:8'],
            'telegram_button_label.*' => ['nullable', 'string', 'max:80'],
            'telegram_button_url' => ['nullable', 'array', 'max:8'],
            'telegram_button_url.*' => ['nullable', 'url', 'max:2048'],
            'telegram_button_style' => ['nullable', 'array', 'max:8'],
            'telegram_button_style.*' => ['nullable', Rule::in(['primary', 'success', 'danger'])],
            'telegram_button_width' => ['nullable', 'array', 'max:8'],
            'telegram_button_width.*' => ['nullable', Rule::in(['full', 'half'])],
            'build_now' => ['nullable', 'boolean'],
            'editing_rules' => ['nullable', 'json'],
        ]);

        if ($request->hasFile('source_file')) {
            $data['source_url'] = asset('storage/' . ltrim($request->file('source_file')->store('video-studio/sources', 'public'), '/'));
        }
        if (!empty($data['source_library_id'])) {
            $librarySource = VideoStudioSource::query()->where('is_active', true)->findOrFail((int) $data['source_library_id']);
            $data['source_mode'] = $librarySource->type;
            $data['source_url'] = $librarySource->source_url;
        }
        if (($data['source_mode'] ?? null) === 'auto' && empty($data['source_library_id'])) {
            $data['source_url'] = null;
        }
        if (($data['source_mode'] ?? null) === 'auto' && blank($data['source_url'])) {
            $librarySource = VideoStudioSource::query()
                ->where('is_active', true)
                ->whereNotNull('source_url')
                ->where('source_url', '<>', '')
                ->orderBy('used_count')
                ->orderBy('id')
                ->first();
            if ($librarySource) {
                $data['source_library_id'] = $librarySource->id;
                $data['source_mode'] = $librarySource->type;
                $data['source_url'] = $librarySource->source_url;
            }
        }
        $sourceError = blank($data['source_url'])
            ? 'منبع صوت یا ویدیو معتبر انتخاب نشده است.'
            : null;
        $selectedImages = collect(preg_split('/\R/u', (string) ($data['selected_images_text'] ?? '')))
            ->map(fn ($url): string => trim((string) $url))
            ->filter()
            ->unique()
            ->take(10)
            ->values()
            ->all();
        $buttons = $this->normalizeTelegramButtons($request);
        $ctaBackground = $this->resolveHookColor((string) ($data['cta_background'] ?? data_get($job->payload, 'cta_background', 'primary')), 'background');
        $ctaTextColor = $this->resolveHookColor((string) ($data['cta_text_color'] ?? data_get($job->payload, 'cta_text_color', 'light')), 'text');
        $data['cta_background'] = $ctaBackground['key'];
        $data['cta_background_color'] = $ctaBackground['render_value'];
        $data['cta_text_color'] = $ctaTextColor['key'];
        $data['cta_text_color_value'] = $ctaTextColor['render_value'];
        $hookBackground = $this->resolveHookColor((string) ($data['hook_background'] ?? data_get($job->payload, 'hook_background', 'primary')), 'background');
        $hookTextColor = $this->resolveHookColor((string) ($data['hook_text_color'] ?? data_get($job->payload, 'hook_text_color', 'light')), 'text');
        $data['hook_background'] = $hookBackground['key'];
        $data['hook_background_color'] = $hookBackground['render_value'];
        $data['hook_text_color'] = $hookTextColor['key'];
        $data['hook_text_color_value'] = $hookTextColor['render_value'];
        $payload = is_array($job->payload) ? $job->payload : [];
        $editingRules = $this->normalizeVideoEditingRules($request->input('editing_rules') ?: data_get($payload, 'editing_rules'),
            (string) ($data['aspect_ratio'] ?? $job->aspect_ratio ?? '9:16'),
            (string) ($data['transition'] ?? data_get($payload, 'transition', 'cut')),
            (float) ($data['transition_duration'] ?? data_get($payload, 'transition_duration', 0.5)),
        );
        $renderInstructions = $this->videoEditingInstructions();
        if (Schema::hasTable('video_studio_social_prompts')) {
            $savedPrompts = VideoStudioSocialPrompt::query()
                ->where('admin_id', auth('admin')->id())
                ->pluck('prompt', 'platform');
        } else {
            $savedPrompts = collect();
        }
        foreach (['instagram', 'telegram', 'youtube', 'aparat', 'linkedin'] as $platform) {
            $key = $platform . '_prompt';
            if (blank($data[$key] ?? null) && filled($savedPrompts[$platform] ?? null)) {
                $data[$key] = (string) $savedPrompts[$platform];
            }
        }
        $buildNow = $request->boolean('build_now');
        $instagramEnabled = $request->has('instagram_enabled') ? $request->boolean('instagram_enabled') : (bool) data_get($payload, 'instagram_enabled', true);
        $telegramEnabled = $request->has('telegram_enabled') ? $request->boolean('telegram_enabled') : (bool) data_get($payload, 'telegram_enabled', true);
        $youtubeEnabled = $request->has('youtube_enabled') ? $request->boolean('youtube_enabled') : (bool) data_get($payload, 'youtube_enabled', false);
        $aparatEnabled = $request->has('aparat_enabled') ? $request->boolean('aparat_enabled') : (bool) data_get($payload, 'aparat_enabled', false);
        $linkedinEnabled = $request->has('linkedin_enabled') ? $request->boolean('linkedin_enabled') : (bool) data_get($payload, 'linkedin_enabled', false);
        $platformError = (!$instagramEnabled && !$telegramEnabled && !$youtubeEnabled && !$aparatEnabled && !$linkedinEnabled)
            ? 'حداقل یکی از خروجی‌های شبکه‌های اجتماعی باید روشن باشد.'
            : null;
        $payload = array_merge($payload, [
            'font_family' => (string) $data['font_family'],
            'hook_background' => (string) $data['hook_background'],
            'hook_background_color' => (string) $data['hook_background_color'],
            'hook_text_color' => (string) $data['hook_text_color'],
            'hook_text_color_value' => (string) $data['hook_text_color_value'],
            'hook_font_size' => (float) ($data['hook_font_size'] ?? data_get($payload, 'hook_font_size', 36)),
            'hook_font_weight' => (int) ($data['hook_font_weight'] ?? data_get($payload, 'hook_font_weight', 3)),
            'hook_scale' => (float) ($data['hook_scale'] ?? data_get($payload, 'hook_scale', 1)),
            'hook_vertical_offset' => (float) ($data['hook_vertical_offset'] ?? data_get($payload, 'hook_vertical_offset', 0)),
            'hook_duration' => (float) ($data['hook_duration'] ?? data_get($payload, 'hook_duration', 2)),
            'hook_duration_mode' => (string) ($data['hook_duration_mode'] ?? data_get($payload, 'hook_duration_mode', 'manual')),
            'hook_position' => (string) ($data['hook_position'] ?? data_get($payload, 'hook_position', 'center')),
            'instagram_prompt' => (string) ($data['instagram_prompt'] ?? ''),
            'telegram_prompt' => (string) ($data['telegram_prompt'] ?? ''),
            'youtube_prompt' => (string) ($data['youtube_prompt'] ?? ''),
            'aparat_prompt' => (string) ($data['aparat_prompt'] ?? ''),
            'linkedin_prompt' => (string) ($data['linkedin_prompt'] ?? ''),
            'telegram_caption_text' => (string) ($data['telegram_caption_text'] ?? ''),
            'youtube_caption_text' => (string) ($data['youtube_caption_text'] ?? ''),
            'aparat_caption_text' => (string) ($data['aparat_caption_text'] ?? ''),
            'linkedin_caption_text' => (string) ($data['linkedin_caption_text'] ?? ''),
            'telegram_buttons' => $buttons,
            'instagram_enabled' => $instagramEnabled,
            'telegram_enabled' => $telegramEnabled,
            'youtube_enabled' => $youtubeEnabled,
            'aparat_enabled' => $aparatEnabled,
            'linkedin_enabled' => $linkedinEnabled,
            'telegram_send_video' => $request->has('telegram_send_video') ? $request->boolean('telegram_send_video') : (bool) data_get($payload, 'telegram_send_video', true),
            'telegram_send_images' => $request->has('telegram_send_images') ? $request->boolean('telegram_send_images') : (bool) data_get($payload, 'telegram_send_images', false),
            'instagram_send_video' => $request->has('instagram_send_video') ? $request->boolean('instagram_send_video') : (bool) data_get($payload, 'instagram_send_video', true),
            'instagram_send_images' => $request->has('instagram_send_images') ? $request->boolean('instagram_send_images') : (bool) data_get($payload, 'instagram_send_images', false),
            'youtube_send_video' => $request->has('youtube_send_video') ? $request->boolean('youtube_send_video') : (bool) data_get($payload, 'youtube_send_video', false),
            'youtube_send_images' => $request->has('youtube_send_images') ? $request->boolean('youtube_send_images') : (bool) data_get($payload, 'youtube_send_images', false),
            'aparat_send_video' => $request->has('aparat_send_video') ? $request->boolean('aparat_send_video') : (bool) data_get($payload, 'aparat_send_video', false),
            'aparat_send_images' => $request->has('aparat_send_images') ? $request->boolean('aparat_send_images') : (bool) data_get($payload, 'aparat_send_images', false),
            'linkedin_send_video' => $request->has('linkedin_send_video') ? $request->boolean('linkedin_send_video') : (bool) data_get($payload, 'linkedin_send_video', false),
            'linkedin_send_images' => $request->has('linkedin_send_images') ? $request->boolean('linkedin_send_images') : (bool) data_get($payload, 'linkedin_send_images', false),
            'cta_enabled' => $request->has('cta_enabled') ? $request->boolean('cta_enabled') : (bool) data_get($payload, 'cta_enabled', true),
            'cta_text' => (string) ($data['cta_text'] ?? data_get($payload, 'cta_text', '')),
            'cta_background' => (string) ($data['cta_background'] ?? data_get($payload, 'cta_background', 'primary')),
            'cta_background_color' => (string) ($data['cta_background_color'] ?? data_get($payload, 'cta_background_color', '#16594F')),
            'cta_text_color' => (string) ($data['cta_text_color'] ?? data_get($payload, 'cta_text_color', 'light')),
            'cta_text_color_value' => (string) ($data['cta_text_color_value'] ?? data_get($payload, 'cta_text_color_value', '#FFFFFF')),
            'cta_font_size' => (float) ($data['cta_font_size'] ?? data_get($payload, 'cta_font_size', 36)),
            'cta_font_weight' => (int) ($data['cta_font_weight'] ?? data_get($payload, 'cta_font_weight', 3)),
            'cta_scale' => (float) ($data['cta_scale'] ?? data_get($payload, 'cta_scale', 1)),
            'cta_vertical_offset' => (float) ($data['cta_vertical_offset'] ?? data_get($payload, 'cta_vertical_offset', 0)),
            'cta_guidelines' => (string) ($data['cta_guidelines'] ?? data_get($payload, 'cta_guidelines', '')),
            'cta_duration' => (float) ($data['cta_duration'] ?? data_get($payload, 'cta_duration', 2)),
            'cta_duration_mode' => (string) ($data['cta_duration_mode'] ?? data_get($payload, 'cta_duration_mode', 'manual')),
            'transition' => (string) ($data['transition'] ?? data_get($payload, 'transition', 'cut')),
            'transition_duration' => (float) ($data['transition_duration'] ?? data_get($payload, 'transition_duration', 0.5)),
            'editing_rules' => $editingRules,
            'render_instructions' => $renderInstructions,
            'text_command' => trim((string) ($data['text_command'] ?? data_get($payload, 'text_command', ''))),
            'render_config' => [
                'font_family' => (string) $data['font_family'],
                'hook_background' => (string) $data['hook_background'],
                'hook_background_color' => (string) $data['hook_background_color'],
                'hook_text_color' => (string) $data['hook_text_color'],
                'hook_text_color_value' => (string) $data['hook_text_color_value'],
                'hook_font_size' => (float) ($data['hook_font_size'] ?? data_get($payload, 'hook_font_size', 36)),
                'hook_font_weight' => (int) ($data['hook_font_weight'] ?? data_get($payload, 'hook_font_weight', 3)),
                'hook_scale' => (float) ($data['hook_scale'] ?? data_get($payload, 'hook_scale', 1)),
                'hook_vertical_offset' => (float) ($data['hook_vertical_offset'] ?? data_get($payload, 'hook_vertical_offset', 0)),
                'hook_duration' => (float) ($data['hook_duration'] ?? data_get($payload, 'hook_duration', 2)),
                'hook_duration_mode' => (string) ($data['hook_duration_mode'] ?? data_get($payload, 'hook_duration_mode', 'manual')),
                'hook_position' => (string) ($data['hook_position'] ?? data_get($payload, 'hook_position', 'center')),
                'cta_position' => (string) data_get($payload, 'cta_position', 'bottom'),
                'cta_background' => (string) ($data['cta_background'] ?? data_get($payload, 'cta_background', 'primary')),
                'cta_background_color' => (string) ($data['cta_background_color'] ?? data_get($payload, 'cta_background_color', '#16594F')),
                'cta_text_color' => (string) ($data['cta_text_color'] ?? data_get($payload, 'cta_text_color', 'light')),
                'cta_text_color_value' => (string) ($data['cta_text_color_value'] ?? data_get($payload, 'cta_text_color_value', '#FFFFFF')),
                'cta_font_size' => (float) ($data['cta_font_size'] ?? data_get($payload, 'cta_font_size', 36)),
                'cta_font_weight' => (int) ($data['cta_font_weight'] ?? data_get($payload, 'cta_font_weight', 3)),
                'cta_scale' => (float) ($data['cta_scale'] ?? data_get($payload, 'cta_scale', 1)),
                'cta_vertical_offset' => (float) ($data['cta_vertical_offset'] ?? data_get($payload, 'cta_vertical_offset', 0)),
                'cta_guidelines' => (string) ($data['cta_guidelines'] ?? data_get($payload, 'cta_guidelines', '')),
                'cta_duration' => (float) ($data['cta_duration'] ?? data_get($payload, 'cta_duration', 2)),
                'cta_duration_mode' => (string) ($data['cta_duration_mode'] ?? data_get($payload, 'cta_duration_mode', 'manual')),
                'cta_enabled' => $request->has('cta_enabled') ? $request->boolean('cta_enabled') : (bool) data_get($payload, 'cta_enabled', true),
                'cta_text' => (string) ($data['cta_text'] ?? data_get($payload, 'cta_text', '')),
                'transition' => (string) ($data['transition'] ?? data_get($payload, 'transition', 'cut')),
                'transition_duration' => (float) ($data['transition_duration'] ?? data_get($payload, 'transition_duration', 0.5)),
                'editing_rules' => $editingRules,
                'render_instructions' => $renderInstructions,
            ],
            'estimated_cost' => $this->estimateVideoCost((int) $data['product_id'], (string) $data['aspect_ratio'], (string) ($data['source_mode'] ?? 'auto')),
            'source_library_id' => (int) ($data['source_library_id'] ?? 0) ?: null,
            'source_fingerprint' => hash('sha256', json_encode([
                'product_id' => (int) $data['product_id'],
                'source_mode' => (string) $data['source_mode'],
                'source_url' => (string) ($data['source_url'] ?? ''),
                'selected_images' => $selectedImages,
                'aspect_ratio' => (string) $data['aspect_ratio'],
                'cta_duration' => (float) ($data['cta_duration'] ?? data_get($payload, 'cta_duration', 2)),
                'cta_duration_mode' => (string) ($data['cta_duration_mode'] ?? data_get($payload, 'cta_duration_mode', 'manual')),
                'cta_enabled' => $request->has('cta_enabled') ? $request->boolean('cta_enabled') : (bool) data_get($payload, 'cta_enabled', true),
                'cta_text' => (string) ($data['cta_text'] ?? data_get($payload, 'cta_text', '')),
                'cta_background' => (string) ($data['cta_background'] ?? data_get($payload, 'cta_background', 'primary')),
                'cta_text_color' => (string) ($data['cta_text_color'] ?? data_get($payload, 'cta_text_color', 'light')),
                'cta_font_size' => (float) ($data['cta_font_size'] ?? data_get($payload, 'cta_font_size', 36)),
                'cta_font_weight' => (int) ($data['cta_font_weight'] ?? data_get($payload, 'cta_font_weight', 3)),
                'cta_scale' => (float) ($data['cta_scale'] ?? data_get($payload, 'cta_scale', 1)),
                'cta_vertical_offset' => (float) ($data['cta_vertical_offset'] ?? data_get($payload, 'cta_vertical_offset', 0)),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)),
            'build_now' => $buildNow,
        ]);
        unset($data['source_file'], $data['source_library_id'], $data['selected_images_text'], $data['telegram_buttons_enabled'], $data['telegram_button_label'], $data['telegram_button_url'], $data['telegram_button_style'], $data['telegram_button_width'], $data['build_now'], $data['instagram_enabled'], $data['telegram_enabled'], $data['youtube_enabled'], $data['aparat_enabled'], $data['linkedin_enabled'], $data['telegram_send_video'], $data['telegram_send_images'], $data['instagram_send_video'], $data['instagram_send_images'], $data['youtube_send_video'], $data['youtube_send_images'], $data['aparat_send_video'], $data['aparat_send_images'], $data['linkedin_send_video'], $data['linkedin_send_images'], $data['cta_enabled'], $data['cta_text'], $data['cta_background'], $data['cta_background_color'], $data['cta_text_color'], $data['cta_text_color_value'], $data['cta_font_size'], $data['cta_font_weight'], $data['cta_scale'], $data['cta_vertical_offset'], $data['cta_guidelines'], $data['cta_duration'], $data['cta_duration_mode'], $data['transition'], $data['transition_duration'], $data['text_command']);
        $data['selected_images'] = $selectedImages ?: (array) $job->selected_images;
        $data['payload'] = $payload;
        if ($buildNow) {
            $data['status'] = ($sourceError || $platformError) ? 'failed' : 'queued';
            $data['error_message'] = $sourceError ?: $platformError;
            $data['started_at'] = null;
            $data['completed_at'] = null;
            $data['video_url'] = null;
        }
        $job->fill($data)->save();
        if ($buildNow && !$sourceError && !$platformError) {
            $this->dispatchJobToWorkflow($job->fresh());
        }

        return back()->with(($sourceError || $platformError) && $buildNow ? 'warning' : 'success', ($sourceError || $platformError) && $buildNow
            ? 'تنظیمات ذخیره شد اما پیش از ساخت، اعتبارسنجی ناموفق بود.'
            : ($buildNow ? 'تنظیمات ذخیره و ساخت مجدد آغاز شد.' : 'تنظیمات سفارش ذخیره شد.'));
    }

    public function retryJob(VideoStudioJob $job)
    {
        if (!$this->ensureJobSource($job)) {
            $job->update(['status' => 'failed', 'error_message' => 'منبع صوت یا ویدیو برای این سفارش موجود نیست؛ ابتدا یک منبع معتبر انتخاب کنید.']);
            return back()->withErrors(['source_file' => 'منبع این سفارش موجود نیست؛ از ویرایش کامل، فایل یا منبع کتابخانه را انتخاب کنید.']);
        }
        $job->update(['status' => 'queued', 'error_message' => null, 'started_at' => null, 'completed_at' => null]);
        $this->dispatchJobToWorkflow($job);

        return back()->with('success', 'سفارش برای ساخت مجدد به ورکفلو ارسال شد.');
    }

    public function reviseJob(Request $request, VideoStudioJob $job)
    {
        $data = $request->validate([
            'revision_request' => ['required', 'string', 'max:5000'],
        ]);

        $payload = is_array($job->payload) ? $job->payload : [];
        $payload['revision_request'] = trim($data['revision_request']);
        $payload['revision_at'] = now()->toIso8601String();
        $job->update([
            'status' => 'queued',
            'error_message' => null,
            'started_at' => null,
            'completed_at' => null,
            'payload' => $payload,
        ]);
        $this->dispatchJobToWorkflow($job->fresh());

        return back()->with('success', 'اصلاحیه به هوش مصنوعی ارسال شد و ساخت مجدد آغاز می‌شود.');
    }

    public function bulkAction(Request $request)
    {
        $data = $request->validate([
            'action' => ['required', Rule::in(['delete', 'retry'])],
            'job_ids' => ['required', 'array', 'min:1', 'max:50'],
            'job_ids.*' => ['integer', 'exists:video_studio_jobs,id'],
        ]);

        $jobs = VideoStudioJob::query()->whereIn('id', $data['job_ids'])->get();
        if ($data['action'] === 'delete') {
            $jobs->each->delete();
            return back()->with('success', 'سفارش‌های انتخاب‌شده از صف حذف شدند.');
        }

        $jobs->each(function (VideoStudioJob $job): void {
            if (!$this->ensureJobSource($job)) {
                $job->update(['status' => 'failed', 'error_message' => 'منبع صوت یا ویدیو برای این سفارش موجود نیست؛ ابتدا یک منبع معتبر انتخاب کنید.']);
                return;
            }
            $job->update(['status' => 'queued', 'error_message' => null, 'started_at' => null, 'completed_at' => null]);
            $this->dispatchJobToWorkflow($job->fresh());
        });

        return back()->with('success', 'سفارش‌های انتخاب‌شده برای ساخت مجدد ارسال شدند.');
    }

    /**
     * فایل هر وزن واقعی فونت‌های منتخب ویدیو. برای فونت‌های افزوده‌شده توسط مدیر، همان فایل
     * ثبت‌شده به‌عنوان وزن پایه استفاده می‌شود تا انتخاب فونت هرگز از کار نیفتد.
     */
    private function videoStudioFontWeightAssets(iterable $fonts): array
    {
        $assets = $this->videoStudioFontWeightAssetCatalog();

        foreach ($fonts as $font) {
            $slug = (string) ($font->slug ?? '');
            if ($slug !== '' && !isset($assets[$slug]) && filled($font->file_path ?? null)) {
                $assets[$slug] = [400 => (string) $font->file_path];
            }
        }

        return $assets;
    }

    private function videoStudioFontWeightAssetCatalog(): array
    {
        return [
            'B_Yekan' => [400 => 'fonts/B_Yekan.ttf'],
            'Abar' => [300 => 'fonts/video/AbarMid-Regular.ttf', 400 => 'fonts/video/AbarMid-Regular.ttf', 500 => 'fonts/video/AbarMid-SemiBold.ttf', 700 => 'fonts/video/AbarMid-Bold.ttf', 900 => 'fonts/video/AbarMid-Black.ttf'],
            'IRANSansX' => [300 => 'fonts/IRANSansXFaNum-LightD4.ttf', 400 => 'fonts/IRANSansXFaNum-RegularD4.ttf', 500 => 'fonts/IRANSansXFaNum-MediumD4.ttf', 700 => 'fonts/IRANSansXFaNum-BoldD4.ttf', 900 => 'fonts/IRANSansXFaNum-BlackD4.ttf'],
            'Peyda' => [300 => 'fonts/video/peyda-light.ttf', 400 => 'fonts/video/Peyda-Medium.ttf', 500 => 'fonts/video/Peyda-Medium.ttf', 700 => 'fonts/video/Peyda-SemiBold.ttf', 900 => 'fonts/video/Peyda-Black.ttf'],
            'Doran' => [300 => 'fonts/video/Doran-Light.ttf', 400 => 'fonts/video/Doran-Regular.ttf', 500 => 'fonts/video/Doran-Medium.ttf', 700 => 'fonts/video/Doran-Bold.ttf', 900 => 'fonts/video/Doran-ExtraBold.ttf'],
            'Modam' => [300 => 'fonts/video/Modam-ExtraLight.ttf', 400 => 'fonts/video/Modam-Medium.ttf', 500 => 'fonts/video/Modam-Medium.ttf', 700 => 'fonts/video/Modam-SemiBold.ttf', 900 => 'fonts/video/Modam-Black.ttf'],
            'YekanBakh' => [300 => 'fonts/video/YekanBakh-Light.ttf', 400 => 'fonts/YekanBakh-Regular.ttf', 500 => 'fonts/video/YekanBakh-Medium.ttf', 700 => 'fonts/video/YekanBakh-Bold.ttf', 900 => 'fonts/video/YekanBakh-Heavy.ttf'],
        ];
    }

    private function hookFontWeightValue(int $weight): int
    {
        return [1 => 300, 2 => 400, 3 => 500, 4 => 700, 5 => 900][$weight] ?? 500;
    }

    private function videoStudioFontPathForWeight(string $family, int $weight, ?string $fallbackPath = null): ?string
    {
        $assets = $this->videoStudioFontWeightAssetCatalog()[$family] ?? [];
        if ($assets === []) {
            return $fallbackPath;
        }

        $availableWeights = array_keys($assets);
        usort($availableWeights, static fn (int $left, int $right): int => abs($left - $weight) <=> abs($right - $weight));

        return $assets[$availableWeights[0]] ?? $fallbackPath;
    }

    /**
     * رنگ‌های پایه از توکن‌های موجود پنل می‌آیند؛ رنگ سفارشی فقط برای همان مدیر نگه‌داری می‌شود.
     * مقدار render_value به ورکفلو داده می‌شود تا خروجی با پیش‌نمایش هم‌خوان بماند.
     */
    private function hookColorOptions(string $target): array
    {
        $defaults = $this->defaultHookColors($target);
        if (! Schema::hasTable('video_studio_hook_colors') || ! auth('admin')->check()) {
            return $defaults;
        }

        if (Schema::hasTable('video_studio_hook_color_preferences')) {
            $hiddenKeys = VideoStudioHookColorPreference::query()
                ->where('admin_id', auth('admin')->id())
                ->where('target', $target)
                ->where('is_hidden', true)
                ->pluck('color_key')
                ->all();
            $defaults = array_values(array_filter($defaults, static fn (array $color): bool => !in_array($color['key'], $hiddenKeys, true)));
        }

        $custom = VideoStudioHookColor::query()
            ->where('admin_id', auth('admin')->id())
            ->where('target', $target)
            ->latest('id')
            ->get()
            ->map(fn (VideoStudioHookColor $color): array => $this->hookColorPayload($color))
            ->all();

        return array_merge($defaults, $custom);
    }

    private function defaultHookColors(string $target): array
    {
        $colors = [
            'background' => [
                ['key' => 'primary', 'name' => 'سبز وطن', 'css_value' => 'var(--primary)', 'render_value' => '#16594F', 'is_custom' => false],
                ['key' => 'dark', 'name' => 'مشکی', 'css_value' => 'var(--text-h)', 'render_value' => '#000000', 'is_custom' => false],
                ['key' => 'light', 'name' => 'سفید', 'css_value' => 'var(--card-bg)', 'render_value' => '#FFFFFF', 'is_custom' => false],
                ['key' => 'neutral', 'name' => 'خاکستری', 'css_value' => 'var(--text-soft)', 'render_value' => '#686E6B', 'is_custom' => false],
            ],
            'text' => [
                ['key' => 'dark', 'name' => 'مشکی', 'css_value' => 'var(--text-h)', 'render_value' => '#000000', 'is_custom' => false],
                ['key' => 'light', 'name' => 'سفید', 'css_value' => 'var(--card-bg)', 'render_value' => '#FFFFFF', 'is_custom' => false],
                ['key' => 'primary', 'name' => 'سبز وطن', 'css_value' => 'var(--primary)', 'render_value' => '#16594F', 'is_custom' => false],
                ['key' => 'neutral', 'name' => 'خاکستری', 'css_value' => 'var(--text-soft)', 'render_value' => '#686E6B', 'is_custom' => false],
            ],
        ];

        return $colors[$target] ?? [];
    }

    private function hookColorPayload(VideoStudioHookColor $color): array
    {
        return [
            'key' => 'custom-' . $color->id,
            'name' => $color->name,
            'css_value' => $color->color_value,
            'render_value' => $color->color_value,
            'is_custom' => true,
            'id' => $color->id,
        ];
    }

    private function resolveHookColor(string $key, string $target): array
    {
        foreach ($this->defaultHookColors($target) as $color) {
            if ($color['key'] === $key) {
                return $color;
            }
        }
        if (preg_match('/^custom-(\d+)$/', $key, $matches) && Schema::hasTable('video_studio_hook_colors')) {
            $color = VideoStudioHookColor::query()
                ->whereKey((int) $matches[1])
                ->where('admin_id', auth('admin')->id())
                ->where('target', $target)
                ->first();
            if ($color) {
                return $this->hookColorPayload($color);
            }
        }

        return $this->defaultHookColors($target)[0];
    }

    private function isKnownHookColor(string $key, string $target): bool
    {
        if ($key === '') {
            return true;
        }

        return $this->resolveHookColor($key, $target)['key'] === $key;
    }

    private function normalizeTelegramButtons(Request $request): array
    {
        if (!$request->boolean('telegram_buttons_enabled')) {
            return [];
        }

        $labels = $request->input('telegram_button_label', []);
        $urls = $request->input('telegram_button_url', []);
        $styles = $request->input('telegram_button_style', []);
        $widths = $request->input('telegram_button_width', []);
        $buttons = [];
        foreach ((array) $labels as $index => $label) {
            $label = trim((string) $label);
            $url = trim((string) ($urls[$index] ?? ''));
            if ($label === '' || $url === '') {
                continue;
            }
            $buttons[] = [
                'label' => $label,
                'url' => $url,
                'style' => in_array(($styles[$index] ?? 'primary'), ['primary', 'success', 'danger'], true)
                    ? (string) $styles[$index]
                    : 'primary',
                'width' => in_array(($widths[$index] ?? 'full'), ['full', 'half'], true)
                    ? (string) $widths[$index]
                    : 'full',
            ];
        }

        return array_slice($buttons, 0, 8);
    }

    /**
     * برآورد سبک و بدون فراخوانی زندهٔ سرویس‌دهنده؛ نرخ از جدول نرخ ارز موجود خوانده می‌شود.
     */
    private function estimateVideoCost(int $productId, string $aspectRatio, string $sourceMode = 'auto'): array
    {
        if (! Schema::hasTable('finance_exchange_rates') || ! Schema::hasColumn('finance_exchange_rates', 'rate_to_toman')) {
            return [];
        }

        // این سازنده ویدیو از فایل موجود برای صدا و از تصاویر محصول برای پلان‌ها
        // استفاده می‌کند؛ در این مسیر مدل تولید ویدیو فراخوانی نمی‌شود. قبلاً
        // قیمت مدل اصلی محصول (مثلاً یک مدل ویدیویی گران) به‌اشتباه به‌عنوان
        // هزینهٔ این تدوین نمایش داده می‌شد و عددی مثل ۳۳ هزار تومان می‌ساخت.
        if (in_array($sourceMode, ['auto', 'music', 'video', 'upload'], true)) {
            return [
                'usd' => 0,
                'toman' => 0,
                'rate_toman' => (float) app(\App\Services\Finance\FinanceExchangeRateSnapshotService::class)
                    ->rateToman('USD'),
                'source' => 'تدوین قطعی با منبع موجود؛ بدون هزینهٔ مدل تولید ویدیو',
            ];
        }

        $product = Product::query()->find($productId);
        $model = $product && filled($product->primary_model)
            ? AiModel::query()->where('openrouter_model_id', $product->primary_model)->first()
            : null;
        if (! $model) {
            return [];
        }

        $unitUsd = app(StudioCostService::class)->modelUnitPrice($model, 'video', '', null, $aspectRatio);
        $rateToman = (float) app(\App\Services\Finance\FinanceExchangeRateSnapshotService::class)
            ->rateToman('USD');
        if (! is_numeric($unitUsd) || (float) $unitUsd <= 0 || $rateToman <= 0) {
            return [];
        }

        return [
            'usd' => round((float) $unitUsd, 6),
            'toman' => round((float) $unitUsd * $rateToman, 2),
            'rate_toman' => round($rateToman, 2),
            'source' => 'قیمت مدل و نرخ ارز ثبت‌شده',
        ];
    }

    /**
     * قوانین قطعی تدوین را از لایهٔ هوش مصنوعی جدا نگه می‌دارد تا اجرای آن‌ها
     * توکن اضافه مصرف نکند و هر سفارش، مستقل از نسخهٔ قدیمی، تنظیمات کامل داشته باشد.
     */
    private function videoEditingRules(string $aspectRatio, string $transition, float $transitionDuration): array
    {
        return [
            'enabled' => true,
            'target_aspect_ratio' => $aspectRatio ?: '9:16',
            'fit_mode' => 'cover',
            'object_fit' => 'cover',
            'crop_mode' => 'subject_center',
            'crop_anchor' => 'center',
            'fill_frame' => true,
            'allow_letterbox' => false,
            'no_letterbox' => true,
            'preserve_subject' => true,
            'keep_subject_centered' => true,
            'safe_area' => [
                'top' => 0.08,
                'right' => 0.08,
                'bottom' => 0.10,
                'left' => 0.08,
            ],
            'hook_first' => true,
            'image_order' => 'selected_order',
            'cta_last' => true,
            'transition' => $transition ?: 'cut',
            'transition_duration' => max(0.2, min(1.5, $transitionDuration ?: 0.5)),
            'audio_sync_mode' => 'beat_if_available',
            'audio_sync_fallback' => 'equal_segments',
            'audio_sync' => [
                'enabled' => true,
                'mode' => 'beat_if_available',
                'fallback' => 'equal_segments',
            ],
            'render_with_deterministic_rules' => true,
            'llm_for_rendering' => false,
        ];
    }

    private function normalizeVideoEditingRules(mixed $input, string $aspectRatio, string $transition, float $transitionDuration): array
    {
        $rules = $this->videoEditingRules($aspectRatio, $transition, $transitionDuration);
        if (is_string($input)) {
            $decoded = json_decode($input, true);
            $input = is_array($decoded) ? $decoded : [];
        }
        if (! is_array($input)) {
            return $rules;
        }

        $fitModes = ['cover', 'contain'];
        $cropModes = ['subject_center', 'center'];
        $transitions = ['cut', 'fade', 'blur', 'slide'];
        $audioModes = ['beat_if_available', 'equal_segments', 'disabled'];
        $rules['fit_mode'] = in_array((string) ($input['fit_mode'] ?? ''), $fitModes, true) ? (string) $input['fit_mode'] : $rules['fit_mode'];
        $rules['object_fit'] = $rules['fit_mode'];
        $rules['crop_mode'] = in_array((string) ($input['crop_mode'] ?? ''), $cropModes, true) ? (string) $input['crop_mode'] : $rules['crop_mode'];
        $rules['crop_anchor'] = 'center';
        $rules['fill_frame'] = filter_var($input['fill_frame'] ?? $rules['fill_frame'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? $rules['fill_frame'];
        $rules['allow_letterbox'] = filter_var($input['allow_letterbox'] ?? $rules['allow_letterbox'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? $rules['allow_letterbox'];
        $rules['no_letterbox'] = ! $rules['allow_letterbox'];
        $rules['preserve_subject'] = filter_var($input['preserve_subject'] ?? $rules['preserve_subject'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? $rules['preserve_subject'];
        $rules['keep_subject_centered'] = $rules['preserve_subject'];
        $rules['hook_first'] = filter_var($input['hook_first'] ?? $rules['hook_first'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? $rules['hook_first'];
        $rules['cta_last'] = filter_var($input['cta_last'] ?? $rules['cta_last'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? $rules['cta_last'];
        $rules['transition'] = in_array((string) ($input['transition'] ?? ''), $transitions, true) ? (string) $input['transition'] : $rules['transition'];
        $rules['transition_duration'] = max(0.2, min(1.5, (float) ($input['transition_duration'] ?? $rules['transition_duration'])));
        $rules['audio_sync_mode'] = in_array((string) ($input['audio_sync_mode'] ?? ''), $audioModes, true) ? (string) $input['audio_sync_mode'] : $rules['audio_sync_mode'];
        $rules['audio_sync'] = [
            'enabled' => $rules['audio_sync_mode'] !== 'disabled',
            'mode' => $rules['audio_sync_mode'],
            'fallback' => $rules['audio_sync_mode'] === 'beat_if_available' ? 'equal_segments' : $rules['audio_sync_mode'],
        ];
        $rules['render_with_deterministic_rules'] = true;
        $rules['llm_for_rendering'] = false;
        if (is_array($input['safe_area'] ?? null)) {
            foreach (['top', 'right', 'bottom', 'left'] as $side) {
                if (is_numeric($input['safe_area'][$side] ?? null)) {
                    $rules['safe_area'][$side] = max(0, min(0.2, (float) $input['safe_area'][$side]));
                }
            }
        }
        $rules['target_aspect_ratio'] = $aspectRatio ?: '9:16';

        return $rules;
    }

    private function videoEditingInstructions(): string
    {
        return 'تدوین را با قواعد قطعی انجام بده: خروجی باید تمام قاب هدف را با حالت cover و crop سوژه‌محور پر کند؛ حاشیهٔ خالی، نوار سیاه و letterbox ممنوع است؛ سوژهٔ اصلی تا حد ممکن در کادر امن بماند؛ هوک ابتدا، تصاویر طبق image_sequence و CTA در انتهای ویدیو قرار بگیرند؛ ناحیهٔ امن متن رعایت شود؛ ترنزیشن و زمان‌های ورودی اعمال شوند؛ اگر تشخیص ضرب صدا ممکن بود بر اساس ضرب تقسیم کن و در غیر این صورت زمان پلان‌ها را به‌صورت یکنواخت بین بخش‌ها تقسیم کن. برای اجرای این قواعد از مدل زبانی استفاده نکن.';
    }

    private function productImageUrls(?Product $product): array
    {
        if (!$product) {
            return [];
        }

        return collect(array_merge(
            [$product->cover, $product->thumbnail],
            (array) $product->sample_outputs,
            (array) $product->before_images,
        ))->map(function ($path): ?string {
            $path = trim((string) $path);
            if ($path === '') {
                return null;
            }
            if (Str::startsWith($path, ['http://', 'https://', 'data:'])) {
                return $path;
            }
            return Storage::disk('public')->exists($path)
                ? asset('storage/' . ltrim($path, '/'))
                : null;
        })->filter()->unique()->values()->all();
    }

    private function dispatchJobToWorkflow(VideoStudioJob $job): void
    {
        if (!$this->ensureJobSource($job)) {
            $job->update(['status' => 'failed', 'error_message' => 'منبع صوت یا ویدیو برای این سفارش موجود نیست؛ ابتدا یک منبع معتبر انتخاب کنید.']);
            return;
        }
        $job = $job->fresh();
        $webhook = trim((string) config('services.n8n.video_studio_webhook', env('N8N_VIDEO_STUDIO_WEBHOOK_URL', '')));
        if ($webhook === '') {
            $job->update(['status' => 'failed', 'error_message' => 'اتصال ورکفلو تنظیم نشده است.']);
            return;
        }

        $product = $job->product ?: Product::query()->find($job->product_id);
        $payload = is_array($job->payload) ? $job->payload : [];
        $editingRules = is_array($payload['editing_rules'] ?? null)
            ? $payload['editing_rules']
            : $this->videoEditingRules(
                (string) ($job->aspect_ratio ?: '9:16'),
                (string) ($payload['transition'] ?? 'cut'),
                (float) ($payload['transition_duration'] ?? 0.5),
            );
        $renderInstructions = trim((string) ($payload['render_instructions'] ?? '')) ?: $this->videoEditingInstructions();
        $renderConfig = is_array($payload['render_config'] ?? null) ? $payload['render_config'] : [];
        $renderConfig['editing_rules'] = $editingRules;
        $renderConfig['render_instructions'] = $renderInstructions;
        $autoHook = (bool) ($payload['auto_generate_hook'] ?? false);
        $autoCaption = (bool) ($payload['auto_generate_caption'] ?? false);
        $autoKeyword = (bool) ($payload['auto_generate_keyword'] ?? false);
        $promptProfile = trim((string) ($payload['prompt_profile'] ?? ''));
        $channel = (string) ($payload['channel'] ?? 'instagram');
        $channelPrompt = trim((string) ($payload[$channel . '_prompt'] ?? ''));
        $fontFamily = (string) ($payload['font_family'] ?? 'B_Yekan');
        $font = Schema::hasTable('video_studio_fonts')
            ? VideoStudioFont::query()->where('is_active', true)->where('slug', $fontFamily)->first()
            : null;
        $hookFontWeight = max(1, min(5, (int) ($payload['hook_font_weight'] ?? 3)));
        $hookFontWeightValue = $this->hookFontWeightValue($hookFontWeight);
        $fontFilePath = $this->videoStudioFontPathForWeight($fontFamily, $hookFontWeightValue, $font?->file_path);
        $fontFileUrl = filled($fontFilePath)
            ? (Str::startsWith($fontFilePath, ['http://', 'https://']) ? $fontFilePath : asset(ltrim($fontFilePath, '/')))
            : '';
        if ($channelPrompt !== '') {
            $promptProfile = $channelPrompt;
        }
        $hookGuidelines = trim((string) ($payload['hook_guidelines'] ?? ''));
        $captionGuidelines = trim((string) ($payload['caption_guidelines'] ?? ''));
        if ($promptProfile !== '') {
            $hookGuidelines = trim($promptProfile . "\n\n" . $hookGuidelines);
            $captionGuidelines = trim($promptProfile . "\n\n" . $captionGuidelines);
        }
        // منبع ویدیو/موزیک فقط منبع صداست. تصویرهای خروجی همیشه از تصاویر
        // انتخاب‌شدهٔ محصول می‌آیند تا ورکفلو نتواند به‌اشتباه فریم‌های ویدیوی
        // آرشیو را به‌عنوان پلان تصویری استفاده کند.
        $productImageUrls = $this->productImageUrls($product);
        $selectedImageUrls = collect($job->selected_images ?: $productImageUrls)
            ->map(static fn ($url): string => trim((string) $url))
            ->filter()
            ->unique()
            ->values()
            ->all();
        if ($selectedImageUrls === []) {
            $selectedImageUrls = $productImageUrls;
        }
        $sourceAudioOnly = in_array((string) $job->source_mode, ['music', 'video'], true);
        $renderConfig['visual_source'] = 'product_images';
        $renderConfig['visual_image_urls'] = $selectedImageUrls;
        $renderConfig['source_audio_url'] = (string) $job->source_url;
        $renderConfig['source_audio_only'] = $sourceAudioOnly;
        $renderConfig['source_video_as_visual'] = false;
        // قرارداد صریح هر شبکه برای ورکفلو؛ نودهای ارسال نباید کپشن یا دکمهٔ
        // تلگرام را به‌صورت پیش‌فرض برای شبکهٔ دیگری مصرف کنند.
        $platformPayloads = [];
        foreach (['instagram', 'telegram', 'youtube', 'aparat', 'linkedin'] as $platform) {
            $caption = (string) ($payload[$platform . '_caption_text']
                ?? ($platform === 'instagram' ? ($job->caption_text ?? '') : ''));
            if (trim($caption) === '') {
                $caption = implode("\n\n", $this->defaultSocialCaptions($product, $platform));
            }
            $buttons = $platform === 'telegram' && is_array($payload['telegram_buttons'] ?? null)
                ? array_values($payload['telegram_buttons'])
                : [];
            $platformPayloads[$platform] = [
                'delivery_id' => "video-studio:{$job->id}:{$platform}",
                'enabled' => (bool) ($payload[$platform . '_enabled'] ?? false),
                'caption' => $caption,
                'prompt' => (string) ($payload[$platform . '_prompt'] ?? ''),
                'send_video' => (bool) ($payload[$platform . '_send_video'] ?? false),
                'send_images' => (bool) ($payload[$platform . '_send_images'] ?? false),
                'image_urls' => $selectedImageUrls,
                'buttons' => $buttons,
                'inline_keyboard' => $platform === 'telegram'
                    ? array_map(static fn (array $button): array => [[
                        'text' => (string) ($button['label'] ?? ''),
                        'url' => (string) ($button['url'] ?? ''),
                        'style' => (string) ($button['style'] ?? 'primary'),
                        'color' => match ((string) ($button['style'] ?? 'primary')) {
                            'success' => 'success',
                            'danger' => 'danger',
                            default => 'primary',
                        },
                        'width' => (string) ($button['width'] ?? 'full'),
                    ]], $buttons)
                    : [],
            ];
        }
        if (Schema::hasTable('video_hook_inspirations')) {
            $library = VideoHookInspiration::query()
                ->where('is_active', true)
                ->latest()
                ->limit(12)
                ->get(['title', 'hook_text', 'tags'])
                ->map(fn (VideoHookInspiration $item): string => trim(implode(' | ', array_filter([
                    (string) $item->title,
                    (string) $item->hook_text,
                    is_array($item->tags) ? implode('، ', $item->tags) : (string) $item->tags,
                ]))))
                ->filter()
                ->implode("\n");
            if ($library !== '') {
                $hookGuidelines = trim($hookGuidelines . "\n\nنمونه‌های تأییدشدهٔ کتابخانهٔ هوک؛ فقط از ساختارشان الهام بگیر و متن را برای محصول فعلی بازنویسی کن:\n" . $library);
            }
        }
        try {
            $response = Http::retry(3, 300)->timeout(20)->post($webhook, [
                'job_id' => $job->id,
                'product_id' => $job->product_id,
                'product_name' => (string) ($product?->name_fa ?? 'محصول'),
                'product_link' => $product ? route('app.product', ['product' => $product->route_slug]) : '',
                'source_mode' => $job->source_mode,
                'source_url' => $job->source_url,
                'selected_images' => $job->selected_images,
                'product_images' => $productImageUrls,
                'visual_images' => $selectedImageUrls,
                'visual_image_urls' => $selectedImageUrls,
                'visual_source' => 'product_images',
                'source_audio_url' => $job->source_url,
                'source_audio_only' => $sourceAudioOnly,
                'source_video_as_visual' => false,
                'aspect_ratio' => $job->aspect_ratio,
                'font_family' => $fontFamily,
                'font_file_url' => $fontFileUrl,
                'hook_font_file_url' => $fontFileUrl,
                'hook_text' => $job->hook_text,
                'caption_text' => $job->caption_text,
                'instagram_caption_text' => (string) ($job->caption_text ?? ''),
                'keyword' => $job->keyword,
                'dm_template' => $job->dm_template,
                'auto_generate_hook' => $autoHook,
                'auto_generate_caption' => $autoCaption,
                'auto_generate_keyword' => $autoKeyword,
                'hook_guidelines' => $hookGuidelines,
                'caption_guidelines' => $captionGuidelines,
                'prompt_profile' => $promptProfile,
                'instagram_prompt' => (string) ($payload['instagram_prompt'] ?? ''),
                'telegram_prompt' => (string) ($payload['telegram_prompt'] ?? ''),
                'youtube_prompt' => (string) ($payload['youtube_prompt'] ?? ''),
                'aparat_prompt' => (string) ($payload['aparat_prompt'] ?? ''),
                'linkedin_prompt' => (string) ($payload['linkedin_prompt'] ?? ''),
                'telegram_caption_text' => (string) ($payload['telegram_caption_text'] ?? ''),
                'youtube_caption_text' => (string) ($payload['youtube_caption_text'] ?? ''),
                'aparat_caption_text' => (string) ($payload['aparat_caption_text'] ?? ''),
                'linkedin_caption_text' => (string) ($payload['linkedin_caption_text'] ?? ''),
                'telegram_buttons' => is_array($payload['telegram_buttons'] ?? null) ? $payload['telegram_buttons'] : [],
                'platform_payloads' => $platformPayloads,
                'delivery_plan' => collect($platformPayloads)
                    ->filter(static fn (array $platform): bool => (bool) ($platform['enabled'] ?? false))
                    ->map(static fn (array $platform, string $name): array => [
                        'platform' => $name,
                        'delivery_id' => "video-studio:{$job->id}:{$name}",
                        'send_video' => (bool) ($platform['send_video'] ?? false),
                        'send_images' => (bool) ($platform['send_images'] ?? false),
                        'topic_id' => match ($name) {
                            'instagram' => (string) (config('services.n8n.video_studio_telegram_instagram_thread_id') ?: '4'),
                            'telegram' => (string) (config('services.n8n.video_studio_telegram_channel_thread_id') ?: '2'),
                            'linkedin' => (string) config('services.n8n.video_studio_telegram_linkedin_thread_id', '29'),
                            'aparat' => (string) config('services.n8n.video_studio_telegram_aparat_thread_id', '31'),
                            'youtube' => (string) config('services.n8n.video_studio_telegram_youtube_thread_id', '33'),
                            default => null,
                        },
                        'send_once' => true,
                    ])->values()->all(),
                'instagram_enabled' => (bool) ($payload['instagram_enabled'] ?? true),
                'telegram_enabled' => (bool) ($payload['telegram_enabled'] ?? true),
                'youtube_enabled' => (bool) ($payload['youtube_enabled'] ?? false),
                'aparat_enabled' => (bool) ($payload['aparat_enabled'] ?? false),
                'linkedin_enabled' => (bool) ($payload['linkedin_enabled'] ?? false),
                'telegram_send_video' => (bool) ($payload['telegram_send_video'] ?? true),
                'telegram_send_images' => (bool) ($payload['telegram_send_images'] ?? false),
                'instagram_send_video' => (bool) ($payload['instagram_send_video'] ?? true),
                'instagram_send_images' => (bool) ($payload['instagram_send_images'] ?? false),
                'youtube_send_video' => (bool) ($payload['youtube_send_video'] ?? false),
                'youtube_send_images' => (bool) ($payload['youtube_send_images'] ?? false),
                'aparat_send_video' => (bool) ($payload['aparat_send_video'] ?? false),
                'aparat_send_images' => (bool) ($payload['aparat_send_images'] ?? false),
                'linkedin_send_video' => (bool) ($payload['linkedin_send_video'] ?? false),
                'linkedin_send_images' => (bool) ($payload['linkedin_send_images'] ?? false),
                'cta_enabled' => (bool) ($payload['cta_enabled'] ?? true),
                'cta_text' => (string) ($payload['cta_text'] ?? ''),
                'cta_background' => (string) ($payload['cta_background'] ?? 'primary'),
                'cta_background_color' => (string) ($payload['cta_background_color'] ?? '#16594F'),
                'cta_text_color' => (string) ($payload['cta_text_color'] ?? 'light'),
                'cta_text_color_value' => (string) ($payload['cta_text_color_value'] ?? '#FFFFFF'),
                'cta_font_size' => (float) ($payload['cta_font_size'] ?? 36),
                'cta_font_weight' => (int) ($payload['cta_font_weight'] ?? 3),
                'cta_scale' => (float) ($payload['cta_scale'] ?? 1),
                'cta_vertical_offset' => (float) ($payload['cta_vertical_offset'] ?? 0),
                'cta_guidelines' => (string) ($payload['cta_guidelines'] ?? ''),
                'cta_duration' => (float) ($payload['cta_duration'] ?? 2),
                'cta_duration_mode' => (string) ($payload['cta_duration_mode'] ?? 'manual'),
                'hook_background' => (string) ($payload['hook_background'] ?? 'primary'),
                'hook_background_color' => (string) ($payload['hook_background_color'] ?? '#16594F'),
                'hook_text_color' => (string) ($payload['hook_text_color'] ?? 'light'),
                'hook_text_color_value' => (string) ($payload['hook_text_color_value'] ?? '#FFFFFF'),
                'hook_font_size' => (float) ($payload['hook_font_size'] ?? 36),
                'hook_font_weight' => $hookFontWeight,
                'hook_font_weight_value' => $hookFontWeightValue,
                'hook_scale' => (float) ($payload['hook_scale'] ?? 1),
                'hook_vertical_offset' => (float) ($payload['hook_vertical_offset'] ?? 0),
                'hook_duration' => (float) ($payload['hook_duration'] ?? 2),
                'hook_duration_mode' => (string) ($payload['hook_duration_mode'] ?? 'manual'),
                'image_sequence' => is_array($payload['image_sequence'] ?? null) ? $payload['image_sequence'] : [],
                'hook_position' => (string) ($payload['hook_position'] ?? 'center'),
                'cta_position' => (string) ($payload['cta_position'] ?? 'bottom'),
                'transition' => (string) ($payload['transition'] ?? 'cut'),
                'transition_duration' => (float) ($payload['transition_duration'] ?? 0.5),
                'editing_rules' => $editingRules,
                'render_instructions' => $renderInstructions,
                'text_command' => (string) ($payload['text_command'] ?? ''),
                'render_config' => $renderConfig ?: [
                    'font_family' => $fontFamily,
                    'visual_source' => 'product_images',
                    'visual_image_urls' => $selectedImageUrls,
                    'source_audio_url' => $job->source_url,
                    'source_audio_only' => $sourceAudioOnly,
                    'source_video_as_visual' => false,
                    'hook_background' => (string) ($payload['hook_background'] ?? 'primary'),
                    'hook_background_color' => (string) ($payload['hook_background_color'] ?? '#16594F'),
                    'hook_text_color' => (string) ($payload['hook_text_color'] ?? 'light'),
                    'hook_text_color_value' => (string) ($payload['hook_text_color_value'] ?? '#FFFFFF'),
                    'hook_font_size' => (float) ($payload['hook_font_size'] ?? 36),
                    'hook_font_weight' => $hookFontWeight,
                    'hook_font_weight_value' => $hookFontWeightValue,
                    'hook_font_file_url' => $fontFileUrl,
                    'hook_scale' => (float) ($payload['hook_scale'] ?? 1),
                    'hook_vertical_offset' => (float) ($payload['hook_vertical_offset'] ?? 0),
                    'hook_duration' => (float) ($payload['hook_duration'] ?? 2),
                    'hook_duration_mode' => (string) ($payload['hook_duration_mode'] ?? 'manual'),
                    'image_sequence' => is_array($payload['image_sequence'] ?? null) ? $payload['image_sequence'] : [],
                    'hook_position' => (string) ($payload['hook_position'] ?? 'center'),
                    'cta_position' => (string) ($payload['cta_position'] ?? 'bottom'),
                    'cta_background' => (string) ($payload['cta_background'] ?? 'primary'),
                    'cta_background_color' => (string) ($payload['cta_background_color'] ?? '#16594F'),
                    'cta_text_color' => (string) ($payload['cta_text_color'] ?? 'light'),
                    'cta_text_color_value' => (string) ($payload['cta_text_color_value'] ?? '#FFFFFF'),
                    'cta_font_size' => (float) ($payload['cta_font_size'] ?? 36),
                    'cta_font_weight' => (int) ($payload['cta_font_weight'] ?? 3),
                    'cta_scale' => (float) ($payload['cta_scale'] ?? 1),
                    'cta_vertical_offset' => (float) ($payload['cta_vertical_offset'] ?? 0),
                    'cta_guidelines' => (string) ($payload['cta_guidelines'] ?? ''),
                    'cta_duration' => (float) ($payload['cta_duration'] ?? 2),
                    'cta_duration_mode' => (string) ($payload['cta_duration_mode'] ?? 'manual'),
                    'transition' => (string) ($payload['transition'] ?? 'cut'),
                    'transition_duration' => (float) ($payload['transition_duration'] ?? 0.5),
                    'editing_rules' => $editingRules,
                    'render_instructions' => $renderInstructions,
                ],
                'video_code' => method_exists($job, 'shortCode') ? $job->shortCode() : ('P' . strtoupper(base_convert((string) $job->id, 10, 36))),
                'telegram_topics' => [
                    'chat_id' => (string) config('services.n8n.video_studio_telegram_chat_id', ''),
                    'instagram_thread_id' => (string) (config('services.n8n.video_studio_telegram_instagram_thread_id') ?: '4'),
                    'telegram_thread_id' => (string) (config('services.n8n.video_studio_telegram_channel_thread_id') ?: '2'),
                    'music_thread_id' => (string) config('services.n8n.video_studio_telegram_music_thread_id', ''),
                    'linkedin_thread_id' => (string) config('services.n8n.video_studio_telegram_linkedin_thread_id', '29'),
                    'aparat_thread_id' => (string) config('services.n8n.video_studio_telegram_aparat_thread_id', '31'),
                    'youtube_thread_id' => (string) config('services.n8n.video_studio_telegram_youtube_thread_id', '33'),
                    'platform_topics' => [
                        'instagram' => (string) (config('services.n8n.video_studio_telegram_instagram_thread_id') ?: '4'),
                        'telegram' => (string) (config('services.n8n.video_studio_telegram_channel_thread_id') ?: '2'),
                        'linkedin' => (string) config('services.n8n.video_studio_telegram_linkedin_thread_id', '29'),
                        'aparat' => (string) config('services.n8n.video_studio_telegram_aparat_thread_id', '31'),
                        'youtube' => (string) config('services.n8n.video_studio_telegram_youtube_thread_id', '33'),
                    ],
                ],
                'revision_request' => (string) ($payload['revision_request'] ?? ''),
                'chat_id' => (string) config('services.n8n.video_studio_telegram_chat_id', ''),
                'callback_url' => rtrim((string) config('services.n8n.video_studio_callback_base_url', ''), '/')
                    . ((string) config('services.n8n.video_studio_callback_base_url', '') !== '' ? '/webhooks/video-studio/' . $job->id . '/status' : route('webhooks.video-studio.status', ['job' => $job->id])),
                'status_secret' => (string) config('services.n8n.video_studio_status_secret', ''),
            ]);
            if ($response->successful()) {
                if (!empty($payload['source_library_id'])) {
                    VideoStudioSource::query()->whereKey((int) $payload['source_library_id'])->update([
                        'used_count' => DB::raw('used_count + 1'),
                        'last_used_at' => now(),
                    ]);
                }
                $job->update(['status' => 'processing', 'n8n_execution_id' => (string) ($response->json('execution_id') ?? '')]);
            } else {
                $job->update(['status' => 'failed', 'error_message' => 'پاسخ نامعتبر از ورکفلو دریافت شد.']);
            }
        } catch (\Throwable $e) {
            $job->update(['status' => 'failed', 'error_message' => 'اتصال به ورکفلو برقرار نشد.']);
        }
    }

    /**
     * منبع معتبر را برای سفارش تضمین می‌کند و جلوی ارسال سفارش‌های بدون فایل به n8n را می‌گیرد.
     */
    private function ensureJobSource(VideoStudioJob $job): bool
    {
        if (filled($job->source_url)) {
            return true;
        }
        if ((string) $job->source_mode !== 'auto' || !Schema::hasTable('video_studio_sources')) {
            return false;
        }
        $source = VideoStudioSource::query()
            ->where('is_active', true)
            ->whereNotNull('source_url')
            ->where('source_url', '<>', '')
            ->orderBy('used_count')
            ->orderBy('id')
            ->first();
        if (!$source) {
            return false;
        }
        $payload = is_array($job->payload) ? $job->payload : [];
        $payload['source_library_id'] = $source->id;
        $job->source_mode = $source->type;
        $job->source_url = $source->source_url;
        $job->payload = $payload;
        $job->save();
        return true;
    }

    /**
     * دریافت وضعیت اجرای ورکفلو از `n8n`؛ این مسیر عمومی است اما با secret امضا می‌شود.
     */
    public function n8nStatus(Request $request, VideoStudioJob $job)
    {
        $expected = trim((string) config('services.n8n.video_studio_status_secret', ''));
        $provided = trim((string) $request->header('X-N8N-Webhook-Secret', ''));
        if ($expected === '' || ! hash_equals($expected, $provided)) {
            return response()->json(['message' => 'دسترسی غیرمجاز است.'], 401);
        }

        $data = $request->validate([
            'status' => ['required', Rule::in(['queued', 'processing', 'completed', 'failed'])],
            'n8n_execution_id' => ['nullable', 'string', 'max:120'],
            'video_url' => ['nullable', 'url', 'max:2048'],
            'error_message' => ['nullable', 'string', 'max:5000'],
            'error' => ['nullable', 'string', 'max:5000'],
            'message' => ['nullable', 'string', 'max:5000'],
        ]);

        $status = $data['status'];
        $errorMessage = trim((string) ($data['error_message'] ?? $data['error'] ?? $data['message'] ?? ''));
        if ($errorMessage !== '' && $status === 'processing') {
            $status = 'failed';
        }
        $job->update([
            'status' => $status,
            'n8n_execution_id' => $data['n8n_execution_id'] ?? $job->n8n_execution_id,
            'video_url' => $data['video_url'] ?? $job->video_url,
            'error_message' => $errorMessage !== '' ? $errorMessage : ($status === 'failed' ? $job->error_message : null),
            'started_at' => in_array($status, ['processing', 'completed'], true) ? ($job->started_at ?: now()) : $job->started_at,
            'completed_at' => in_array($status, ['completed', 'failed'], true) ? now() : null,
        ]);

        if ($status === 'completed') {
            $this->deliverRequestedProductImages($job->fresh());
        }

        return response()->json(['ok' => true, 'job_id' => $job->id, 'status' => $job->status]);
    }

    /**
     * عکس‌های محصول را فقط یک بار برای تاپیک‌هایی که در سفارش فعال شده‌اند
     * ارسال می‌کند. ارسال ویدیو همچنان مسئولیت ورکفلو است؛ این مسیر فقط
     * گزینه‌ی «ارسال عکس‌های محصول» را اجرا می‌کند.
     */
    private function deliverRequestedProductImages(VideoStudioJob $job): void
    {
        $payload = is_array($job->payload) ? $job->payload : [];
        if (filled(data_get($payload, 'images_delivered_at'))) {
            return;
        }

        $token = trim((string) config('services.telegram.bot_token'));
        $chatId = trim((string) config('services.n8n.video_studio_telegram_chat_id'));
        if ($token === '' || $chatId === '') {
            return;
        }

        $images = collect($job->selected_images ?: $this->productImageUrls($job->product))
            ->map(static fn ($url): string => trim((string) $url))
            ->filter(static fn (string $url): bool => Str::startsWith($url, ['http://', 'https://']))
            ->unique()
            ->take(5)
            ->values();
        if ($images->isEmpty()) {
            return;
        }

        $topics = [
            'instagram' => (string) (config('services.n8n.video_studio_telegram_instagram_thread_id') ?: '4'),
            'telegram' => (string) (config('services.n8n.video_studio_telegram_channel_thread_id') ?: '2'),
            'linkedin' => (string) config('services.n8n.video_studio_telegram_linkedin_thread_id', '29'),
            'aparat' => (string) config('services.n8n.video_studio_telegram_aparat_thread_id', '31'),
            'youtube' => (string) config('services.n8n.video_studio_telegram_youtube_thread_id', '33'),
        ];
        $buttons = collect((array) ($payload['telegram_buttons'] ?? []))
            ->filter(fn ($button): bool => is_array($button) && filled($button['label'] ?? '') && filled($button['url'] ?? ''))
            ->map(static fn (array $button): array => [
                'text' => (string) $button['label'],
                'url' => (string) $button['url'],
            ])->values()->all();
        $replyMarkup = $buttons !== [] ? ['inline_keyboard' => array_map(static fn (array $button): array => [$button], $buttons)] : null;
        $caption = (string) ($payload['instagram_caption_text']
            ?: $payload['telegram_caption_text']
            ?: $job->caption_text
            ?: 'تصاویر محصول');

        $sent = false;
        foreach ($topics as $platform => $topicId) {
            if (!(bool) ($payload[$platform . '_enabled'] ?? false) || !(bool) ($payload[$platform . '_send_images'] ?? false) || $topicId === '') {
                continue;
            }
            foreach ($images as $index => $imageUrl) {
                try {
                    $request = [
                        'chat_id' => $chatId,
                        'message_thread_id' => $topicId,
                        'photo' => $imageUrl,
                        'caption' => $index === 0 ? $caption : '',
                    ];
                    if ($platform === 'telegram' && $replyMarkup !== null && $index === 0) {
                        $request['reply_markup'] = json_encode($replyMarkup, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    }
                    $response = Http::acceptJson()->timeout(8)->post("https://api.telegram.org/bot{$token}/sendPhoto", $request);
                    $sent = $sent || $response->successful();
                } catch (\Throwable $exception) {
                    Log::warning('Video studio product image delivery failed', [
                        'job_id' => $job->id,
                        'platform' => $platform,
                        'message' => $exception->getMessage(),
                    ]);
                }
            }
        }

        if ($sent) {
            $payload['images_delivered_at'] = now()->toIso8601String();
            $job->forceFill(['payload' => $payload])->save();
        }
    }
}
