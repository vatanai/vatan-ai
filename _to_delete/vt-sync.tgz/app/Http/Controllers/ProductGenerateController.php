<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\AiModel;
use App\Models\ProductMetricEvent;
use App\Models\GeneratedImage;
use App\Models\Order;
use App\Models\AiProviderRequest;
use App\Models\Discount;
use App\Models\FaceProfile;
use App\Models\ReferralSetting;
use App\Models\TelegramUser;
use App\Services\AiProviderRouter;
use App\Services\CreditWalletService;
use App\Services\ProductBuildSchema;
use App\Services\ProductPromptBuilder;
use App\Services\SmsEventService;
use App\Services\ModelTierService;
use App\Services\VideoProductConfigService;
use App\Services\StudioCostService;
use App\Services\UserGalleryService;
use App\Services\ProductCreatorRewardService;
use App\Services\UserStorageService;
use App\Jobs\GenerateProfileMediaThumbnail;
use App\Http\Requests\GenerateProductRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Exception;

class ProductGenerateController extends Controller
{
    public function __construct(
        protected AiProviderRouter $openRouter,
        protected CreditWalletService $creditWallet,
        protected ModelTierService $modelTiers,
        protected ProductCreatorRewardService $creatorRewards,
        protected UserStorageService $userStorage,
    )
    {
    }

    public function create(Request $request, ProductBuildSchema $schema)
    {
        $slug = $request->query('product');
        // هر دو لینک قدیمی و جدید را پشتیبانی می‌کنیم:
        // ?product=slug و ?product=123456-slug باید همان محصول را باز کنند.
        // اگر محصول مشخص شده باشد، هرگز به‌صورت بی‌صدا محصول دیگری جایگزین نشود.
        if ($slug !== null && $slug !== '') {
            $product = (new Product())->resolveRouteBinding($slug, 'route_slug');
            abort_unless($product && $product->status === 'active', 404);
            // «استودیو محصول» (پک شات): فقط محصولات product_mode=product وارد این شاخه می‌شوند؛
            // مسیر همه‌ی محصولات قبلی (portrait) بدون تغییر ادامه پیدا می‌کند.
            if ($product->isShotProduct()) {
                abort_unless(app(\App\Services\ProductShots\ProductShotFeature::class)->availableFor($request->user()), 404);

                return app(\App\Http\Controllers\ProductShotController::class)->page($product);
            }
            if ($product->isVideoProduct()) {
                return app(VideoProductController::class)->show(
                    $request,
                    $product,
                    $schema,
                    app(\App\Services\VideoModelSchemaService::class),
                );
            }
        } else {
            // لینک عمومی «بساز» ابتدا همه‌ی محصولات فعال را برای انتخاب نمایش می‌دهد.
            $products = Product::query()
                ->where('status', 'active')
                ->hideUnavailableProductModes()
                ->latest()
                ->get();

            return view('app.create-products', compact('products'));
        }

        $user = $request->user();
        $tierKey = $this->modelTiers->tierKeyForUser($user);
        return view('app.create-product', [
            'product' => $product,
            'buildProduct' => $schema->pageData(
                $product,
                $this->modelTiers->tierMeta($tierKey, $user?->plan),
                $this->modelTiers->outputQualityOptions($user, $product),
            ),
        ]);
    }

    /**
     * استودیوی عمومی ساخت، تنظیماتش را از دو محصول واقعی فعال می‌گیرد تا
     * فرم عمومی هم از همان مسیر اعتبارسنجی و اجرای محصول استفاده کند.
     */
    public function createStudio(ProductBuildSchema $schema)
    {
        return view('app.create-studio', $this->studioViewData($schema));
    }

    /**
     * داده‌ی مشترک استودیوی اصلی و نسخه‌ی آزمایشی گردش‌کارها.
     */
    public function studioViewData(ProductBuildSchema $schema): array
    {
        $imageProduct = Product::query()
            ->where('status', 'active')
            ->where('slug', 'ai-fashion-portrait')
            ->first()
            ?: Product::query()->where('status', 'active')->withoutShotProducts()->where('output_type', 'image')->latest()->first();

        $videoProduct = Product::query()
            ->where('status', 'active')
            ->where('slug', 'ai-cinematic-short-video')
            ->first()
            ?: Product::query()->where('status', 'active')->where('output_type', 'video')->latest()->first();

        abort_unless($imageProduct && $videoProduct, 404);

        $imageData = $schema->pageData($imageProduct);
        // استودیوی اصلی نسبت‌های استاندارد را نمایش می‌دهد؛ مدل انتخاب‌شده
        // در رابط کاربری گزینه‌های ناسازگار را فیلتر می‌کند.
        $imageData['output_aspect_ratios'] = Product::supportedAspectRatios();
        $imageData['default_output_aspect_ratio'] = '3:4';
        $videoData = $schema->pageData($videoProduct);
        $videoData['video'] = $videoProduct->videoConfiguration();
        // استودیوی عمومی دامنه‌ی کامل تنظیمات ساخت را در اختیار کاربر می‌گذارد؛
        // محدودیت‌های کوتاه فرم قدیمی محصول نباید رابط استودیو را محدود کند.
        $videoData['video']['durations'] = range(1, 15);
        $videoData['video']['default_duration'] = 4;
        $videoData['video']['resolutions'] = VideoProductConfigService::RESOLUTIONS;
        $videoData['video']['default_resolution'] = '720p';
        $videoData['video']['aspect_ratios'] = VideoProductConfigService::STUDIO_ASPECT_RATIOS;
        $defaultVideoDuration = max(1, (int) ($videoData['video']['default_duration'] ?? 4));
        $defaultVideoCredit = max(0, app(VideoProductConfigService::class)->creditCost($videoProduct, $defaultVideoDuration));
        $videoData['video']['credit_costs_by_duration'] = collect(range(1, 15))
            ->mapWithKeys(fn (int $duration): array => [(string) $duration => $defaultVideoCredit * (int) ceil($duration / $defaultVideoDuration)])
            ->all();
        $videoData['video']['motion_presets'] = collect(app(VideoProductConfigService::class)->motionPresetCatalog())
            ->map(fn (array $preset, string $key): array => ['key' => $key] + $preset)
            ->values()->all();

        return [
            'studioConfig' => [
                'image' => $this->studioProductConfig($imageProduct, $imageData, $schema, 'image'),
                'video' => $this->studioProductConfig($videoProduct, $videoData, $schema, 'video'),
                'authenticated' => auth()->check(),
                'login_url' => route('login', ['redirect' => request()->fullUrl()]),
            ],
        ];
    }

    public function studioQuote(Request $request, StudioCostService $studioCosts): \Illuminate\Http\JsonResponse
    {
        $mode = $request->query('mode') === 'video' ? 'video' : 'image';
        $product = Product::query()->where('status', 'active')->where('output_type', $mode)->where('slug', $mode === 'video' ? 'ai-cinematic-short-video' : 'ai-fashion-portrait')->first()
            ?: Product::query()->where('status', 'active')->withoutShotProducts()->where('output_type', $mode)->latest()->firstOrFail();
        $model = $this->studioQuoteModel($request, $product, $mode);
        $quote = $studioCosts->quote($product, [
            'media_type' => $mode,
            'resolution' => (string) $request->query('resolution', ''),
            'aspect_ratio' => (string) $request->query('aspect_ratio', ''),
            'workflow' => $mode === 'image' ? (string) $request->query('workflow', 'text_to_image') : '',
            'duration' => $mode === 'video' ? max(1, min(15, (int) $request->query('duration', 4))) : null,
            'count' => $mode === 'image' ? max(1, min(6, (int) $request->query('count', 1))) : 1,
        ], $model);

        return response()->json($quote);
    }

    private function studioQuoteModel(Request $request, Product $product, string $mode): ?AiModel
    {
        $requestedModelId = trim((string) $request->query('model', ''));

        if ($mode === 'image') {
            $models = AiModel::query()->selectableForImageStudio()->get();
            $model = $requestedModelId !== ''
                ? $models->firstWhere('openrouter_model_id', $requestedModelId)
                : $this->sortStudioImageModels($models)->first();

            if (! $model) {
                throw ValidationException::withMessages([
                    'model' => 'مدل انتخاب‌شده در کاتالوگ تأییدشده‌ی استودیو موجود نیست.',
                ]);
            }

            return $model;
        }

        $modelId = $requestedModelId ?: (string) $product->primary_model;
        if ($modelId === '') return null;

        $primary = AiModel::query()->where('is_active', true)->where('output_modality', $mode)
            ->whereIn('task_type', $this->studioTaskTypes($mode))
            ->when($mode === 'video', fn ($query) => $query->whereNotNull('capability_config'))
            ->where('openrouter_model_id', $modelId)
            ->where('provider', 'openrouter')
            ->first();
        if ($requestedModelId !== '' || $this->hasStoredModelPrice($primary)) return $primary;

        return AiModel::query()->where('is_active', true)->where('output_modality', $mode)
            ->whereIn('task_type', $this->studioTaskTypes($mode))
            ->when($mode === 'video', fn ($query) => $query->whereNotNull('capability_config'))
            ->where('provider', 'openrouter')
            ->whereNotNull('openrouter_model_id')->where('openrouter_model_id', '<>', '')
            ->orderByRaw($mode === 'video'
                ? "CASE task_type WHEN 'text_to_video' THEN 0 WHEN 'image_to_video' THEN 1 WHEN 'video_to_video' THEN 2 ELSE 3 END"
                : "CASE task_type WHEN 'text_to_image' THEN 0 WHEN 'image_to_image' THEN 1 ELSE 2 END")
            ->orderByRaw("CASE provider WHEN 'openrouter' THEN 0 WHEN 'fal' THEN 1 WHEN 'replicate' THEN 2 ELSE 3 END")
            ->orderByDesc('lab_priority')->first() ?: $primary;
    }

    private function studioProductConfig(Product $product, array $data, ProductBuildSchema $schema, string $modality): array
    {
        $modelOptions = $this->studioModelOptions($product, $modality);
        $defaultModel = $modality === 'image'
            ? (string) data_get($modelOptions, '0.value', '')
            : (string) ($product->primary_model ?: 'مدل پیش‌فرض وطن');
        $fields = $schema->fields($product);
        $defaults = [];
        foreach ($fields as $field) {
            if (($field['id'] ?? '') === '' || ($field['type'] ?? '') === 'file_upload') continue;
            $options = (array) ($field['options'] ?? []);
            if ($options !== []) {
                $defaults[$field['id']] = (string) ($options[0]['value'] ?? '');
            } elseif (($field['type'] ?? '') === 'text') {
                $defaults[$field['id']] = 'استودیوی وطن';
            } elseif (($field['type'] ?? '') === 'number') {
                $defaults[$field['id']] = (string) ($field['min'] ?? 1);
            }
        }

        return [
            'id' => $product->id,
            'route_slug' => $product->route_slug,
            'generate_url' => route('app.create.generate', $product->route_slug),
            'name' => $data['name'],
            'cover' => $data['cover'],
            'description' => $data['description'],
            'cost' => (int) ($data['cost'] ?? 0),
            'estimated_time' => $data['estimated_time'] ?? 'حدود یک دقیقه',
            'model' => $defaultModel,
            'default_model' => $defaultModel,
            'model_options' => $modelOptions,
            'fields' => $data['fields'] ?? [],
            'reference_upload_key' => data_get(collect($fields)->first(fn (array $field): bool => in_array($field['type'] ?? '', ['image_upload', 'multi_image'], true)), 'id'),
            'requires_reference' => (int) ($product->min_reference_images ?? 0) > 0,
            'defaults' => $defaults,
            'output_aspect_ratios' => $data['output_aspect_ratios'] ?? [],
            'default_output_aspect_ratio' => $data['default_output_aspect_ratio'] ?? null,
            'output_resolutions' => $modality === 'image' ? ['1K', '2K'] : ($data['output_resolutions'] ?? []),
            'default_output_resolution' => $modality === 'image' ? '1K' : ($data['default_output_resolution'] ?? null),
            'main_quality_options' => $data['main_quality_options'] ?? [],
            'default_main_quality' => data_get($data, 'main_quality_options.0.key', 'standard'),
            'output_count' => max(1, (int) ($data['output_count'] ?? 1)),
            'image_workflows' => $modality === 'image' ? [
                ['value' => 'text_to_image', 'label' => 'متن به عکس', 'help' => 'فقط توضیحات ساخت لازم است.'],
                ['value' => 'image_to_image', 'label' => 'عکس به عکس', 'help' => 'عکس مرجع و توضیحات ساخت لازم است.'],
            ] : [],
            'video' => $data['video'] ?? null,
        ];
    }

    private function studioModelOptions(Product $product, string $modality): array
    {
        $query = $modality === 'image'
            ? AiModel::query()->selectableForImageStudio()
            : AiModel::query()
                ->where('is_active', true)
                ->where('output_modality', $modality)
                ->whereIn('task_type', $this->studioTaskTypes($modality))
                ->whereNotNull('capability_config')
                ->whereNotNull('openrouter_model_id')
                ->where('openrouter_model_id', '<>', '')
                ->where('provider', 'openrouter')
                ->orderByRaw("CASE provider WHEN 'openrouter' THEN 0 WHEN 'fal' THEN 1 WHEN 'replicate' THEN 2 ELSE 3 END")
                ->orderByRaw("CASE task_type WHEN 'text_to_video' THEN 0 WHEN 'image_to_video' THEN 1 WHEN 'video_to_video' THEN 2 ELSE 3 END");

        $modelColumns = [
            'id',
            'name',
            'openrouter_model_id',
            'provider',
            'task_type',
            'supports_image_input',
            'capability_config',
            'pricing_config',
        ];
        if ($modality === 'image' && Schema::hasColumn('ai_models', 'studio_image_priority')) {
            $modelColumns[] = 'studio_image_priority';
        }

        $models = $query
            ->get($modelColumns)
            ->when($modality === 'image', fn ($models) => $this->sortStudioImageModels($models))
            ->when($modality === 'video', function ($models) {
                return $models->sortBy(function (AiModel $model): array {
                    $providerPriority = AiModel::STUDIO_PROVIDER_PRIORITY[$model->provider] ?? 99;
                    $priority = array_search($model->openrouter_model_id, AiModel::STUDIO_VIDEO_MODEL_PRIORITY, true);
                    $taskOrder = array_search($model->task_type, ['text_to_video', 'image_to_video', 'video_to_video', 'face_animation'], true);
                    return [$providerPriority, $priority === false ? 1000 : $priority, $taskOrder === false ? 100 : $taskOrder, $model->id];
                })->values();
            });

        $options = $models->map(fn (AiModel $model): array => [
            'value' => (string) $model->openrouter_model_id,
            'label' => (string) ($model->name ?: $model->openrouter_model_id),
            'meta' => strtoupper((string) $model->provider),
            'provider' => (string) $model->provider,
            'supports_image_input' => (bool) $model->supports_image_input,
            'supported_aspect_ratios' => $this->studioModelSupportedOptions($model, 'aspect_ratios', $modality),
            'supported_resolutions' => $this->studioModelSupportedOptions($model, 'resolutions', $modality),
            'supported_durations' => $modality === 'video' ? $this->studioModelSupportedOptions($model, 'durations', $modality) : [],
            'task_type' => (string) $model->task_type,
            'max_reference_images' => max(1, min(
                max(1, (int) config('studio.max_reference_images', 20)),
                (int) data_get($model->capability_config, 'max_reference_images', data_get($model->capability_config, 'max_images', $model->supports_image_input ? 1 : 0)),
            )),
        ])->unique(fn (array $option): string => $option['value'] . '|' . $option['task_type'])->values();

        $primary = $modality === 'image'
            ? (string) data_get($options, '0.value', '')
            : (string) $product->primary_model;

        return $options->map(function (array $option) use ($primary): array {
            $isPrimary = (string) $option['value'] === $primary;
            return [
                ...$option,
                'meta' => ($isPrimary ? 'مدل اصلی' : 'مدل جایگزین') . ' · ' . ($option['meta'] ?: 'سرویس ساخت'),
                'role' => $isPrimary ? 'primary' : 'fallback',
            ];
        })->values()->all();
    }

    /**
     * قابلیت‌های مؤثر مدل را به رابط استودیو می‌دهد تا گزینه‌های ناسازگار
     * پیش از ارسال درخواست حذف شوند. برای مدل‌های قدیمی که هنوز این دو
     * مقدار را در دیتابیس ندارند، فقط خانواده‌هایی که محدودیت شناخته‌شده
     * دارند fallback مشخص دریافت می‌کنند.
     */
    private function studioModelSupportedOptions(AiModel $model, string $kind, string $modality): array
    {
        $key = 'supported_' . $kind;
        $capabilities = (array) ($model->capability_config ?? []);
        $pricing = (array) ($model->pricing_config ?? []);
        $values = data_get($capabilities, $key, data_get($pricing, $key, []));

        if (is_array($values) && $values !== []) {
            return array_values(array_map('strval', $values));
        }

        $modelId = strtolower((string) $model->openrouter_model_id);
        if ($modality === 'image' && $kind === 'aspect_ratios' && str_starts_with($modelId, 'black-forest-labs/flux.2-')) {
            return ['1:1', '4:3', '3:4', '3:2', '2:3', '16:9', '9:16', '21:9'];
        }

        return [];
    }

    private function applyStudioModel(Product $product, Request $request, string $modality): void
    {
        if (! $request->boolean('studio_mode')) {
            return;
        }

        $modelId = trim((string) $request->input('studio_model', ''));

        if ($modality === 'image') {
            $models = $this->sortStudioImageModels(AiModel::query()->selectableForImageStudio()->get());
            $model = $modelId !== ''
                ? $models->firstWhere('openrouter_model_id', $modelId)
                : $models->first();

            if (! $model) {
                throw ValidationException::withMessages([
                    'studio_model' => 'مدل انتخاب‌شده در کاتالوگ تأییدشده‌ی استودیو موجود نیست.',
                ]);
            }

            $product->primary_model = (string) $model->openrouter_model_id;
            $product->ai_provider = 'openrouter';
            $product->fallback_models = [];
            $product->fallback_model_providers = [];
            $product->strict_model_priority = true;

            return;
        }

        $taskTypes = $this->studioTaskTypesForRequest($request, $modality);
        $query = AiModel::query()
            ->where('is_active', true)
            ->where('output_modality', $modality)
            ->where(function ($workflow) use ($taskTypes, $request, $modality): void {
                $workflow->whereIn('task_type', $taskTypes);
                if ($modality === 'image' && $request->input('studio_workflow') === 'image_to_image') {
                    $workflow->orWhere(function ($imageInputModel): void {
                        $imageInputModel->where('task_type', 'text_to_image')->where('supports_image_input', true);
                    });
                }
            })
            ->when($modelId !== '', fn ($builder) => $builder->where('openrouter_model_id', $modelId))
            ->where('provider', 'openrouter')
            ->when($modelId === '', fn ($builder) => $builder->orderByDesc('lab_priority'));
        $model = $query->first();
        if (!$model) {
            throw ValidationException::withMessages(['studio_model' => 'مدل انتخاب‌شده برای این نوع ساخت فعال نیست.']);
        }

        $candidates = collect([(string) $product->primary_model => (string) $product->ai_provider]);
        foreach ((array) $product->fallback_models as $index => $fallback) {
            $fallback = (string) $fallback;
            if ($fallback !== '') {
                $fallbackProviders = (array) $product->fallback_model_providers;
                $candidates->put($fallback, (string) ($fallbackProviders[$index] ?? 'openrouter'));
            }
        }
        $candidates->forget((string) $model->openrouter_model_id);
        $providerPriority = ['openrouter' => 0, 'fal' => 1, 'replicate' => 2];
        $candidates = $candidates->sortBy(function (string $provider, string $modelId) use ($providerPriority): array {
            return [$providerPriority[$provider] ?? 3, $modelId];
        });
        $product->primary_model = (string) $model->openrouter_model_id;
        $product->ai_provider = (string) $model->provider;
        $product->fallback_models = $candidates->keys()->values()->all();
        $product->fallback_model_providers = $candidates->values()->all();
    }

    private function studioTaskTypes(string $modality): array
    {
        return $modality === 'video'
            ? ['text_to_video', 'image_to_video', 'video_to_video', 'face_animation']
            : ['text_to_image', 'image_to_image', 'face_consistency'];
    }

    private function studioTaskTypesForRequest(Request $request, string $modality): array
    {
        if ($modality !== 'image' || ! $request->boolean('studio_mode')) {
            return $this->studioTaskTypes($modality);
        }

        return $request->input('studio_workflow') === 'image_to_image'
            ? ['image_to_image', 'face_consistency']
            : ['text_to_image'];
    }

    private function hasStoredModelPrice(?AiModel $model): bool
    {
        $pricing = (array) ($model?->pricing_config ?? []);

        return $model !== null && (
            (float) $model->cost_per_generation_usd > 0
            || (float) data_get($pricing, 'unit_price', 0) > 0
            || (float) data_get($pricing, 'price', 0) > 0
            || (array) data_get($pricing, 'resolution_tiers', []) !== []
            || (array) data_get($pricing, 'tiers', []) !== []
            || (array) data_get($pricing, 'duration_prices', []) !== []
        );
    }

    public function build(Product $product)
    {
        abort_unless($product->status === 'active', 404);

        // مسیر قدیمی را به مسیر اصلی منتقل می‌کنیم تا تمام لینک‌ها یک تجربه و
        // یک فرم ساخت داشته باشند و مشخصات محصول در صفحه‌ی «بساز» از بین نرود.
        return redirect()->route('app.create', ['product' => $product->route_slug]);
    }

    /**
     * پیش‌نمایش ایزوله رابط کاربری «بساز»؛ تا پیش از تأیید نهایی به محصول یا
     * مسیر عملیاتی متصل نمی‌شود و تمام حالت‌های شِمای ورودی را نمایش می‌دهد.
     */
    public function createPreview()
    {
        $previewProduct = $this->previewProductData();

        return view('app.create-preview', compact('previewProduct'));
    }

    private function previewProductData(): array
    {
        return [
            'name' => 'پرتره سینمایی فوق‌واقعی',
            'description' => 'چهره شما با حفظ دقیق هویت، نورپردازی سینمایی و جزئیات طبیعی بازآفرینی می‌شود.',
            'cover' => asset('assets/img/moody-portrait-of-a-young-man-with-a-black-horse-on-a-ranch-ai-photo-editing-prompt.avif'),
            'cost' => 18,
            'estimated_time' => 'حدود ۴۵ ثانیه',
            'output_count' => 4,
            'fields' => $this->previewInputSchema(),
        ];
    }

    private function previewInputSchema(): array
    {
        return [
            ['id' => 'guide', 'type' => 'info', 'label' => 'برای بیشترین شباهت، یک عکس واضح و روبه‌رو با نور طبیعی انتخاب کنید.'],
            ['id' => 'identity_section', 'type' => 'section', 'label' => 'تصاویر هویتی', 'help' => 'تصویری انتخاب کنید که جزئیات صورت در آن کاملاً مشخص باشد.'],
            ['id' => 'portrait', 'type' => 'image_upload', 'label' => 'تصویر اصلی چهره', 'help' => 'JPG، PNG یا WebP · حداکثر ۱۰ مگابایت', 'required' => true],
            ['id' => 'references', 'type' => 'multi_image', 'label' => 'تصاویر مرجع بیشتر', 'help' => 'اختیاری · تا ۳ زاویه دیگر برای حفظ بهتر هویت'],
            ['id' => 'identity_divider', 'type' => 'divider', 'label' => ''],
            ['id' => 'creative_section', 'type' => 'section', 'label' => 'جزئیات خلاقانه', 'help' => 'این موارد ظاهر و فضای خروجی را شخصی‌سازی می‌کنند.'],
            ['id' => 'scene', 'type' => 'textarea', 'label' => 'فضایی که در ذهن دارید', 'placeholder' => 'مثلاً: یک خیابان خیس در شب با نورهای نئونی...'],
            ['id' => 'custom_prompt', 'type' => 'prompt', 'label' => 'دستور اختصاصی شما', 'placeholder' => 'جزئیات خاصی که دوست دارید در خروجی دیده شود...'],
            ['id' => 'title', 'type' => 'text', 'label' => 'متن کوتاه روی تصویر', 'placeholder' => 'اختیاری'],
            ['id' => 'age', 'type' => 'number', 'label' => 'سن ظاهری', 'min' => 18, 'max' => 80, 'value' => 30],
            ['id' => 'mood', 'type' => 'radio', 'label' => 'حس‌وحال چهره', 'value' => 'confident', 'options' => [['value'=>'confident','label'=>'بااعتمادبه‌نفس'],['value'=>'calm','label'=>'آرام'],['value'=>'serious','label'=>'جدی'],['value'=>'smile','label'=>'لبخند ملایم']]],
            ['id' => 'camera', 'type' => 'select', 'label' => 'نوع قاب دوربین', 'value' => 'portrait', 'options' => [['value'=>'close','label'=>'نمای نزدیک'],['value'=>'portrait','label'=>'پرتره نیم‌تنه'],['value'=>'full','label'=>'تمام‌قد']]],
            ['id' => 'details', 'type' => 'multi_select', 'label' => 'جزئیات تکمیلی', 'options' => [['value'=>'rain','label'=>'باران'],['value'=>'fog','label'=>'مه'],['value'=>'grain','label'=>'گرین فیلم'],['value'=>'bokeh','label'=>'بوکه پس‌زمینه']]],
            ['id' => 'lighting', 'type' => 'button_group', 'label' => 'نورپردازی', 'value' => 'cinematic', 'options' => [['value'=>'soft','label'=>'نرم'],['value'=>'cinematic','label'=>'سینمایی'],['value'=>'studio','label'=>'استودیویی']]],
            ['id' => 'identity', 'type' => 'strength', 'label' => 'میزان حفظ شباهت', 'value' => 90, 'min' => 50, 'max' => 100, 'unit' => '٪'],
            ['id' => 'cinematic_depth', 'type' => 'slider', 'label' => 'عمق سینمایی', 'value' => 65, 'min' => 0, 'max' => 100, 'unit' => '٪'],
            ['id' => 'background', 'type' => 'color', 'label' => 'رنگ غالب پس‌زمینه', 'value' => '#18221f'],
            ['id' => 'preserve_body', 'type' => 'switch', 'label' => 'فرم بدن نیز حفظ شود', 'value' => true],
            ['id' => 'confirm', 'type' => 'checkbox', 'label' => 'حق استفاده از تصاویر بارگذاری‌شده را دارم', 'required' => true],
            ['id' => 'style', 'type' => 'style_preset', 'label' => 'استایل خروجی', 'value' => 'cinematic', 'options' => [
                ['value'=>'cinematic','label'=>'سینمایی','image'=>asset('assets/img/best-ai-prompts-for-cinematic-photos-and-portraits.jpeg')],
                ['value'=>'editorial','label'=>'ادیتوریال','image'=>asset('assets/img/elegant-woman-cafe-portrait-by-promptplum.avif')],
                ['value'=>'classic','label'=>'کلاسیک','image'=>asset('assets/img/gemini-vintage-boys-man-with-flowers-ai-photo-editing-prompt-ud1t53g9cf.webp')],
            ]],
            ['id' => 'ratio', 'type' => 'aspect_ratio', 'label' => 'نسبت تصویر', 'value' => '4:5', 'options' => [['value'=>'1:1','label'=>'۱:۱'],['value'=>'4:5','label'=>'۴:۵'],['value'=>'9:16','label'=>'۹:۱۶'],['value'=>'16:9','label'=>'۱۶:۹']]],
            ['id' => 'resolution', 'type' => 'resolution', 'label' => 'کیفیت خروجی', 'value' => '2K', 'options' => [['value'=>'1K','label'=>'1K','meta'=>'استاندارد'],['value'=>'2K','label'=>'2K','meta'=>'پیشنهادی'],['value'=>'4K','label'=>'4K','meta'=>'+ ۶ اعتبار']]],
            ['id' => 'negative', 'type' => 'negative_prompt', 'label' => 'موارد ناخواسته', 'placeholder' => 'مثلاً: عینک، نوشته، تاری...'],
            ['id' => 'seed', 'type' => 'seed', 'label' => 'Seed', 'placeholder' => 'تصادفی'],
            ['id' => 'source_file', 'type' => 'file_upload', 'label' => 'فایل مرجع تکمیلی', 'help' => 'اختیاری'],
        ];
    }

    public function show(Product $product)
    {
        // محصول پروداکتی صفحه‌ی جزئیات جدا ندارد؛ مستقیم به صفحه‌ی ساخت پک می‌رود.
        if ($product->isShotProduct()) {
            abort_unless(app(\App\Services\ProductShots\ProductShotFeature::class)->availableFor(auth()->user()), 404);

            return redirect()->route('app.create', ['product' => $product->route_slug]);
        }

        $metricPayload = [
            'product_id' => $product->id,
            'user_id' => auth()->id(),
            'session_id' => session()->getId(),
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ];
        ProductMetricEvent::create($metricPayload + ['event_type' => 'view']);
        if (request()->query('source') === 'trends') {
            ProductMetricEvent::create($metricPayload + ['event_type' => 'trend_open']);
        }

        $product->loadCount('likedByUsers');

        $similar = Product::where('status', 'active')
            ->hideUnavailableProductModes()
            ->where('id', '!=', $product->id)
            ->where('category', $product->category)
            ->latest()->limit(6)->get();

        // وضعیت سیو بودن محصول برای کاربر لاگین‌کرده فعلی (برای رنگ‌آمیزی اولیه دکمه سیو)
        $isSaved = auth()->check() ? auth()->user()->hasSavedProduct($product->id) : false;

        // وضعیت لایک بودن محصول (try/catch: اگر مایگریشن liked_products هنوز اجرا نشده باشد صفحه نمی‌شکند)
        $isLiked = false;
        if (auth()->check()) {
            try { $isLiked = auth()->user()->hasLikedProduct($product->id); } catch (\Throwable $e) {}
        }

        $referralSettings = ReferralSetting::current();
        $productReferralUrl = auth()->check() && $referralSettings->referralIsActive()
            ? route('referral.product', [
                'code' => auth()->user()->referral_code,
                'product' => $product->route_slug,
            ])
            : null;

        return view('app.product', compact(
            'product', 'similar', 'isSaved', 'isLiked', 'referralSettings', 'productReferralUrl'
        ));
    }

    public function generate(GenerateProductRequest $request, Product $product, ProductBuildSchema $schema, ProductPromptBuilder $promptBuilder, StudioCostService $studioCosts)
    {
        $correlationId = (string) Str::uuid();
        if ($request->boolean('studio_mode')) {
            Log::withContext([
                'correlation_id' => $correlationId,
                'user_id' => $request->user()?->id,
                'studio_operation' => $product->isVideoProduct() ? 'video_generation' : 'image_generation',
            ]);
            $request->attributes->set('correlation_id', $correlationId);
        }
        if ($product->isVideoProduct()) {
            return app(VideoProductController::class)->generate(
                $request,
                $product,
                $schema,
                app(\App\Services\VideoGenerationService::class),
            );
        }

        $failure = static function (
            string $message,
            string $errorCode,
            int $httpStatus = 422,
            bool $retryable = false,
            int $reserved = 0,
            int $refunded = 0,
        ) use ($correlationId): \Illuminate\Http\JsonResponse {
            return response()->json([
                'success' => false,
                'status' => 'failed',
                'message' => $message,
                'error_code' => $errorCode,
                'retryable' => $retryable,
                'generation_id' => null,
                'credits_reserved' => $reserved,
                'credits_settled' => 0,
                'credits_refunded' => $refunded,
                'poll_url' => null,
            ], $httpStatus)->header('X-Correlation-ID', $correlationId);
        };

        $this->applyStudioModel($product, $request, 'image');
        $user = auth()->user();
        $faceProfile = $this->selectedFaceProfile($request, $user);
        $requestedMainQuality = (string) $request->input('output.main_quality', 'standard');
        $mainQuality = $this->modelTiers->resolveOutputQuality($user, $requestedMainQuality, $product);
        if (! $mainQuality) {
            return $failure('برای انتخاب این کیفیت، ابتدا یکی از پلن‌های اعتباری را فعال کنید.', 'PLAN_REQUIRED', 403);
        }

        $tierKey = $mainQuality['execution_tier_key'];
        $tierMeta = $this->modelTiers->tierMeta($tierKey, $user?->plan);
        $creditReservation = ['total' => 0, 'promotional' => 0, 'paid' => 0];
        $creditReservationSettled = false;
        $order = null;
        $fieldValues = (array) $request->input('fields', []);
        $studioWorkflow = (string) $request->input('studio_workflow', 'text_to_image');
        $identityRequested = (bool) $product->identity_preservation
            && $request->boolean('identity_preservation')
            && (! $request->boolean('studio_mode') || $studioWorkflow === 'image_to_image');
        $creditCost = max(0, (int) $mainQuality['credits'])
            + $schema->additionalCredit($product, $fieldValues)
            + ($identityRequested ? max(0, (int) $product->identity_credit_cost) : 0);

        $studioModel = $this->selectedStudioImageModel($request, $product);
        $studioQuote = $request->boolean('studio_mode')
            ? $studioCosts->quote($product, [
                'media_type' => 'image',
                'resolution' => (string) $request->input('output.quality', ''),
                'aspect_ratio' => (string) $request->input('output.aspect_ratio', ''),
                'count' => 1,
            ], $studioModel)
            : null;
        if ($studioQuote && !$studioQuote['cost_known']) {
            throw ValidationException::withMessages(['studio_model' => 'قیمت مدل انتخاب‌شده هنوز در کاتالوگ پروایدر ثبت نشده است.']);
        }
        if ($studioQuote && $studioQuote['credits'] !== null) {
            $creditCost = (int) ceil((int) $studioQuote['credits'] / max(1, (int) $request->input('output.count', 1)));
        }

        // ۰. مدل‌های خروجی چندگانه (Output Variants) — اگر محصول واریانت دارد،
        // کاربر باید حداقل یکی را انتخاب کرده باشد و هزینه اعتبار در تعداد انتخاب ضرب می‌شود.
        $variantList = $product->outputVariantList();
        $selectedVariants = [];
        if (!empty($variantList)) {
            $requestedKeys = array_map('strval', (array) $request->input('variants', []));
            foreach ($variantList as $v) {
                if (in_array($v['key'], $requestedKeys, true)) {
                    $selectedVariants[] = $v;
                }
            }
            if (empty($selectedVariants)) {
                return $failure('حداقل یک مدل خروجی را انتخاب کنید.', 'OUTPUT_VARIANT_REQUIRED');
            }
        }
        $requestedOutputCount = max(1, min(6, (int) $request->input('output.count', 1)));
        $runCount = max(1, count($selectedVariants) ?: $requestedOutputCount);
        $originalCreditCost = $creditCost * $runCount;
        $totalCreditCost = $originalCreditCost;
        $discount = null;
        $discountCredits = 0;

        if ($request->filled('discount_code')) {
            $code = strtoupper(trim((string) $request->input('discount_code')));
            $discount = Discount::available()->where('code', $code)->first();
            if (!$discount) {
                return $failure('کد تخفیف معتبر یا فعال نیست.', 'DISCOUNT_INVALID');
            }
            if ($discount->first_order_only && Order::where('user_id', $user?->id)->exists()) {
                return $failure('این کد فقط برای اولین سفارش قابل استفاده است.', 'DISCOUNT_FIRST_ORDER_ONLY');
            }
            if ($user && Order::where('user_id', $user->id)->where('discount_id', $discount->id)->count() >= $discount->usage_limit_per_user) {
                return $failure('سقف استفاده شما از این کد تخفیف تکمیل شده است.', 'DISCOUNT_USAGE_LIMIT');
            }
            $inScope = $discount->scope === 'all'
                || ($discount->scope === 'products' && in_array($product->id, $discount->product_ids ?? [], true))
                || ($discount->scope === 'categories' && $product->categories()->whereIn('categories.id', $discount->category_ids ?? [])->exists());
            if (!$inScope) {
                return $failure('این کد برای محصول انتخاب‌شده قابل استفاده نیست.', 'DISCOUNT_OUT_OF_SCOPE');
            }
            $discountCredits = $discount->calculateCredits($originalCreditCost);
            if ($discountCredits < 1) {
                return $failure('حداقل اعتبار لازم برای این کد تخفیف تأمین نشده است.', 'DISCOUNT_MINIMUM_NOT_MET');
            }
            $totalCreditCost = max(0, $originalCreditCost - $discountCredits);
        }

        // اصلاح دریافت فایل‌ها بر اساس ساختار ارسالی جاوااسکریپت (uploads)
        $allFiles = $schema->flattenUploads($request);
        if ($request->boolean('studio_mode') && $studioWorkflow === 'image_to_image' && $studioModel) {
            $modelMaxReferences = max(1, min(
                max(1, (int) config('studio.max_reference_images', 20)),
                (int) data_get($studioModel->capability_config, 'max_reference_images', data_get($studioModel->capability_config, 'max_images', 1)),
            ));
            if (count($allFiles) > $modelMaxReferences) {
                throw ValidationException::withMessages([
                    'uploads' => "مدل انتخاب‌شده حداکثر {$modelMaxReferences} تصویر مرجع می‌پذیرد.",
                ]);
            }
        }
        if ($request->boolean('studio_mode')
            && $studioWorkflow === 'image_to_image'
            && $allFiles === []
            && ! $faceProfile) {
            return $failure('برای حالت عکس به عکس، یک تصویر ورودی انتخاب کنید.', 'REFERENCE_IMAGE_REQUIRED');
        }
        if (! ($request->boolean('studio_mode') && $studioWorkflow === 'image_to_image')
            && in_array($product->subject_type, ['face', 'body'], true)
            && count($allFiles) > 3) {
            return $failure('برای محصولات چهره‌محور حداکثر ۳ عکس مرجع قابل استفاده است.', 'REFERENCE_IMAGE_LIMIT');
        }

        // ۲. بررسی سخت‌گیرانه سقف فضای ذخیره‌سازی (حداکثر ۱۰۰ مگابایت)
        if ($user) {
            $newUploadsSize = 0;
            foreach ($allFiles as $file) {
                if ($file) {
                    $newUploadsSize += $file->getSize();
                }
            }

            $storageCheck = $this->userStorage->check(
                $user,
                $newUploadsSize,
                $this->userStorage->imageOutputEstimate($runCount),
            );

            if (! $storageCheck['allowed']) {
                return $failure($this->userStorage->blockMessage($storageCheck), 'STORAGE_LIMIT_EXCEEDED', 400);
            }
        }

        // ۳. ساخت پرامپت نهایی: system_prompt + قالب (با جایگذاری متغیرها) + دستور حفظ هویت
        $finalPrompt = $promptBuilder->build($product, $fieldValues, $identityRequested);
        $studioPrompt = trim((string) $request->input('studio_prompt', ''));
        if ($studioPrompt !== '') {
            $finalPrompt .= "\n\nUser creative direction: {$studioPrompt}";
        }

        // مقدار فیلدهای اختیاری را بر اساس نوع فیلد پیدا می‌کنیم. این closure
        // باید قبل از ساخت payload provider تعریف شود؛ در غیر این صورت هر
        // محصولی که به فیلد منفی، seed یا strength برسد با خطای PHP متوقف می‌شود.
        $valueForType = function (string $type) use ($schema, $product, $fieldValues) {
            $field = collect($schema->fields($product))->firstWhere('type', $type);
            return $field ? data_get($fieldValues, $field['id']) : null;
        };

        // ۴. پردازش و ذخیره‌سازی عکس‌های آپلودی کاربر
        $base64Images  = [];
        $uploadedPaths = [];

        foreach ($allFiles as $file) {
            if (!$file) continue;

            $path = $file->store('uploads/personal', 'public');
            $mime = $this->normalizeImageMime((string) $file->getMimeType());
            $uploadedPaths[] = [
                'path' => $path,
                'size' => $file->getSize(),
                'mime' => $mime,
            ];

            if (str_starts_with((string) $mime, 'image/')) {
                $base64Images[] = $this->imageReference(
                    $path,
                    $mime,
                    (string) file_get_contents($file->getRealPath()),
                );
            }
        }

        if ($faceProfile) {
            foreach ($faceProfile->referenceImageEntries() as $image) {
                $path = (string) $image['path'];
                $disk = Storage::disk('public');
                if (! $disk->exists($path)) {
                    continue;
                }

                $mime = $this->normalizeImageMime((string) ($image['mime'] ?: $disk->mimeType($path)));
                if (! str_starts_with($mime, 'image/')) {
                    continue;
                }

                $base64Images[] = $this->imageReference($path, $mime, (string) $disk->get($path));
            }
        }

        // ۴.۱ الزام تصویر مرجع برای محصولات هویت‌محور/ویرایشی
        $minRefs = (int) ($product->min_reference_images ?? 0);
        if ($identityRequested && ! $faceProfile && $minRefs > 0 && count($base64Images) < $minRefs) {
            foreach ($uploadedPaths as $up) {
                Storage::disk('public')->delete($up['path']);
            }
            return $failure("این محصول برای نتیجهٔ دقیق به حداقل {$minRefs} تصویر ورودی نیاز دارد.", 'REFERENCE_IMAGE_MINIMUM');
        }

        // ۵. مشخصات خروجی تصویر هوش مصنوعی
        // کیفیت و نسبت تصویر از گزینه‌های فعال همان محصول می‌آیند؛ شِمای قدیمی
        // فقط تنظیمات داخلی محصول را نگه می‌دارد و نباید انتخاب کاربر را بازنویسی کند.
        // مقدار خالی نیز باید به کیفیت استاندارد محصول برگردد تا کلیک مستقیم روی
        // «بساز» هیچ‌وقت درخواست تولید بدون کیفیت نفرستد.
        $allowedAspectRatios = $request->boolean('studio_mode') && !$product->isVideoProduct()
            ? Product::supportedAspectRatios()
            : $product->allowedAspectRatioList();
        $requestedAspectRatio = (string) $request->input('output.aspect_ratio', '');
        $aspectRatio = in_array($requestedAspectRatio, $allowedAspectRatios, true)
            ? $requestedAspectRatio
            : $product->defaultOutputAspectRatio();

        // در استودیوی عمومی، کیفیت انتخاب‌شده از کشوی خود صفحه به مسیر واقعی
        // تولید منتقل می‌شود؛ فرم‌های قدیمی همچنان از سیاست پیش‌فرض محصول و
        // پلن کاربر استفاده می‌کنند.
        $requestedQuality = (string) $request->input('output.quality', '');
        $quality = $request->routeIs('app.create.generate') && in_array($requestedQuality, array_values(array_unique(array_merge(
            $product->allowedResolutionList(), $request->boolean('studio_mode') ? ['1K', '2K'] : []
        ))), true)
            ? $requestedQuality
            : $product->defaultOutputResolutionForUser($user);

        // applyStudioModel() مسیر انتخاب‌شده‌ی استودیو را روی کپی محصول ثبت کرده
        // است. در استودیوی عمومی نباید آن را با تنظیم کیفیت قدیمی محصول بازنویسی
        // کنیم؛ این بازنویسی باعث می‌شد با وجود انتخاب OpenRouter، درخواست ابتدا
        // به Replicate یا Fal ارسال شود.
        $executionProduct = $request->boolean('studio_mode')
            ? $product
            : $this->modelTiers->executionProductForQuality(
                $product,
                $user,
                $mainQuality['key'],
                $tierKey,
            );
        if ($identityRequested && $product->identity_model && empty($product->qualityModelConfiguration($mainQuality['key'], ! $this->modelTiers->hasPaidPlan($user))) && empty($product->modelTierConfiguration($tierKey))) {
            $executionProduct = $product->replicate();
            $executionProduct->primary_model = $product->identity_model;
            $executionProduct->ai_provider = $product->identity_model_provider ?: $product->ai_provider;
            $executionProduct->fallback_models = [];
            $executionProduct->fallback_model_providers = [];
        }

        if (($product->pricing_model === 'per_credit' || $request->boolean('studio_mode')) && $totalCreditCost > 0) {
            if (! $user) {
                return $failure('برای ساخت این محصول ابتدا وارد حساب کاربری شوید.', 'AUTHENTICATION_REQUIRED', 401);
            }
        }

        try {
            // هر درخواست ساخت، یک سفارش قابل‌پیگیری در پنل مدیریت ایجاد می‌کند.
            // این ثبت مستقل از خروجی‌های چندگانه است تا کاربر یک سفارش واحد ببیند.
            $order = Order::create([
                'user_id' => $user?->id,
                'product_id' => $product->id,
                'plan_id' => $user?->plan_id,
                'plan_name' => $user?->plan?->name ?: 'رایگان',
                'model_tier_key' => $tierKey,
                'model_tier_name' => $tierMeta['name'],
                'discount_id' => $discount?->id,
                'status' => 'processing',
                'payment_status' => 'paid',
                'processing_status' => 'processing',
                'original_credits' => $originalCreditCost,
                'discount_credits' => $discountCredits,
                'final_credits' => $totalCreditCost,
                'discount_code' => $discount?->code,
                'ai_model' => $executionProduct->primary_model,
                'ai_provider' => $executionProduct->ai_provider,
                'attempts' => 1,
                'input_payload' => [
                    'fields' => $fieldValues,
                    'prompt' => trim((string) ($request->input('studio_prompt') ?: $request->input('prompt') ?: data_get($fieldValues, 'prompt', ''))) ?: null,
                    'variants' => array_column($selectedVariants, 'key'),
                    'aspect_ratio' => $aspectRatio,
                    'quality' => $quality,
                    'output_count' => $requestedOutputCount,
                    'main_quality' => $mainQuality['key'],
                    'identity_preservation' => $identityRequested,
                    'face_profile_id' => $faceProfile?->id,
                    'resolved_prompt' => trim($finalPrompt) ?: null,
                    'input_media_count' => count($uploadedPaths) + ($faceProfile ? count($faceProfile->referenceImageEntries()) : 0),
                    'source_upload_path' => $uploadedPaths[0]['path'] ?? null,
                    'source_upload_paths' => array_values(array_column($uploadedPaths, 'path')),
                    'project_name' => trim((string) $request->input('studio_project_name', '')) ?: null,
                    'correlation_id' => $correlationId,
                ],
                'source' => 'app',
                'paid_at' => now(),
                'processing_started_at' => now(),
            ]);
            $order->recordEvent('created', 'سفارش ثبت شد', 'پردازش سفارش هوش مصنوعی آغاز شد.');

            // ورودی هر آزمایش، مستقل از موفق یا ناموفق بودن خروجی، در گالری خصوصی
            // کاربر ثبت می‌شود تا در اعتبار سرویس و گالری همان سفارش قابل پیگیری باشد.
            if ($user) {
                $gallery = app(UserGalleryService::class);
                $galleryPrompt = trim((string) ($request->input('studio_prompt') ?: $request->input('prompt') ?: data_get($fieldValues, 'prompt', '')));
                if ($galleryPrompt !== '') {
                    $gallery->captureText($user, $galleryPrompt, $order->id, [
                        'order_id' => $order->id,
                        'source' => 'app.create',
                    ]);
                }
                foreach ($uploadedPaths as $upload) {
                    $gallery->captureBuildInput(
                        $user,
                        'input_image',
                        $order->id,
                        $upload['path'],
                        'public',
                        $upload['size'],
                        $upload['mime'],
                        ['order_id' => $order->id, 'source' => 'app.create'],
                    );
                }
            }

            // رزرو اتمیک اعتبار؛ از ساخت هم‌زمان بیش از موجودی جلوگیری می‌کند و
            // سهم اعتبار هدیه/خریداری‌شده را تا انتهای سفارش نگه می‌دارد.
            if (($product->pricing_model === 'per_credit' || $request->boolean('studio_mode')) && $totalCreditCost > 0) {
                try {
                    $creditReservation = $this->creditWallet->reserve(
                        $user,
                        $totalCreditCost,
                        $order,
                    );
                } catch (ValidationException $exception) {
                    foreach ($uploadedPaths as $up) Storage::disk('public')->delete($up['path']);
                    $order->update([
                        'status' => 'review',
                        'payment_status' => 'failed',
                        'processing_status' => 'stopped',
                        'error_message' => 'موجودی اعتبار هنگام رزرو نهایی کافی نبود.',
                    ]);
                    $order->recordEvent('payment_failed', 'رزرو اعتبار ناموفق بود', 'موجودی اعتبار برای مسیر انتخاب‌شده کافی نبود.');
                    return $failure(
                        collect($exception->errors())->flatten()->first() ?? 'اعتبارهای شما کافی نیست.',
                        'INSUFFICIENT_CREDITS',
                        402,
                    );
                }
            }

            // پیامک سفارش فقط بعد از تولید موفق خروجی ارسال می‌شود. ارسال پیامک
            // در ابتدای پردازش، در صورت تنظیم اشتباه قالب‌ها، باعث پیامک پلن می‌شد.
            if ($user?->phone) {
                app(SmsEventService::class)->notifyLowCredit($user->fresh());
            }

            $extraPayload = [];
            // اتصال مستقیم مصرف provider به سفارش کاربر؛ گزارش اعتبار سرویس‌ها
            // از همین رابطه نام کاربر، محصول، سفارش و هزینه را نمایش می‌دهد.
            $extraPayload['order_id'] = $order?->id;
            if (!empty($base64Images)) {
                $extraPayload['input_references'] = array_map(fn($b64) => [
                    'type'      => 'image_url',
                    'image_url' => ['url' => $b64],
                ], $base64Images);
            }
            if ($identityRequested) {
                $extraPayload['input_fidelity'] = 'high';
            }

            // هم مقدار کسب‌وکاری رزولوشن و هم نسبت تصویر در لاگ/ردیابی اجرای
            // provider نگه داشته می‌شوند؛ خود adapter آن‌ها را به نام فیلد
            // معتبر همان مدل تبدیل می‌کند.
            $extraPayload['requested_output_resolution'] = $quality;
            $extraPayload['requested_aspect_ratio'] = $aspectRatio;

            // ساخت معمول کاربر باید مسیر سریع OpenRouter را ترجیح دهد؛ حالت
            // استودیو و کیفیت‌های حرفه‌ای انتخاب مدل خودشان را حفظ می‌کنند.
            $extraPayload['_prefer_fast_route'] = ! $request->boolean('studio_mode')
                && in_array(strtolower(trim((string) $quality)), ['480', '480p', '512', '720', '720p', '1k', '1080', '1080p'], true);

            // پارامترهای واقعی مؤثر بر کیفیت — فقط در صورت مقداردهی ارسال می‌شوند
            $userNegativePrompt = $valueForType('negative_prompt');
            $studioNegativePrompt = trim((string) $request->input('studio_negative_prompt', ''));
            if (!empty($userNegativePrompt) || !empty($product->negative_prompt)) {
                $extraPayload['negative_prompt'] = trim(implode(', ', array_filter([$product->negative_prompt, $userNegativePrompt, $studioNegativePrompt])));
            } elseif ($studioNegativePrompt !== '') {
                $extraPayload['negative_prompt'] = $studioNegativePrompt;
            }
            $userSeed = $valueForType('seed');
            if ($userSeed !== null || !is_null($product->seed)) {
                $extraPayload['seed'] = (int) ($userSeed ?? $product->seed);
            }
            $strength = $valueForType('strength');
            if ($strength !== null) {
                $extraPayload['strength'] = max(0, min(1, ((float) $strength) / 100));
            }
            if (!empty($product->output_format)) {
                $extraPayload['output_format'] = $product->output_format;
            }
            if (is_array($product->provider_options) && !empty($product->provider_options)) {
                $extraPayload['provider'] = $product->provider_options;
            }

            $outputCount = $selectedVariants === [] ? $requestedOutputCount : 1;

            // ۵.۱ لیست اجراها: بدون واریانت = یک اجرا با پرامپت اصلی (رفتار قبلی دست‌نخورده)؛
            // با واریانت = دقیقاً یک اجرا به‌ازای هر مدل تیک‌خورده، با پرامپت اختصاصی همان مدل.
            $runs = [];
            $finalPromptWithOutput = rtrim($finalPrompt)
                . "\n\nOutput requirements: target output resolution {$quality}; preserve the requested aspect ratio {$aspectRatio}.";
            if (!empty($selectedVariants)) {
                foreach ($selectedVariants as $v) {
                    $variantPrompt = $finalPromptWithOutput;
                    if ($v['prompt'] !== '') {
                        $variantPrompt .= "\n\n" . $v['prompt'];
                    } else {
                        $variantPrompt .= "\n\nOutput style/scene variant: " . $v['title'];
                    }
                    $runs[] = ['prompt' => $variantPrompt, 'key' => $v['key'], 'title' => $v['title'], 'n' => 1];
                }
            } else {
                $runs[] = ['prompt' => $finalPromptWithOutput, 'key' => null, 'title' => null, 'n' => $outputCount];
            }

            $generated = [];   // [{key, title, url, path, size, cost, prompt}]
            $failed    = [];
            $usedModels = [];
            $actualCostUsd = 0.0;
            $allActualCostsKnown = true;

            foreach ($runs as $run) {
                try {
                    $attempt = $this->openRouter->generateForProduct(
                        $executionProduct,
                        $run['prompt'],
                        $quality,
                        $aspectRatio,
                        $run['n'],
                        $extraPayload
                    );
                    $result = $attempt['data'];
                    $usedModels[] = $attempt['model'];
                    $providerRequestId = $order
                        ? AiProviderRequest::query()->where('order_id', $order->id)->latest('id')->value('id')
                        : null;

                    // ۶. ذخیره همه تصاویر پاسخ (نه فقط اولین تصویر آرایه data)
                    $items = !empty($result['data']) && is_array($result['data']) ? $result['data'] : [$result];
                    // Replicate مبلغ را در پاسخ prediction برنمی‌گرداند؛ روتر
                    // قیمت snapshot‌شده‌ی رسمی مدل را در estimated_cost_usd
                    // قرار می‌دهد. Fal نیز در صورت آماده‌بودن billing event
                    // actual_cost_usd را برمی‌گرداند.
                    $actualRunCost = $result['usage']['actual_cost_usd'] ?? $result['usage']['cost'] ?? null;
                    $allActualCostsKnown = $allActualCostsKnown && is_numeric($actualRunCost);
                    if (is_numeric($actualRunCost)) $actualCostUsd += (float) $actualRunCost;
                    $totalApiCost = (float) ($actualRunCost ?? $result['usage']['estimated_cost_usd'] ?? 0);
                    $perImageApiCost = $totalApiCost / max(1, count($items));
                    foreach ($items as $item) {
                        $singleResult = isset($item['b64_json']) || isset($item['url']) ? ['data' => [$item]] : $item;
                        $imageUrl  = $this->saveGeneratedImage($singleResult);
                        $imagePath = $this->urlToStoragePath($imageUrl);
                        $imageSize = Storage::disk('public')->exists($imagePath)
                            ? Storage::disk('public')->size($imagePath)
                            : 1024 * 1024;

                        $generated[] = [
                            'key'    => $run['key'],
                            'title'  => $run['title'],
                            'url'    => $imageUrl,
                            'path'   => $imagePath,
                            'size'   => $imageSize,
                            'cost'   => $perImageApiCost,
                            'prompt' => $run['prompt'],
                            'provider_request_id' => $providerRequestId,
                        ];
                    }
                } catch (Exception $e) {
                    Log::error('ProductGenerateController Variant Error [' . ($run['title'] ?? 'default') . ']: ' . $e->getMessage());
                    $failed[] = $run['title'] ?? 'خروجی';
                    // اگر تک‌اجرایی بود (رفتار قبلی)، خطا مثل قبل به بیرون پرتاب می‌شود
                    if (count($runs) === 1) {
                        throw $e;
                    }
                }
            }

            if (empty($generated)) {
                throw new Exception('هیچ‌کدام از مدل‌های خروجی انتخاب‌شده با موفقیت ساخته نشد. لطفاً دوباره تلاش کنید.');
            }

            if ($request->boolean('studio_mode') && !$allActualCostsKnown) {
                $order?->update([
                    'status' => 'review',
                    'processing_status' => 'needs_review',
                    'output_payload' => array_map(fn ($g) => ['path' => $g['path']], $generated),
                    'error_message' => 'هزینهٔ واقعی سرویس‌دهنده در پاسخ موجود نبود.',
                ]);
                $order?->recordEvent('needs_review', 'هزینهٔ واقعی ساخت نامشخص است', 'خروجی تا بررسی مالی تحویل داده نمی‌شود.');

                foreach ($uploadedPaths as $up) {
                    $this->userStorage->deletePublicFile($up['path'] ?? null);
                }

                return response()->json([
                    'success' => false,
                    'status' => 'needs_review',
                    'message' => 'هزینهٔ واقعی ساخت هنوز از سرویس‌دهنده دریافت نشده است؛ درخواست برای بررسی امن نگه داشته شد.',
                    'error_code' => 'ACTUAL_COST_MISSING',
                    'retryable' => false,
                    'generation_id' => null,
                    'credits_reserved' => (int) ($creditReservation['total'] ?? 0),
                    'credits_settled' => 0,
                    'credits_refunded' => 0,
                    'poll_url' => null,
                ], 202);
            }

            // تسویه پیش از انتشار رکوردهای گالری انجام می‌شود تا در صورت کسری
            // اعتبار برای هزینهٔ واقعی، خروجی بدون تسویه در دسترس قرار نگیرد.
            $actualOriginalCredit = $request->boolean('studio_mode')
                ? $studioCosts->creditsForActualCost($actualCostUsd, 'image')
                : ($product->pricing_model === 'per_credit' ? $creditCost * count($generated) : 0);
            $actualDiscount = $request->boolean('studio_mode') ? 0 : ($discount?->calculateCredits($actualOriginalCredit) ?? 0);
            $actualCredit = max(0, $actualOriginalCredit - $actualDiscount);
            $creditsReturned = 0;
            $reservedCreditTotal = (int) ($creditReservation['total'] ?? 0);
            if ($creditReservation['total'] > 0 && $user) {
                $creditsReturned = max(0, (int) $creditReservation['total'] - $actualCredit);
                $creditReservation = $this->creditWallet->settle($user, $creditReservation, $actualCredit);
                $creditReservationSettled = true;
            }

            // ۷. ثبت نهایی سوابق در دیتابیس در صورت لاگین بودن کاربر
            $generatedImageRecords = [];
            if ($user) {
                foreach ($generated as $g) {
                    $generatedImage = GeneratedImage::create([
                        'user_id'     => $user->id,
                        'product_id'  => $product->id,
                        'order_id' => $order?->id,
                        'ai_provider_request_id' => $g['provider_request_id'],
                        'image_path'  => $g['path'],
                        'user_prompt' => $g['prompt'],
                        'cost'        => $g['cost'],
                        'size'        => $g['size'],
                        'expires_at'  => now()->addDays(UserStorageService::OUTPUT_RETENTION_DAYS),
                    ]);
                    // ساخت بندانگشتی بعد از پاسخ اصلی/در صف انجام می‌شود تا
                    // زمان پاسخ ساخت محصول به پردازش تصویر وابسته نباشد.
                    GenerateProfileMediaThumbnail::dispatch($generatedImage->id)->afterResponse();
                    $generatedImageRecords[] = $generatedImage;
                    try {
                        app(UserGalleryService::class)->captureOutput(
                            $user,
                            'output_image',
                            (int) $generatedImage->id,
                            (string) $g['path'],
                            'public',
                            (int) $g['size'],
                            'image/*',
                            ['order_id' => $order?->id, 'source' => 'app.create'],
                        );
                    } catch (\Throwable $exception) {
                        report($exception);
                    }
                    // ثبت تصویر، منبع اصلی موفقیت ساخت است. سرویس‌های جانبی
                    // مثل رفرال و زمان‌بندی پیامک نباید بعد از ثبت خروجی، پاسخ
                    // موفق ساخت را به خطا تبدیل کنند.
                    try {
                        app(\App\Services\ReferralProgramService::class)->handleSuccessfulGeneration($generatedImage);
                    } catch (\Throwable $exception) {
                        report($exception);
                    }
                    if ($user) {
                        try {
                            app(SmsEventService::class)->markFirstImageFollowupPending($user);
                        } catch (\Throwable $exception) {
                            report($exception);
                        }
                    }
                }

            }

            // ورودی اصلی فقط تا پایان همین ساخت روی دیسک عمومی لازم است؛
            // نسخهٔ مستقل گالری، در صورت رضایت کاربر، قبلاً روی user_gallery کپی شده است.
            foreach ($uploadedPaths as $up) {
                $this->userStorage->deletePublicFile($up['path'] ?? null);
            }

            // پاداش مالک فقط بعد از مشخص‌شدن سهم نهایی اعتبار هر خروجی ثبت می‌شود.
            // خطای دفتر پاداش نباید پاسخ ساخت موفق کاربر را خراب کند؛ اجرای بعدی
            // سرویس با event_key یکتا از ثبت دوباره جلوگیری می‌کند.
            foreach ($generatedImageRecords as $generatedImageRecord) {
                try {
                    $this->creatorRewards->rewardForImage($generatedImageRecord, $creditReservation);
                } catch (\Throwable $exception) {
                    report($exception);
                }
            }

            if ($user) {
                $this->userStorage->forgetProfileSnapshot($user);
            }

            $failedMsg = !empty($failed)
                ? 'ساخت این مدل‌ها ناموفق بود: ' . implode('، ', $failed)
                : null;

            try {
                $order?->update([
                    'status' => 'completed',
                    'processing_status' => 'completed',
                    'ai_model' => $usedModels[0] ?? $executionProduct->primary_model,
                    'final_credits' => $actualCredit,
                    'original_credits' => $actualOriginalCredit,
                    'discount_credits' => $actualDiscount,
                    'promotional_credits_used' => $creditReservation['promotional'],
                    'paid_credits_used' => $creditReservation['paid'],
                    'output_payload' => array_map(fn ($g) => ['key' => $g['key'], 'title' => $g['title'], 'path' => $g['path']], $generated),
                    'completed_at' => now(),
                    'processing_duration_ms' => $order?->processing_started_at ? $order->processing_started_at->diffInMilliseconds(now()) : null,
                ]);
                $order?->recordEvent('completed', 'پردازش با موفقیت تکمیل شد', $failedMsg);
            } catch (\Throwable $exception) {
                report($exception);
            }

            try {
                $this->markTelegramBuildCompleted($request, $product);
            } catch (\Throwable $exception) {
                report($exception);
            }

            if ($user?->phone && $order) {
                try {
                    app(SmsEventService::class)->send('order_completed', $user->phone, [
                        'name'=>$user->name, 'phone'=>$user->phone, 'order_number'=>$order->order_number,
                        'product_name'=>$product->name_fa ?? $product->name ?? '', 'balance'=>(string)($user->fresh()->tokens ?? 0),
                    ]);
                } catch (\Throwable $exception) {
                    report($exception);
                }
            }
            if ($discount) {
                try {
                    $discount->increment('used_count');
                } catch (\Throwable $exception) {
                    report($exception);
                }
            }

            $remainingTokens = 0;
            if ($user) {
                try {
                    $remainingTokens = (int) ($user->fresh()->tokens ?? 0);
                } catch (\Throwable $exception) {
                    report($exception);
                }
            }

            Log::info('Studio image generation completed', [
                'order_id' => $order?->id,
                'actual_cost_usd' => $actualCostUsd,
                'credits_settled' => $actualCredit,
            ]);

            return response()->json([
                'success'          => true,
                'status'           => 'completed',
                'message'          => 'تصویر با موفقیت ساخته شد.',
                'error_code'       => null,
                'retryable'        => false,
                'generation_id'    => ($generatedImageRecords[0] ?? null)?->id,
                'credits_reserved' => $reservedCreditTotal,
                'credits_settled'  => (int) ($creditReservation['total'] ?? 0),
                'credits_refunded' => $creditsReturned,
                'poll_url'         => null,
                'image_url'        => $generated[0]['url'],
                'images'           => array_map(function (array $g, int $index) use ($generatedImageRecords): array {
                    return [
                        'key' => $g['key'],
                        'title' => $g['title'],
                        'url' => $g['url'],
                        'generated_image_id' => ($generatedImageRecords[$index] ?? null)?->id,
                    ];
                }, $generated, array_keys($generated)),
                'failed_message'   => $failedMsg,
                'credits_returned'  => $creditsReturned,
                'used_model'       => $usedModels[0] ?? $executionProduct->primary_model,
                'model_tier'       => $tierMeta,
                'remaining_tokens' => $remainingTokens,
            ])->header('X-Correlation-ID', $correlationId);

        } catch (\Throwable $e) {
            $creditsReturned = 0;
            if ($creditReservation['total'] > 0 && $user) {
                $creditsReturned = (int) $creditReservation['promotional'] + (int) $creditReservation['paid'];
                $this->creditWallet->restore(
                    $user,
                    $creditReservation['promotional'],
                    $creditReservation['paid'],
                    $creditReservationSettled,
                    $creditReservation['ledger_key'] ?? null,
                    $creditReservation['grant_allocations'] ?? [],
                );
            }
            foreach ($uploadedPaths as $up) {
                Storage::disk('public')->delete($up['path']);
            }
            foreach ((array) ($generated ?? []) as $output) {
                if (!empty($output['path'])) Storage::disk('public')->delete((string) $output['path']);
            }
            Log::error('Studio image generation failed', [
                'exception' => $e::class,
                'message' => Str::limit($e->getMessage(), 1000, ''),
                'order_id' => $order?->id,
            ]);
            if ($order) {
                $order->update([
                    'status' => 'review', 'processing_status' => 'failed',
                    'error_message' => $e->getMessage(),
                    'refunded_credits' => $creditsReturned,
                    'promotional_credits_refunded' => $creditsReturned > 0 ? (int) $creditReservation['promotional'] : 0,
                    'paid_credits_refunded' => $creditsReturned > 0 ? (int) $creditReservation['paid'] : 0,
                    'refunded_at' => $creditsReturned > 0 ? now() : null,
                    'processing_duration_ms' => $order->processing_started_at ? $order->processing_started_at->diffInMilliseconds(now()) : null,
                ]);
                $order->recordEvent('failed', 'پردازش ناموفق بود', $e->getMessage());
            }
            $errorText = strtolower($e->getMessage());
            $providerBusy = (int) $e->getCode() === 429
                || str_contains($errorText, 'سقف درخواست‌های هم‌زمان')
                || str_contains($errorText, 'concurrent');
            $providerCreditIssue = str_contains($errorText, 'insufficient credit')
                || str_contains($errorText, 'exhausted balance')
                || str_contains($errorText, 'quota')
                || str_contains($errorText, 'اعتبار سرویس');
            $providerFailure = $providerBusy
                || str_contains($errorText, 'provider')
                || str_contains($errorText, 'fal.ai')
                || str_contains($errorText, 'replicate')
                || str_contains($errorText, 'timeout')
                || str_contains($errorText, 'curl');
            return response()->json([
                'success' => false,
                'status' => 'failed',
                'message' => $providerCreditIssue
                    ? 'موجودی سرویس ساخت موقتاً کافی نیست؛ اعتبار این درخواست کامل به حساب شما برگشت داده شد. لطفاً بعداً دوباره تلاش کنید.'
                    : ($providerBusy
                    ? 'صف پردازش این سرویس در حال تکمیل است. اعتبار این تلاش محفوظ مانده؛ چند لحظه بعد دوباره امتحان کن.'
                    : ($providerFailure
                    ? 'مدل انتخاب‌شده در زمان مقرر پاسخ نداد. اگر مدل جایگزین برای محصول ثبت شده باشد، سیستم آن را هم امتحان کرده است؛ لطفاً چند لحظه بعد دوباره تلاش کنید.'
                    : 'ساخت تصویر انجام نشد. لطفاً دوباره تلاش کنید.')),
                'error_code' => $providerCreditIssue ? 'AI_PROVIDER_CREDIT_UNAVAILABLE' : ($providerBusy ? 'AI_PROVIDER_BUSY' : ($providerFailure ? 'AI_PROVIDER_UNAVAILABLE' : 'IMAGE_GENERATION_FAILED')),
                'retryable' => $providerCreditIssue || $providerBusy || $providerFailure,
                'generation_id' => null,
                'credits_reserved' => (int) ($creditReservation['total'] ?? 0),
                'credits_settled' => 0,
                'credits_refunded' => $creditsReturned,
                'poll_url' => null,
                'credits_returned' => $creditsReturned,
            ], $providerFailure ? 503 : 422)->header('X-Correlation-ID', $correlationId);
        }
    }

    private function markTelegramBuildCompleted(Request $request, Product $product): void
    {
        $telegramUserId = (int) $request->session()->get('telegram_mini_app_user_id');
        $launchToken = trim((string) $request->session()->get('telegram_mini_app_launch_token'));
        if ($telegramUserId < 1 || $launchToken === '') {
            return;
        }

        $telegramUser = TelegramUser::query()->find($telegramUserId);
        if (! $telegramUser) {
            return;
        }

        $telegramUser->productClicks()
            ->where('launch_token', $launchToken)
            ->where('product_id', $product->id)
            ->whereNull('completed_at')
            ->update(['completed_at' => now()]);
    }

    private function selectedStudioImageModel(Request $request, Product $product): ?AiModel
    {
        if ($request->boolean('studio_mode')) {
            $requestedModelId = trim((string) $request->input('studio_model', ''));
            $models = $this->sortStudioImageModels(AiModel::query()->selectableForImageStudio()->get());
            $model = $requestedModelId !== ''
                ? $models->firstWhere('openrouter_model_id', $requestedModelId)
                : $models->first();

            if (! $model) {
                throw ValidationException::withMessages([
                    'studio_model' => 'مدل انتخاب‌شده در کاتالوگ تأییدشده‌ی استودیو موجود نیست.',
                ]);
            }

            return $model;
        }

        $requestedModelId = trim((string) $request->input('studio_model', ''));
        $modelId = $requestedModelId ?: (string) $product->primary_model;
        if ($modelId === '') return null;

        $taskTypes = $this->studioTaskTypesForRequest($request, 'image');
        $primary = AiModel::query()->where('is_active', true)->where('output_modality', 'image')
            ->where(function ($workflow) use ($taskTypes, $request): void {
                $workflow->whereIn('task_type', $taskTypes);
                if ($request->input('studio_workflow') === 'image_to_image') {
                    $workflow->orWhere(function ($imageInputModel): void {
                        $imageInputModel->where('task_type', 'text_to_image')->where('supports_image_input', true);
                    });
                }
            })->where('openrouter_model_id', $modelId)
            ->where('provider', 'openrouter')
            ->first();
        if ($requestedModelId !== '' || $this->hasStoredModelPrice($primary)) return $primary;

        return AiModel::query()->where('is_active', true)->where('output_modality', 'image')
            ->whereIn('task_type', $taskTypes)
            ->where('provider', 'openrouter')
            ->whereNotNull('openrouter_model_id')->where('openrouter_model_id', '<>', '')
            ->orderByRaw("CASE task_type WHEN 'text_to_image' THEN 0 WHEN 'image_to_image' THEN 1 ELSE 2 END")
            ->orderByRaw("CASE provider WHEN 'openrouter' THEN 0 WHEN 'fal' THEN 1 WHEN 'replicate' THEN 2 ELSE 3 END")
            ->orderByDesc('lab_priority')->first() ?: $primary;
    }

    private function sortStudioImageModels(\Illuminate\Support\Collection $models): \Illuminate\Support\Collection
    {
        return $models->sortBy(function (AiModel $model): array {
            $fallbackPriority = array_search($model->openrouter_model_id, AiModel::STUDIO_IMAGE_MODEL_PRIORITY, true);
            $priority = $model->studio_image_priority !== null
                ? (int) $model->studio_image_priority
                : ($fallbackPriority === false ? 1000 : $fallbackPriority + 1);

            return [$priority, $model->id];
        })->values();
    }

    /**
     * مدیریت هوشمند پاسخ‌های مبتنی بر URL یا Base64 از سمت مدل‌های OpenRouter
     */
    private function selectedFaceProfile(Request $request, $user): ?FaceProfile
    {
        if (! $request->filled('face_profile_id')) {
            return null;
        }

        if (! $user || ! Schema::hasTable('face_profiles')) {
            throw ValidationException::withMessages([
                'face_profile_id' => 'پروفایل چهره انتخاب‌شده در دسترس نیست.',
            ]);
        }

        $profile = $user->faceProfiles()
            ->active()
            ->whereKey($request->integer('face_profile_id'))
            ->first();

        if (! $profile || $profile->referenceImageEntries() === []) {
            throw ValidationException::withMessages([
                'face_profile_id' => 'پروفایل چهره انتخاب‌شده معتبر نیست.',
            ]);
        }

        $hasUsableImage = collect($profile->referenceImageEntries())->contains(function (array $image): bool {
            return str_starts_with((string) ($image['mime'] ?? ''), 'image/')
                && Storage::disk('public')->exists((string) $image['path']);
        });

        if (! $hasUsableImage) {
            throw ValidationException::withMessages([
                'face_profile_id' => 'تصاویر مرجع این پروفایل در دسترس نیستند. یک پروفایل چهره جدید بسازید.',
            ]);
        }

        return $profile;
    }

    protected function saveGeneratedImage(array $responseData): string
    {
        // ۱. تلاش برای پیدا کردن ساختار Base64 مرسوم
        $base64Image = $responseData['data'][0]['b64_json']
            ?? $responseData[0]['b64_json']
            ?? null;

        $filename = 'generated/' . uniqid('gen_') . '.png';

        if ($base64Image) {
            if (str_contains($base64Image, 'base64,')) {
                $base64Image = explode('base64,', $base64Image)[1];
            }
            $binary = base64_decode(trim($base64Image), true);
            if ($binary === false) throw new Exception('خطا در رمزگشایی کدهای مربوط به تصویر Base64.');
            
            Storage::disk('public')->put($filename, $binary);
            return asset('storage/' . $filename);
        }

        // ۲. پشتیبانی از ساختارهای مبتنی بر لینک مستقیم (بسیاری از پلتفرم‌های OpenRouter لینک تصویر برمی‌گردانند)
        $directUrl = $responseData['data'][0]['url'] 
            ?? $responseData[0]['url'] 
            ?? null;
        $downloadHeaders = $responseData['data'][0]['headers']
            ?? $responseData[0]['headers']
            ?? [];

        if ($directUrl) {
            try {
                $download = Http::withHeaders(is_array($downloadHeaders) ? $downloadHeaders : [])
                    ->connectTimeout(15)->timeout(120)->get($directUrl);
                if ($download->successful()) {
                    Storage::disk('public')->put($filename, $download->body());
                    return asset('storage/' . $filename);
                }
            } catch (Exception $e) {
                Log::warning("امکان دانلود مستقیم تصویر فراهم نشد، بازگشت لینک اصلی: " . $e->getMessage());
                return $directUrl; // در صورت عدم امکان دانلود، خود آدرس مستقیم را برگردان
            }
            return $directUrl;
        }

        throw new Exception('هیچ داده تصویری معتبری (بایری یا لینک خروجی) در پاسخ سرور یافت نشد. پاسخ خام: ' . json_encode($responseData));
    }

    protected function urlToStoragePath(string $url): string
    {
        $base = asset('storage/');
        return str_replace($base, '', $url);
    }

    private function imageReference(string $path, string $mime, string $contents): string
    {
        // در محیط آنلاین، URL عمومی هم از نظر حجم درخواست بهتر است و هم
        // مشکل escape شدن MIME در data URL را به‌طور کامل حذف می‌کند.
        if (app()->environment('production')) {
            return asset('storage/' . ltrim($path, '/'));
        }

        return 'data:' . $mime . ';base64,' . base64_encode($contents);
    }

    private function normalizeImageMime(string $mime): string
    {
        $mime = strtolower(trim(explode(';', $mime, 2)[0] ?? ''));
        $mime = str_replace(['\\', '"', "'", ' '], '', $mime);

        return match ($mime) {
            'image/jpg', 'image/jpeg' => 'image/jpeg',
            'image/png' => 'image/png',
            'image/webp' => 'image/webp',
            default => $mime,
        };
    }
}
