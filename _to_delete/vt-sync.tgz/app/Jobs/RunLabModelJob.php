<?php

namespace App\Jobs;

use App\Models\LabExperiment;
use App\Models\LabRun;
use App\Models\ServiceCreditAccount;
use App\Services\FalAiBillingService;
use App\Services\AiProviderRouter;
use App\Services\OpenRouterService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class RunLabModelJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 1;
    public int $timeout = 900;

    public function __construct(public int $runId) {}

    public function handle(AiProviderRouter $router, OpenRouterService $openRouter): void
    {
        $run = LabRun::with(['experiment.images', 'aiModel'])->find($this->runId);
        if (!$run || in_array($run->status, ['completed', 'cancelled'], true)) return;

        $started = microtime(true);
        $run->forceFill(['status' => 'processing', 'started_at' => now(), 'error_message' => null])->save();

        try {
            $settings = (array) $run->parameters;
            $providerResolution = match ((string) ($settings['grade_resolution'] ?? $settings['resolution'] ?? '720')) {
                '480', '720', '1080' => '1K',
                '1440' => '2K',
                '2160' => '4K',
                default => (string) ($settings['resolution'] ?? '1K'),
            };
            $references = [];
            foreach ($run->experiment->images as $image) {
                if (!Storage::disk('public')->exists($image->image_path)) continue;
                $contents = Storage::disk('public')->get($image->image_path);
                $mime = $image->mime_type ?: 'image/jpeg';
                $references[] = ['type' => 'image_url', 'image_url' => ['url' => 'data:' . $mime . ';base64,' . base64_encode($contents)]];
            }

            $extra = [];
            // مدل‌های عکس‌به‌عکس و هویت‌محور مرجع را دریافت می‌کنند؛ مدل‌های
            // متن‌به‌عکس با همان پرامپت محصول و بدون ورودی ناسازگار اجرا می‌شوند.
            if ($references && $run->aiModel?->supports_image_input) {
                $extra['input_references'] = $references;
            }
            if (($settings['seed'] ?? null) !== null && $settings['seed'] !== '') $extra['seed'] = (int) $settings['seed'];
            if ($run->experiment->negative_prompt) $extra['negative_prompt'] = $run->experiment->negative_prompt;
            $extra['preserve_face'] = (bool) $run->preserve_face;

            $result = $router->generateImageFromPrompt(
                $run->model_id,
                $run->prompt_snapshot,
                $providerResolution,
                (string) ($settings['grade_aspect_ratio'] ?? $settings['aspect_ratio'] ?? '1:1'),
                max(1, min(4, (int) ($settings['count'] ?? 1))),
                $extra,
                $run->provider
            );

            $items = (array) ($result['data'] ?? []);
            if (!$items) throw new \RuntimeException('از مدل انتخاب‌شده خروجی تصویری دریافت نشد.');

            foreach ($items as $item) {
                $base64 = $item['b64_json'] ?? null;
                $remoteUrl = $item['url'] ?? null;
                $path = null;
                if ($base64) {
                    $path = 'lab-outputs/' . Str::uuid() . '.png';
                    Storage::disk('public')->put($path, base64_decode($base64, true));
                } elseif ($remoteUrl && filter_var($remoteUrl, FILTER_VALIDATE_URL)) {
                    try {
                        $download = Http::timeout(30)->get($remoteUrl);
                        if ($download->successful() && $download->body() !== '') {
                            $path = 'lab-outputs/' . Str::uuid() . '.png';
                            Storage::disk('public')->put($path, $download->body());
                            $remoteUrl = null;
                        }
                    } catch (\Throwable) {
                        // لینک Provider به‌عنوان پشتیبان در خروجی نگه داشته می‌شود.
                    }
                }
                if (!$path && !$remoteUrl) continue;
                $metadata = ['provider_item' => array_filter(['revised_prompt' => $item['revised_prompt'] ?? null])];
                $width = $height = null;
                $size = null;
                $mime = null;
                if ($path && Storage::disk('public')->exists($path)) {
                    $size = (int) Storage::disk('public')->size($path);
                    $mime = Storage::disk('public')->mimeType($path) ?: 'image/png';
                    $absolute = method_exists(Storage::disk('public'), 'path') ? Storage::disk('public')->path($path) : null;
                    if ($absolute && is_file($absolute)) {
                        $dimensions = @getimagesize($absolute);
                        $width = $dimensions[0] ?? null;
                        $height = $dimensions[1] ?? null;
                    }
                }
                $run->outputs()->create([
                    'output_path' => $path,
                    'remote_url' => $remoteUrl,
                    'status' => 'completed',
                    'width' => $width,
                    'height' => $height,
                    'ratio' => $width && $height ? round($width / $height, 4) : null,
                    'size' => $size,
                    'mime_type' => $mime,
                    'color_profile' => 'RGB',
                    'metadata' => $metadata,
                ]);
            }

            if (!$run->outputs()->exists()) throw new \RuntimeException('فایل خروجی قابل ذخیره‌سازی نبود.');

            $scoringCost = $this->scoreOutputs($run, $openRouter);

            $usage = (array) ($result['usage'] ?? []);
            $reportedTokens = data_get($usage, 'total_tokens', data_get($usage, 'tokens'));
            $generationCost = $this->resolveGenerationCost($run, $result, $usage);
            $this->recordFalBilling($run, $result);
            $actualCost = $generationCost + $scoringCost;
            $durationMs = (int) round((microtime(true) - $started) * 1000);
            $rateToman = (float) $run->exchange_rate_irr / 10;
            $run->forceFill([
                'status' => 'completed',
                'actual_cost_usd' => $actualCost,
                'cost' => $actualCost,
                'actual_cost_toman' => $actualCost * $rateToman,
                'build_seconds' => max(1, (int) round($durationMs / 1000)),
                // همه‌ی providerهای تصویر (از جمله Replicate) توکن گزارش نمی‌کنند.
                // مقدار null یعنی «گزارش نشده» و با صفرِ واقعی اشتباه گرفته نمی‌شود.
                'tokens_used' => is_numeric($reportedTokens) ? (int) $reportedTokens : null,
                'provider_response' => array_filter([
                    'id' => $result['id'] ?? null,
                    'model' => $result['model'] ?? $run->model_id,
                    'created' => $result['created'] ?? null,
                    'usage' => $usage,
                    'provider_metadata' => $result['provider_metadata'] ?? [],
                ], fn ($value) => $value !== null && $value !== []),
                'completed_at' => now(),
                'duration_ms' => $durationMs,
                'latency_ms' => $durationMs,
            ])->save();
        } catch (\Throwable $error) {
            $run->forceFill([
                'status' => 'failed',
                'error_message' => Str::limit($error->getMessage(), 1000, ''),
                'completed_at' => now(),
                'build_seconds' => max(1, (int) round((microtime(true) - $started))),
                'duration_ms' => (int) round((microtime(true) - $started) * 1000),
                'latency_ms' => (int) round((microtime(true) - $started) * 1000),
            ])->save();
        }

        $this->refreshExperiment($run->lab_experiment_id);
    }

    public function failed(?\Throwable $exception): void
    {
        $run = LabRun::find($this->runId);
        if (!$run || in_array($run->status, ['completed', 'failed', 'cancelled'], true)) return;

        $run->forceFill([
            'status' => 'failed',
            'error_message' => Str::limit($exception?->getMessage() ?: 'پردازش آزمایش توسط worker متوقف شد.', 1000, ''),
            'completed_at' => now(),
        ])->save();

        $this->refreshExperiment($run->lab_experiment_id);
    }

    private function refreshExperiment(int $experimentId): void
    {
        $experiment = LabExperiment::with('runs')->find($experimentId);
        if (!$experiment) return;
        $runs = $experiment->runs;
        $terminal = $runs->every(fn ($run) => in_array($run->status, ['completed', 'failed', 'cancelled'], true));
        $status = $terminal
            ? ($runs->contains(fn ($run) => $run->status === 'completed')
                ? ($runs->contains(fn ($run) => $run->status === 'failed') ? 'partially_failed' : 'completed')
                : 'failed')
            : ($runs->contains(fn ($run) => $run->status === 'processing') ? 'processing' : 'queued');
        $totalUsd = (float) $runs->sum(fn ($run) => $this->effectiveRunCost($run));
        $rateToman = (float) $experiment->exchange_rate_irr / 10;
        $experiment->forceFill([
            'status' => $status,
            'actual_cost_usd' => $totalUsd,
            'actual_cost_irr' => $totalUsd * (float) $experiment->exchange_rate_irr,
            'actual_cost_toman' => $totalUsd * $rateToman,
            'total_cost_usd' => $totalUsd,
            'total_cost_toman' => $totalUsd * $rateToman,
            'models_count' => $runs->count(),
            'started_at' => $runs->min('started_at') ?: $experiment->started_at,
            'completed_at' => $terminal ? now() : null,
            'tested_at' => $terminal ? now() : $experiment->tested_at,
            'report_status' => $terminal && $status !== 'failed' ? 'ready' : ($status === 'failed' ? 'failed' : 'draft'),
        ])->save();
    }

    private function resolveGenerationCost(LabRun $run, array $result, array $usage): float
    {
        foreach ([
            data_get($usage, 'cost'),
            data_get($usage, 'actual_cost_usd'),
            data_get($result, 'actual_cost_usd'),
            data_get($usage, 'estimated_cost_usd'),
            data_get($result, 'estimated_cost_usd'),
            $run->estimated_cost_usd,
        ] as $candidate) {
            if (is_numeric($candidate) && (float) $candidate > 0) {
                return round((float) $candidate, 6);
            }
        }

        return 0.0;
    }

    private function recordFalBilling(LabRun $run, array $result): void
    {
        if ($run->provider !== 'fal') return;
        $event = data_get($result, 'provider_metadata.provider_metadata.billing_event');
        if (!is_array($event)) return;
        $account = ServiceCreditAccount::query()->where('slug', 'fal')->where('is_active', true)->first();
        if ($account) app(FalAiBillingService::class)->recordBillingEvent($account, $event);
    }

    private function effectiveRunCost(LabRun $run): float
    {
        $actual = (float) $run->actual_cost_usd;
        return $actual > 0 ? $actual : (float) $run->estimated_cost_usd;
    }

    private function scoreOutputs(LabRun $run, OpenRouterService $openRouter): float
    {
        $scoringModel = (string) data_get($run->parameters, 'scoring_model', 'openai/gpt-4o-mini');
        if ($scoringModel === '') return 0.0;
        $totalCost = 0.0;

        foreach ($run->outputs()->get() as $output) {
            try {
                $imageData = null;
                if ($output->output_path && Storage::disk('public')->exists($output->output_path)) {
                    $mime = Storage::disk('public')->mimeType($output->output_path) ?: 'image/png';
                    $imageData = 'data:' . $mime . ';base64,' . base64_encode(Storage::disk('public')->get($output->output_path));
                } elseif ($output->remote_url) {
                    $imageData = $output->remote_url;
                }
                if (!$imageData) continue;

                $evaluation = $openRouter->scoreLabImage($scoringModel, $run->prompt_snapshot, $imageData);
                $totalCost += (float) data_get($evaluation, 'usage.cost', 0);
                foreach ((array) ($evaluation['scores'] ?? []) as $criterion => $score) {
                    \App\Models\LabScore::updateOrCreate(
                        ['lab_run_output_id' => $output->id, 'evaluator_type' => 'ai', 'criterion' => $criterion, 'admin_id' => null],
                        ['score' => (int) $score, 'note' => $evaluation['summary'] ?: null]
                    );
                }

                $metadata = (array) $output->metadata;
                $metadata['ai_evaluation'] = [
                    'model' => $scoringModel,
                    'summary' => $evaluation['summary'] ?? null,
                    'usage' => $evaluation['usage'] ?? [],
                ];
                $output->update(['metadata' => $metadata]);
            } catch (\Throwable $error) {
                // شکست ارزیابی نباید نتیجه‌ی تولید تصویر را ناموفق کند.
                $metadata = (array) $output->metadata;
                $metadata['ai_evaluation_error'] = \Illuminate\Support\Str::limit($error->getMessage(), 500, '');
                $output->update(['metadata' => $metadata]);
            }
        }

        return $totalCost;
    }
}
